;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.34.0"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "0c8db5a197400beeda1bb3046be0857f1491f5a4"
  :revdesc "0c8db5a19740"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
