;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "panel" "0.2"
  "Simple welcome-panel screen."
  '((emacs "27.1")
    (async "1.9.7"))
  :url "https://github.com/konrad1977/welcome-panel"
  :commit "f3977ce5755912ce737f1471379dd8fdb92cb773"
  :revdesc "f3977ce57559"
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
