;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.7.0"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5b35ea6fbd22a773ba904e35e81cd2b3862568e3"
  :revdesc "5b35ea6fbd22"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
