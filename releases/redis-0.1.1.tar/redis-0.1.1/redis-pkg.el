;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redis" "0.1.1"
  "Native Redis RESP client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/redis.el"
  :commit "3c6e12244f148ad5d66e0b09af89e156cee5da02"
  :revdesc "3c6e12244f14"
  :keywords '("data" "redis" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
