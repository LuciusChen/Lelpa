;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "setup" "1.5.0"
  "Helpful Configuration Macro."
  '((emacs "26.1"))
  :url "https://codeberg.org/pkal/setup.el"
  :commit "8805db36d03891c5df3fd9b56f5a9137c7ca5255"
  :revdesc "8805db36d038"
  :keywords '("lisp" "local")
  :authors '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")))
