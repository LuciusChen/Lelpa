;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plz-event-source" "0.1.1"
  "Plz Event Source."
  '((emacs          "26.3")
    (plz-media-type "0.1.0"))
  :url "https://github.com/r0man/plz-event-source"
  :commit "1abd0313244603d8b76ea8ffd6dfd2b166d825b6"
  :revdesc "1abd03132446"
  :keywords '("comm" "network" "http")
  :authors '(("r0man" . "roman@burningswell.com"))
  :maintainers '(("r0man" . "roman@burningswell.com")))
