;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.64.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c6f24788b5e114ad6569b3943702bd1609617a5e"
  :revdesc "c6f24788b5e1"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
