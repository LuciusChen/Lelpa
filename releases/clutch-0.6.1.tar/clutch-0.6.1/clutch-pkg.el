;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.6.1"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "bbb1d800763628312d493153ceae738fafb04ebd"
  :revdesc "bbb1d8007636"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
