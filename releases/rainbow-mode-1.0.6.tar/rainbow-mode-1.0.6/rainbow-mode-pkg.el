;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-mode" "1.0.6"
  "Colorize color names in buffers."
  ()
  :url "https://github.com/emacs-straight/rainbow-mode"
  :commit "55a8c15782197cd9db8950d2f5ed1b9caca08dae"
  :revdesc "55a8c1578219"
  :keywords '("faces")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
