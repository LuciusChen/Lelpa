;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.8.0"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "257ef714db0b4db298ea2eda8013b09cd20ab45b"
  :revdesc "257ef714db0b"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
