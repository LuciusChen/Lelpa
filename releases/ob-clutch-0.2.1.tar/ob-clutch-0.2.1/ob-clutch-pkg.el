;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-clutch" "0.2.1"
  "Org-Babel integration for clutch database client."
  '((emacs  "29.1")
    (clutch "0.7.2"))
  :url "https://github.com/LuciusChen/ob-clutch"
  :commit "7215e324db2798e06f3ae47e96f2c0c5d9b87818"
  :revdesc "7215e324db27"
  :keywords '("languages" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
