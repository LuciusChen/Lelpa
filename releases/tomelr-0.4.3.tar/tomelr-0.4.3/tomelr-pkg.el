;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomelr" "0.4.3"
  "Convert S-expressions to TOML."
  '((emacs "26.3")
    (map   "3.2.1")
    (seq   "2.23"))
  :url "https://github.com/kaushalmodi/tomelr/"
  :commit "57cb24df521031a6d02f61091db82d292e4175df"
  :revdesc "57cb24df5210"
  :keywords '("data" "tools" "toml" "serialization" "config")
  :authors '(("Kaushal Modi" . "kaushal.modi@gmail.com"))
  :maintainers '(("Kaushal Modi" . "kaushal.modi@gmail.com")))
