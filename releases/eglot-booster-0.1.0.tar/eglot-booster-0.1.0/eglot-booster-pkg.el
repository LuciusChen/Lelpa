;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-booster" "0.1.0"
  "Boost eglot using lsp-booster."
  '((emacs   "29.1")
    (jsonrpc "1.0")
    (eglot   "1.0")
    (seq     "2.24"))
  :url "https://github.com/jdtsmith/eglot-booster"
  :commit "e6daa6bcaf4aceee29c8a5a949b43eb1b89900ed"
  :revdesc "e6daa6bcaf4a"
  :keywords '("convenience" "programming"))
