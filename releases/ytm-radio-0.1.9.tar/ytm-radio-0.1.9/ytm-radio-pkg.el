;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ytm-radio" "0.1.9"
  "YouTube Music audio launcher."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/luciuschen/ytm-radio"
  :commit "73a4a11dba1ac158795ff8d9ee57f0b0977024fb"
  :revdesc "73a4a11dba1a"
  :keywords '("multimedia"))
