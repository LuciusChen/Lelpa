;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-clutch" "0.2.0"
  "Org-Babel integration for clutch database client."
  '((emacs  "29.1")
    (clutch "0.5.2"))
  :url "https://github.com/LuciusChen/ob-clutch"
  :commit "74f0f21cb69ba79a86455ae3ffd6b73d731803a6"
  :revdesc "74f0f21cb69b"
  :keywords '("languages" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
