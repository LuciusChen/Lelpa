;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote" "4.3.1"
  "Simple notes with an efficient file-naming scheme."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/denote"
  :commit "8f2dded4fcc680052c1925f20d883e4029eced0d"
  :revdesc "8f2dded4fcc6"
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
