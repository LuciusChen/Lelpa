;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "0.8.392"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "961ff116e7fad159fd426d06d117437e2e2bb055"
  :revdesc "961ff116e7fa"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
