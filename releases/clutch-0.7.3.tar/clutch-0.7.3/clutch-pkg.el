;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.7.3"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5a27e6aff44745723f860be995efa6c95884ca64"
  :revdesc "5a27e6aff447"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
