;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.5"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "f34fa6e463b9ec377935c7520f2f9700a2c6c1fd"
  :revdesc "f34fa6e463b9"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
