;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote" "4.2.3"
  "Simple notes with an efficient file-naming scheme."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/denote"
  :commit "f6a9fe27128a38f74d92cfaa0d0d0d8333af989d"
  :revdesc "f6a9fe27128a"
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
