;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tramp-rpc" "0.12.0"
  "TRAMP backend using RPC."
  '((emacs   "30.1")
    (msgpack "0.1.1")
    (tramp   "2.8.1.4"))
  :url "https://github.com/ArthurHeymans/emacs-tramp-rpc"
  :commit "f111d16db3ff2ce85cd5489144be30a2336628cf"
  :revdesc "v0.12.0-0-gf111d16db3ff"
  :keywords '("comm" "processes" "files")
  :authors '(("Arthur Heymans" . "arthur@aheymans.xyz"))
  :maintainers '(("Arthur Heymans" . "arthur@aheymans.xyz")))
