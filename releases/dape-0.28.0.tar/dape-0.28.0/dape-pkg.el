;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.28.0"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "c0c5c83cfd0748a8b86f99bcd8ed936169bf3f04"
  :revdesc "c0c5c83cfd07"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
