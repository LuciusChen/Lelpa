;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.67.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b0330a90b46fde82c47122add00d4440cef35711"
  :revdesc "b0330a90b46f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
