;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.33.0"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "ffc09771df99a204f7716de12b7fae249db77298"
  :revdesc "ffc09771df99"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
