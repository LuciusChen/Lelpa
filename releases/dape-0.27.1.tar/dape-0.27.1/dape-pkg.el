;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "4b32b356fbb41b3934e68e966513cc07a252994d"
  :revdesc "4b32b356fbb4"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
