;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-mode" "1.0.7"
  "Colorize color names in buffers."
  ()
  :url "https://github.com/emacs-straight/rainbow-mode"
  :commit "8af64da0a3d6d27ae7265e3d74b212a19763a406"
  :revdesc "8af64da0a3d6"
  :keywords '("faces")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
