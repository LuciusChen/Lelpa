;;; ytm-radio.el --- YouTube Music audio launcher -*- lexical-binding: t; -*-

;; Author: Lucius Chen
;; URL: https://github.com/luciuschen/ytm-radio
;; Package-Version: 0.1.10
;; Package-Revision: 02729552a661
;; Package-Requires: ((emacs "29.1") (transient "0.3.7"))
;; Keywords: multimedia
;; SPDX-License-Identifier: GPL-3.0-or-later
;; Assisted-by: OpenAI Codex

;;; Commentary:

;; ytm-radio is a small Emacs audio player for YouTube and YouTube Music
;; URLs.  It relies on yt-dlp for source discovery and mpv for playback.

;;; Code:

(require 'button)
(require 'cl-lib)
(require 'imenu)
(require 'json)
(require 'map)
(require 'seq)
(require 'subr-x)
(require 'svg nil t)
(require 'transient)
(require 'url)
(require 'url-parse)

(defvar text-scale-mode)
(defvar text-scale-mode-amount)
(defvar text-scale-mode-step)

(defconst ytm-radio--directory
  (file-name-directory (or load-file-name buffer-file-name default-directory))
  "Directory containing the loaded ytm-radio package.")

(defun ytm-radio--helper-executable-name ()
  "Return the helper executable file name for the current platform."
  (if (eq system-type 'windows-nt)
      "ytm-radio-helper.exe"
    "ytm-radio-helper"))

(defconst ytm-radio--default-helper-command
  (expand-file-name (concat "helper/target/debug/"
                            (ytm-radio--helper-executable-name))
                    ytm-radio--directory)
  "Default in-repository helper executable path.")

(defconst ytm-radio--state-version 1
  "Current durable state file version.")

(defconst ytm-radio--helper-schema-version 1
  "Supported helper JSON envelope schema version.")

(defconst ytm-radio--helper-protocol-version 1
  "Supported helper protocol version.")

(defconst ytm-radio--helper-version "0.1.10"
  "Helper binary version expected by this Elisp package.")

;;; Customization

(defgroup ytm-radio nil
  "Play YouTube and YouTube Music audio from Emacs."
  :group 'multimedia)

(defface ytm-radio-button
  '((t (:inherit link :underline nil)))
  "Face for clickable ytm-radio text without link underlines."
  :group 'ytm-radio)

(defface ytm-radio-item-title
  '((t (:inherit default :underline nil)))
  "Face for clickable ytm-radio item titles."
  :group 'ytm-radio)

(defface ytm-radio-section-title
  '((t (:inherit bold :underline nil)))
  "Face for ytm-radio source section headings."
  :group 'ytm-radio)

(defface ytm-radio-detail-title
  '((t (:inherit bold :underline nil)))
  "Face for ytm-radio detail header titles."
  :group 'ytm-radio)

(defface ytm-radio-header-active
  '((t (:inherit bold :underline nil)))
  "Face for the active ytm-radio browser header item."
  :group 'ytm-radio)

(defface ytm-radio-header-inactive
  '((t (:inherit shadow :underline nil)))
  "Face for inactive ytm-radio browser header items."
  :group 'ytm-radio)

(defface ytm-radio-header-logo
  '((t (:foreground "#ff0000" :weight bold :underline nil)))
  "Face for the YouTube logo in the ytm-radio browser header."
  :group 'ytm-radio)

(defface ytm-radio-child-frame-border
  '((((class color) (background light)) (:background "#8a8a8a"))
    (((class color) (background dark)) (:background "#6f6f6f"))
    (t (:background "gray50")))
  "Face for the now-playing child-frame border."
  :group 'ytm-radio)

(defface ytm-radio-progress-filled
  '((((class color) (background light)) (:foreground "#2f6f9f" :weight bold))
    (((class color) (background dark)) (:foreground "#f0c674" :weight bold))
    (t (:inherit bold)))
  "Face for the filled now-playing progress bar cells."
  :group 'ytm-radio)

(defface ytm-radio-explicit-badge
  '((t (:inherit mode-line :inverse-video t :weight bold :underline nil)))
  "Face for fallback explicit-content badges."
  :group 'ytm-radio)

(defface ytm-radio-side-window-title
  '((t (:inherit bold :underline nil)))
  "Face for the side-window now-playing track title."
  :group 'ytm-radio)

(defface ytm-radio-side-window-artist
  '((t (:inherit shadow :underline nil)))
  "Face for the side-window now-playing track artist."
  :group 'ytm-radio)

(defcustom ytm-radio-yt-dlp-program "yt-dlp"
  "Program name or path used to run yt-dlp."
  :type 'string
  :group 'ytm-radio)

(defcustom ytm-radio-mpv-program "mpv"
  "Program name or path used to run mpv."
  :type 'string
  :group 'ytm-radio)

(defcustom ytm-radio-yt-dlp-extra-args nil
  "Extra arguments passed to yt-dlp when fetching source metadata."
  :type '(repeat string)
  :group 'ytm-radio)

(defcustom ytm-radio-mpv-extra-args nil
  "Extra arguments passed to mpv before the media URL."
  :type '(repeat string)
  :group 'ytm-radio)

(defcustom ytm-radio-mpv-network-cache-args
  '("--cache=yes"
    "--cache-pause=no"
    "--demuxer-readahead-secs=60"
    "--demuxer-max-bytes=256MiB")
  "Default mpv cache arguments used for long network tracks.
These arguments are placed before `ytm-radio-mpv-extra-args', so user-supplied
extra arguments can override them."
  :type '(repeat string)
  :group 'ytm-radio)

(defcustom ytm-radio-mpv-ytdl-format "bestaudio/best"
  "Default mpv ytdl format used when playing YouTube URLs.
The default avoids resolving and selecting video streams for audio-only
playback.  Set nil to let mpv choose its own ytdl format."
  :type '(choice (const :tag "mpv default" nil)
                 string)
  :group 'ytm-radio)

(defcustom ytm-radio-stream-prefetch-limit 1
  "Maximum number of upcoming tracks to pre-resolve for faster playback.
Prefetching runs in the background and keeps direct audio stream URLs in memory
only.  Set to 0 to disable stream prefetching."
  :type 'natnum
  :group 'ytm-radio)

(defcustom ytm-radio-seek-step 15
  "Default seek step in seconds for forward and backward commands."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (numberp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-ytdl-raw-options nil
  "Raw ytdl options passed to mpv's ytdl hook.
Each string should be in mpv's `--ytdl-raw-options' item form, for
example \"cookies-from-browser=chrome\"."
  :type '(repeat string)
  :group 'ytm-radio)

(defcustom ytm-radio-proxy-url nil
  "Proxy URL used for YouTube Music network requests.
When non-nil, this is passed to yt-dlp, mpv's ytdl hook, and the Rust helper.
HTTP and HTTPS proxy URLs are also passed to cover downloads and mpv's direct
media transport.
When the helper starts a Chromium-compatible login browser, it also passes this
proxy to that browser."
  :type '(choice (const :tag "No proxy" nil)
                 string)
  :group 'ytm-radio)

(defcustom ytm-radio-helper-command
  ytm-radio--default-helper-command
  "External helper executable used to fetch account data."
  :type 'file
  :group 'ytm-radio)

(defcustom ytm-radio-data-directory
  (expand-file-name "~/.ytm-radio/")
  "Directory used for ytm-radio runtime data."
  :type 'directory
  :group 'ytm-radio)

(defcustom ytm-radio-helper-install-directory
  (expand-file-name "bin/" ytm-radio-data-directory)
  "Directory used by `ytm-radio-install-helper' for helper binaries."
  :type 'directory
  :group 'ytm-radio)

(defcustom ytm-radio-helper-offer-install t
  "Whether missing default helpers should offer release installation."
  :type 'boolean
  :group 'ytm-radio)

(defcustom ytm-radio-helper-release-base-url
  "https://github.com/LuciusChen/ytm-radio/releases/download/"
  "Base URL before the version tag used to download helper releases."
  :type 'string
  :group 'ytm-radio)

(defcustom ytm-radio-helper-auth-file
  (expand-file-name "auth.json" ytm-radio-data-directory)
  "Authentication file passed to `ytm-radio-helper-command'.
The file contents are never persisted in ytm-radio state."
  :type 'file
  :group 'ytm-radio)

(defcustom ytm-radio-helper-login-browser nil
  "Browser executable or known browser name used for account login.
When nil, the helper uses the system default browser when it supports a
known login flow.  Chromium-based browsers use DevTools; Firefox and Zen use
WebDriver BiDi."
  :type '(choice (const :tag "Auto" nil)
                 string)
  :group 'ytm-radio)

(defcustom ytm-radio-helper-login-profile-directory
  nil
  "Optional isolated browser profile directory used for account login.
When nil, the helper uses browser-specific defaults.  Chrome, Firefox, and Zen
use helper-managed non-default profiles for their remote-control login flows."
  :type '(choice (const :tag "Use helper/browser default profile" nil)
                 directory)
  :group 'ytm-radio)

(defcustom ytm-radio-helper-login-cdp-port 29317
  "Local browser remote-control port used for account login."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (<= 1 value 65535)))))
  :group 'ytm-radio)

(defcustom ytm-radio-helper-login-timeout 180
  "Seconds the account login flow waits for browser sign-in to finish."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (< 0 value)))))
  :group 'ytm-radio)

(defcustom ytm-radio-helper-library-limit 100
  "Maximum number of library items requested from the helper."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-helper-home-limit 12
  "Maximum number of items requested for each home recommendation section."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-home-lazy-load-margin 4
  "Number of lines from the bottom that trigger Home lazy loading."
  :type 'natnum
  :group 'ytm-radio)

(defcustom ytm-radio-state-file
  (expand-file-name "state.eld" ytm-radio-data-directory)
  "File used to persist ytm-radio sources and last track."
  :type 'file
  :group 'ytm-radio)

(defcustom ytm-radio-display-style 'child-frame
  "Preferred display style for the now-playing view.
The `side-window' style installs a compact top side window on the frame."
  :type '(choice (const :tag "Child frame" child-frame)
          (const :tag "Top side window" side-window)
          (const :tag "Regular buffer" buffer))
  :group 'ytm-radio)

(defcustom ytm-radio-auto-show-now-playing t
  "Whether track changes automatically show the now-playing view.
This only controls automatic display during playback changes.  Manual calls to
`ytm-radio-now-playing' still show or hide the now-playing view."
  :type 'boolean
  :group 'ytm-radio)

(defcustom ytm-radio-child-frame-draggable t
  "Whether graphical now-playing child frames can be dragged with the mouse."
  :type 'boolean
  :group 'ytm-radio)

(defcustom ytm-radio-side-window-height 1
  "Height in lines of the side-window now-playing view.
Graphical side windows use at least two lines to avoid clipping cover images
and larger fonts."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-side-window-cover-size 34
  "Displayed side-window cover image edge size in pixels."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-side-window-title-width 32
  "Fallback title width in columns for the side-window now-playing view."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-child-frame-width 34
  "Fallback width of the now-playing child frame in character columns.
The frame normally fits itself to the displayed cover image."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-cover-cache-directory
  (expand-file-name "covers/" ytm-radio-data-directory)
  "Directory used to cache YouTube Music cover images."
  :type 'directory
  :group 'ytm-radio)

(defcustom ytm-radio-cover-max-width 200
  "Displayed now-playing cover image width in pixels."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-cover-max-height 180
  "Maximum displayed cover image height in pixels."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-browser-thumbnail-size 48
  "Maximum thumbnail size in pixels for items in the browser buffer."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-browser-thumbnail-layout 'split
  "The browser thumbnail layout for two-line items.
The value `split' slices the thumbnail across title and detail rows.
The value `first-line' places the thumbnail on the title row and reserves
thumbnail-width space on the detail row."
  :type '(choice
          (const :tag "Split across title and detail rows" split)
          (const :tag "Title row only" first-line))
  :group 'ytm-radio)

(defcustom ytm-radio-browser-item-line-height-scale 1.10
  "Scale applied to browser item row height.
Values above 1 add visual breathing room without inserting extra logical
rows.  Thumbnail content follows the scaled row height.  In `first-line'
layout, the same scale also adds visual space between item blocks."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (numberp value) (>= value 1.0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-browser-thumbnail-workaround-gaps t
  "Non-nil to render browser thumbnails through a fixed SVG canvas.
This mirrors telega's avatar gap workaround: the image is first placed
inside a fixed two-line canvas, then the canvas is sliced per text row.
It avoids row gaps and keeps non-square YouTube thumbnails from being
cropped or shifting the following text."
  :type 'boolean
  :group 'ytm-radio)

(defcustom ytm-radio-browser-thumbnail-downloads-per-render 8
  "Maximum thumbnail downloads started during one browser render.
When nil, thumbnail downloads are uncapped per render."
  :type '(choice
          (const :tag "No per-render cap" nil)
          natnum)
  :group 'ytm-radio)

(defcustom ytm-radio-browser-header-height 176
  "Displayed height in pixels for detail header cover images."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (integerp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-progress-refresh-interval 0.25
  "Minimum seconds between now-playing progress redraws."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (numberp value) (> value 0)))))
  :group 'ytm-radio)

(defcustom ytm-radio-title-scroll-interval 0.7
  "Seconds between now-playing title marquee updates."
  :type '(restricted-sexp
          :match-alternatives
          ((lambda (value)
             (and (numberp value) (> value 0)))))
  :group 'ytm-radio)

(defconst ytm-radio--now-playing-cover-left-padding-pixels 7
  "Left padding in pixels before now-playing cover images.")

(defconst ytm-radio--now-playing-cover-right-padding-pixels 5
  "Right padding in pixels after now-playing cover images.")

(defconst ytm-radio--now-playing-thin-padding
  (propertize "\n" 'display '((height 0.25)))
  "Thin vertical padding used inside the now-playing child frame.")

(defconst ytm-radio--now-playing-top-padding
  (propertize "\n" 'display '((height 0.5)))
  "Top vertical padding used inside the now-playing child frame.")

(defconst ytm-radio--now-playing-bottom-padding
  (propertize "\n" 'display '((height 0.5)))
  "Bottom vertical padding used inside the now-playing child frame.")

(defconst ytm-radio--browser-heading-padding
  (propertize "\n" 'display '((height 0.25)))
  "Thin vertical padding used below browser headings.")

(defconst ytm-radio--detail-header-cover-slice-overlap 1
  "Pixels of overlap between adjacent detail header cover slices.")

(defconst ytm-radio--detail-header-row-height-padding-ratio 0.25
  "Extra detail header row height ratio for fallback font line boxes.")

;;; State

(cl-defun ytm-radio--make-track
    (&key id title url duration artist album thumbnail-url source-id source-kind
          like-status in-library account-auth explicit)
  "Return a track alist.
ID, TITLE, URL, DURATION, ARTIST, ALBUM, THUMBNAIL-URL, SOURCE-ID,
SOURCE-KIND, LIKE-STATUS, IN-LIBRARY, ACCOUNT-AUTH, and EXPLICIT are stored as
stable track fields."
  (list (cons :id id)
        (cons :title title)
        (cons :url url)
        (cons :duration duration)
        (cons :artist artist)
        (cons :album album)
        (cons :thumbnail-url thumbnail-url)
        (cons :source-id source-id)
        (cons :source-kind source-kind)
        (cons :like-status like-status)
        (cons :in-library in-library)
        (cons :account-auth account-auth)
        (cons :explicit explicit)))

(cl-defun ytm-radio--make-source
    (&key id kind title url tracks items continuation subtitle thumbnail-url
          in-library subscribed playlist-id in-library-known subscribed-known)
  "Return a source alist.
ID, KIND, TITLE, URL, TRACKS, ITEMS, CONTINUATION, SUBTITLE, and
THUMBNAIL-URL are stable source fields.  IN-LIBRARY and SUBSCRIBED are
account state fields when YouTube Music exposes them.  PLAYLIST-ID is
the underlying YouTube Music playlist id when available.  IN-LIBRARY-KNOWN and
SUBSCRIBED-KNOWN mark explicit false account states."
  (list (cons :id id)
        (cons :kind kind)
        (cons :title title)
        (cons :url url)
        (cons :tracks tracks)
        (cons :items items)
        (cons :continuation continuation)
        (cons :subtitle subtitle)
        (cons :thumbnail-url thumbnail-url)
        (cons :in-library in-library)
        (cons :subscribed subscribed)
        (cons :playlist-id playlist-id)
        (cons :in-library-known in-library-known)
        (cons :subscribed-known subscribed-known)))

(cl-defun ytm-radio--make-player
    (&key (status 'idle) current-track process ipc-process socket position
          duration repeat shuffle queue queue-index playback-url
          using-stream-cache retry-stage)
  "Return a player alist.
STATUS, CURRENT-TRACK, PROCESS, IPC-PROCESS, SOCKET, POSITION,
DURATION, REPEAT, SHUFFLE, QUEUE, QUEUE-INDEX, PLAYBACK-URL,
USING-STREAM-CACHE, and RETRY-STAGE are ephemeral runtime fields."
  (list (cons :status status)
        (cons :current-track current-track)
        (cons :process process)
        (cons :ipc-process ipc-process)
        (cons :socket socket)
        (cons :position position)
        (cons :duration duration)
        (cons :repeat repeat)
        (cons :shuffle shuffle)
        (cons :queue queue)
        (cons :queue-index queue-index)
        (cons :playback-url playback-url)
        (cons :using-stream-cache using-stream-cache)
        (cons :retry-stage retry-stage)))

(cl-defun ytm-radio--make-state
    (&key sources last-track-id home-continuation home-continuation-known)
  "Return the durable package state.
SOURCES, LAST-TRACK-ID, HOME-CONTINUATION, and HOME-CONTINUATION-KNOWN are
stored in `ytm-radio-state-file'."
  (list (cons :sources sources)
        (cons :last-track-id last-track-id)
        (cons :home-continuation home-continuation)
        (cons :home-continuation-known home-continuation-known)))

(defvar ytm-radio--state (ytm-radio--make-state)
  "Durable state for sources and the last played track.")

(defvar ytm-radio--player (ytm-radio--make-player)
  "Ephemeral player state for mpv processes and sockets.")

(defun ytm-radio--repeat-mode ()
  "Return the current repeat mode."
  (map-elt ytm-radio--player :repeat))

(defvar ytm-radio--loaded nil
  "Non-nil once durable state has been loaded.")

(defconst ytm-radio--library-buffer-name "*ytm-radio*"
  "Buffer name for the ytm-radio browser.")

(defconst ytm-radio--now-playing-buffer-name "*ytm-radio-now-playing*"
  "Buffer name for the ytm-radio now-playing child frame.")

(defconst ytm-radio--doctor-buffer-name "*ytm-radio-doctor*"
  "Buffer name for ytm-radio setup diagnostics.")

(defvar ytm-radio--frame nil
  "Child frame currently showing the now-playing buffer.")

(defvar ytm-radio--frame-manual-position nil
  "Manual pixel position for the now-playing child frame.")

(defconst ytm-radio--frame-border-width 1
  "Width in pixels of the now-playing child-frame border.")

(defvar ytm-radio--side-window nil
  "Top side window currently showing the now-playing buffer.")

(defvar ytm-radio--cover-render-width nil
  "Temporary cover image width used while rendering now-playing.")

(defvar ytm-radio--inhibit-frame-fit nil
  "Non-nil means rendering should not resize the now-playing frame.")

(defvar ytm-radio--progress-render-timer nil
  "Timer used to throttle now-playing progress refreshes.")

(defvar ytm-radio--last-rendered-progress-key nil
  "Progress state last rendered in the now-playing view.")

(defvar ytm-radio--title-scroll-timer nil
  "Timer used to animate long now-playing titles.")

(defvar ytm-radio--title-scroll-offset 0
  "Current display-column offset for the now-playing title marquee.")

(defvar ytm-radio--title-scroll-key nil
  "Track and width key for the current now-playing title marquee.")

(defvar ytm-radio--cover-downloads (make-hash-table :test #'equal)
  "Cover image URLs currently being fetched, mapped to completion callbacks.")

(defvar ytm-radio--image-dimensions-cache (make-hash-table :test #'equal)
  "Cached image dimensions keyed by local file attributes.")

(defvar ytm-radio--thumbnail-image-cache (make-hash-table :test #'equal)
  "Cached browser thumbnail image objects keyed by file and display size.")

(defconst ytm-radio--image-memory-cache-limit 256
  "Maximum entries retained in each decoded image memory cache.")

(defun ytm-radio--cache-image-value (cache key value)
  "Store VALUE under KEY in image CACHE with a fixed memory bound."
  (when (>= (hash-table-count cache) ytm-radio--image-memory-cache-limit)
    (clrhash cache))
  (puthash key value cache))

(defvar ytm-radio--browser-thumbnail-state-cache (make-hash-table :test #'equal)
  "Mutable browser thumbnail descriptors keyed by URL and display settings.")

(defvar ytm-radio--browser-thumbnail-state-keys-by-url
  (make-hash-table :test #'equal)
  "Browser thumbnail state cache keys grouped by thumbnail URL.")

(defvar ytm-radio--browser-thumbnail-pending-urls nil
  "Thumbnail URLs visible in the browser but not yet scheduled for download.")

(defvar ytm-radio--browser-thumbnail-download-budget nil
  "Dynamic cap for thumbnail downloads started in the current render pass.")

(defvar ytm-radio--stream-url-cache (make-hash-table :test #'equal)
  "Direct audio stream URLs cached by track id or URL.")

(defvar ytm-radio--stream-prefetch-queue nil
  "Tracks waiting for background direct stream URL resolution.")

(defvar ytm-radio--stream-prefetch-process nil
  "Current asynchronous stream prefetch process.")

(defvar ytm-radio--playback-resolve-process nil
  "Current authenticated stream resolver for immediate playback.")

(defvar ytm-radio--track-status-refreshes (make-hash-table :test #'equal)
  "Track status requests keyed by video id and completion time.")

(defconst ytm-radio--track-status-refresh-ttl 300
  "Seconds before a completed track account status may be refreshed again.")

(defconst ytm-radio--account-state-missing (make-symbol "account-state-missing")
  "Sentinel used when no runtime account state is known.")

(defvar ytm-radio--account-state-index (make-hash-table :test #'equal)
  "Runtime account state keyed by state kind and stable YouTube id.")

(defvar ytm-radio--account-state-owner nil
  "Durable state object represented by `ytm-radio--account-state-index'.")

(defvar ytm-radio--browser-view 'home
  "Current ytm-radio browser view.")

(defvar ytm-radio--browser-history nil
  "Stack of previous ytm-radio browser views.")

(defvar ytm-radio--root-view-positions nil
  "Alist of remembered positions for Home, Explore, and Library views.")

(defvar ytm-radio--browser-loading-message nil
  "Transient loading message shown while replacing browser view content.")

(defvar ytm-radio--browser-loading-view nil
  "Browser view currently associated with `ytm-radio--browser-loading-message'.")

(defvar ytm-radio--browser-load-process nil
  "Current asynchronous non-Home helper process.")

(defvar ytm-radio--browser-load-token nil
  "Identity token for the current asynchronous non-Home helper request.")

(defvar ytm-radio--add-url-process nil
  "Current asynchronous URL import process.")

(defvar ytm-radio--login-process nil
  "Current asynchronous YouTube Music login helper process.")

(defvar ytm-radio--login-continuation nil
  "Action to run after the current YouTube Music login succeeds.")

(defvar ytm-radio--login-status nil
  "Current YouTube Music login status for the browser header line.")

(defvar ytm-radio--initial-home-refreshed nil
  "Non-nil once Home has been refreshed on first browser open.")

(defun ytm-radio--home-continuation ()
  "Return the continuation token for loading more Home sections."
  (map-elt ytm-radio--state :home-continuation))

(defun ytm-radio--set-home-continuation (continuation)
  "Set Home CONTINUATION in durable state."
  (setf (map-elt ytm-radio--state :home-continuation) continuation
        (map-elt ytm-radio--state :home-continuation-known) t))

(defun ytm-radio--home-continuation-known-p ()
  "Return non-nil when Home continuation state is known."
  (map-elt ytm-radio--state :home-continuation-known))

(defvar ytm-radio--home-loading nil
  "Non-nil while Home is loading asynchronously.")

(defvar ytm-radio--home-process nil
  "Current asynchronous Home helper process.")

(defvar ytm-radio--home-load-token nil
  "Identity token for the current asynchronous Home helper request.")

(defconst ytm-radio--browser-section-limit 8
  "Maximum items shown per source in overview browser views.")

(defun ytm-radio--container-list-source-id-p (id)
  "Return non-nil when ID identifies a Library container-list source."
  (and (stringp id)
       (or (string-prefix-p "ytm:library:albums" id)
           (string-prefix-p "ytm:library:artists" id)
           (string-prefix-p "ytm:library:playlists" id))))

(defun ytm-radio--container-list-source-p (source)
  "Return non-nil when SOURCE should display only helper items."
  (ytm-radio--container-list-source-id-p (map-elt source :id)))

(defun ytm-radio--raw-item-field (item key)
  "Return ITEM field KEY, accepting plain or keyword alist keys."
  (or (map-elt item key)
      (map-elt item (intern (concat ":" (symbol-name key))))))

(defun ytm-radio--container-list-item-type (item)
  "Return the durable Library container type for ITEM, or nil."
  (let ((browse-id (ytm-radio--raw-item-field item 'browse-id))
        (playlist-id (ytm-radio--raw-item-field item 'playlist-id)))
    (cond
     ((and (stringp browse-id) (string-prefix-p "MPRE" browse-id))
      "album")
     ((and (stringp browse-id) (string-prefix-p "UC" browse-id))
      "artist")
     ((and (stringp browse-id)
           (or (string-prefix-p "VL" browse-id)
               (string-prefix-p "PL" browse-id)
               (string-prefix-p "RD" browse-id)))
      "playlist")
     ((stringp playlist-id)
      "playlist"))))

(defun ytm-radio--set-item-field (item key value)
  "Set ITEM field KEY to VALUE, preserving existing key style when present."
  (let ((keyword (intern (concat ":" (symbol-name key)))))
    (cond
     ((assq key item)
      (setf (map-elt item key) value))
     ((assq keyword item)
      (setf (map-elt item keyword) value))
     (t
      (setf (map-elt item key) value))))
  item)

(defun ytm-radio--sanitize-container-list-item (item)
  "Return ITEM after normalizing stale Library container metadata."
  (if-let* ((type (ytm-radio--container-list-item-type item)))
      (ytm-radio--set-item-field item 'type type)
    item))

(defun ytm-radio--sanitize-source (source)
  "Return SOURCE after clearing stale generated fields."
  (when (ytm-radio--container-list-source-p source)
    (setf (map-elt source :tracks) nil)
    (setf (map-elt source :items)
          (mapcar #'ytm-radio--sanitize-container-list-item
                  (or (map-elt source :items) nil))))
  source)

(defun ytm-radio--sanitize-source-cell (cell)
  "Return durable source CELL after sanitizing its source."
  (cons (car cell) (ytm-radio--sanitize-source (cdr cell))))

(defun ytm-radio--sources ()
  "Return the current source alist."
  (let ((sources (or (map-elt ytm-radio--state :sources) nil)))
    (when sources
      (setq sources (mapcar #'ytm-radio--sanitize-source-cell sources))
      (setf (map-elt ytm-radio--state :sources) sources))
    sources))

(defun ytm-radio--source (id)
  "Return the source with ID, or nil."
  (cdr (assoc id (ytm-radio--sources))))

(defun ytm-radio--index-account-state (kind ids value)
  "Index account VALUE of KIND under each stable id in IDS."
  (dolist (id ids)
    (when (and (stringp id) (not (string-empty-p id)))
      (puthash (cons kind id) value ytm-radio--account-state-index))))

(defun ytm-radio--index-account-state-observation (kind ids value)
  "Merge observed account VALUE of KIND under IDS.
Positive source observations take precedence over negative cached snapshots."
  (dolist (id ids)
    (when (and (stringp id) (not (string-empty-p id)))
      (let* ((key (cons kind id))
             (current (gethash key ytm-radio--account-state-index
                               ytm-radio--account-state-missing)))
        (when (or value (eq current ytm-radio--account-state-missing))
          (puthash key value ytm-radio--account-state-index))))))

(defun ytm-radio--ensure-account-state-index ()
  "Ensure the runtime account index represents the current durable state."
  (unless (eq ytm-radio--account-state-owner ytm-radio--state)
    (clrhash ytm-radio--account-state-index)
    (setq ytm-radio--account-state-owner ytm-radio--state)
    (dolist (source (map-values (ytm-radio--sources)))
      (ytm-radio--index-source-account-state source))))

(defun ytm-radio--account-state (kind ids)
  "Return account state of KIND for IDS, or the missing-state sentinel."
  (ytm-radio--ensure-account-state-index)
  (catch 'value
    (dolist (id ids ytm-radio--account-state-missing)
      (let* ((key (cons kind id))
             (value (gethash key ytm-radio--account-state-index
                             ytm-radio--account-state-missing)))
        (unless (eq value ytm-radio--account-state-missing)
          (throw 'value value))))))

(defun ytm-radio--set-account-state (kind ids value)
  "Set runtime account VALUE of KIND for each stable id in IDS."
  (ytm-radio--ensure-account-state-index)
  (ytm-radio--index-account-state kind ids value))

(defun ytm-radio--put-source (source)
  "Insert or replace SOURCE in `ytm-radio--state'."
  (ytm-radio--ensure-account-state-index)
  (let* ((source (ytm-radio--sanitize-source source))
         (id (map-elt source :id))
         (sources (ytm-radio--sources))
         (cell (assoc id sources)))
    (if cell
        (setcdr cell source)
      (setq sources (append sources (list (cons id source))))
      (setf (map-elt ytm-radio--state :sources) sources))
    (ytm-radio--index-source-account-state source)))

(defun ytm-radio--source-tracks (source)
  "Return playable tracks for SOURCE."
  (unless (ytm-radio--container-list-source-p source)
    (or (map-elt source :tracks) nil)))

(defun ytm-radio--all-tracks ()
  "Return all known tracks in source order."
  (seq-mapcat (lambda (source)
                (ytm-radio--source-tracks source))
              (map-values (ytm-radio--sources))
              'list))

(defun ytm-radio--empty-catalog-p ()
  "Return non-nil when no source has been added."
  (null (ytm-radio--sources)))

(defun ytm-radio--track (id)
  "Return the known track with ID, or nil."
  (seq-find (lambda (track)
              (equal (map-elt track :id) id))
            (ytm-radio--all-tracks)))

(defun ytm-radio--current-track ()
  "Return the current player track, falling back to the last track."
  (or (map-elt ytm-radio--player :current-track)
      (ytm-radio--track (map-elt ytm-radio--state :last-track-id))))

(defun ytm-radio--save ()
  "Persist durable state to `ytm-radio-state-file'."
  (make-directory (file-name-directory ytm-radio-state-file) t)
  (with-temp-file ytm-radio-state-file
    (prin1 (list (cons :version ytm-radio--state-version)
                 (cons :sources (map-elt ytm-radio--state :sources))
                 (cons :last-track-id
	                       (map-elt ytm-radio--state :last-track-id))
                 (cons :home-continuation
                       (map-elt ytm-radio--state :home-continuation)))
	           (current-buffer))))

(defun ytm-radio--state-track-p (track)
  "Return non-nil when TRACK has the durable track shape."
  (and (listp track)
       (or (stringp (map-elt track :id))
           (stringp (map-elt track :url)))
       (or (null (map-elt track :title))
           (stringp (map-elt track :title)))
       (or (null (map-elt track :url))
           (stringp (map-elt track :url)))))

(defun ytm-radio--state-source-p (cell)
  "Return non-nil when CELL has the durable source shape."
  (let ((source (cdr-safe cell)))
    (and (consp cell)
         (stringp (car cell))
         (listp source)
         (equal (car cell) (map-elt source :id))
         (symbolp (map-elt source :kind))
         (or (null (map-elt source :title))
             (stringp (map-elt source :title)))
         (or (null (map-elt source :url))
             (stringp (map-elt source :url)))
         (listp (map-elt source :tracks))
         (seq-every-p #'ytm-radio--state-track-p
                      (or (map-elt source :tracks) nil))
         (listp (map-elt source :items)))))

(defun ytm-radio--state-data-p (data)
  "Return non-nil when DATA has the supported durable state shape."
  (and (listp data)
       (equal (map-elt data :version) ytm-radio--state-version)
       (listp (map-elt data :sources))
       (seq-every-p #'ytm-radio--state-source-p
                    (or (map-elt data :sources) nil))
       (or (null (map-elt data :last-track-id))
           (stringp (map-elt data :last-track-id)))
       (or (not (assq :home-continuation data))
           (null (map-elt data :home-continuation))
           (stringp (map-elt data :home-continuation)))))

(defun ytm-radio--read-state-file ()
  "Read and validate `ytm-radio-state-file'."
  (let* ((read-eval-symbol (intern "read-eval"))
         (read-eval-bound (boundp read-eval-symbol))
         (old-read-eval (and read-eval-bound
                             (symbol-value read-eval-symbol)))
         data)
    (unwind-protect
        (progn
          (set read-eval-symbol nil)
          (setq data
                (with-temp-buffer
                  (insert-file-contents ytm-radio-state-file)
                  (read (current-buffer)))))
      (if read-eval-bound
          (set read-eval-symbol old-read-eval)
        (makunbound read-eval-symbol)))
    (unless (equal (map-elt data :version) ytm-radio--state-version)
      (user-error "Unsupported ytm-radio state version %S"
                  (map-elt data :version)))
    (unless (ytm-radio--state-data-p data)
      (user-error "Invalid ytm-radio state file %s" ytm-radio-state-file))
    data))

(defun ytm-radio--load ()
  "Load durable state from `ytm-radio-state-file'."
  (when (file-exists-p ytm-radio-state-file)
    (let ((data (ytm-radio--read-state-file)))
      (setq ytm-radio--state
            (ytm-radio--make-state
             :sources (mapcar #'ytm-radio--sanitize-source-cell
                              (map-elt data :sources))
             :last-track-id (map-elt data :last-track-id)
             :home-continuation (map-elt data :home-continuation)
             :home-continuation-known
             (and (assq :home-continuation data) t))))))

(defun ytm-radio--ensure-loaded ()
  "Load durable state once for the current Emacs session."
  (unless ytm-radio--loaded
    (ytm-radio--load)
    (setq ytm-radio--loaded t)))

;;; Source fetching

(defun ytm-radio--ensure-program (program label)
  "Signal a user error unless PROGRAM named LABEL is executable."
  (cond
   ((or (not (stringp program))
        (string-empty-p program))
    (user-error "%s program is not configured" label))
   ((file-name-absolute-p program)
    (unless (file-executable-p program)
      (user-error "Cannot execute %s at %s" label program)))
   ((not (executable-find program))
    (user-error "Cannot find %s (%s) in `exec-path'" label program))))

(defun ytm-radio--program-executable-p (program)
  "Return non-nil when PROGRAM is executable."
  (and (stringp program)
       (not (string-empty-p program))
       (if (file-name-absolute-p program)
           (file-executable-p program)
         (executable-find program))))

(defun ytm-radio--installed-helper-command ()
  "Return the helper path installed by `ytm-radio-install-helper'."
  (expand-file-name (ytm-radio--helper-executable-name)
                    ytm-radio-helper-install-directory))

(defun ytm-radio--helper-command ()
  "Return the helper executable path to use."
  (let ((installed (ytm-radio--installed-helper-command)))
    (cond
     ((ytm-radio--program-executable-p ytm-radio-helper-command)
      ytm-radio-helper-command)
     ((and (equal ytm-radio-helper-command ytm-radio--default-helper-command)
           (file-executable-p installed))
      installed)
     (t ytm-radio-helper-command))))

(defun ytm-radio--helper-install-offer-allowed-p ()
  "Return non-nil when a missing helper can offer release installation."
  (and ytm-radio-helper-offer-install
       (not noninteractive)
       (equal ytm-radio-helper-command ytm-radio--default-helper-command)))

(defun ytm-radio--helper-release-target ()
  "Return the release helper target for the current platform."
  (let ((configuration system-configuration))
    (cond
     ((and (eq system-type 'darwin)
           (string-match-p "\\(?:aarch64\\|arm64\\)" configuration))
      "aarch64-apple-darwin")
     ((and (eq system-type 'darwin)
           (string-match-p "\\(?:x86_64\\|amd64\\)" configuration))
      "x86_64-apple-darwin")
     ((and (eq system-type 'gnu/linux)
           (string-match-p "\\(?:x86_64\\|amd64\\)" configuration))
      "x86_64-unknown-linux-gnu")
     ((and (eq system-type 'windows-nt)
           (string-match-p "\\(?:x86_64\\|amd64\\)" configuration))
      "x86_64-pc-windows-msvc")
     (t
      (user-error "No ytm-radio helper release is available for %s"
                  configuration)))))

(defun ytm-radio--helper-release-asset-name ()
  "Return the helper release asset name for the current platform."
  (concat "ytm-radio-helper-"
          (ytm-radio--helper-release-target)
          (when (eq system-type 'windows-nt) ".exe")))

(defun ytm-radio--helper-release-url ()
  "Return the helper release download URL for the current platform."
  (concat (if (string-suffix-p "/" ytm-radio-helper-release-base-url)
              ytm-radio-helper-release-base-url
            (concat ytm-radio-helper-release-base-url "/"))
          "v" ytm-radio--helper-version "/"
          (ytm-radio--helper-release-asset-name)))

(defun ytm-radio--helper-release-checksum-url ()
  "Return the SHA-256 checksum URL for the current helper release."
  (concat (ytm-radio--helper-release-url) ".sha256"))

(defun ytm-radio--file-sha256 (file)
  "Return the lowercase SHA-256 digest of FILE."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally file)
    (secure-hash 'sha256 (current-buffer))))

(defun ytm-radio--read-sha256-file (file)
  "Return the first SHA-256 digest recorded in FILE."
  (with-temp-buffer
    (insert-file-contents file)
    (goto-char (point-min))
    (unless (looking-at
             "[[:space:]]*\\([[:xdigit:]]\\{64\\}\\)\\(?:[[:space:]]\\|\\'\\)")
      (user-error "Invalid helper checksum file"))
    (downcase (match-string 1))))

(defun ytm-radio--verify-helper-checksum (helper checksum-file)
  "Verify HELPER against CHECKSUM-FILE or signal a user error."
  (let ((expected (ytm-radio--read-sha256-file checksum-file))
        (actual (ytm-radio--file-sha256 helper)))
    (unless (string-equal expected actual)
      (user-error "Helper SHA-256 mismatch: expected %s, got %s"
                  expected actual))))

(defun ytm-radio--copy-url-to-file (url file)
  "Copy URL to FILE, replacing FILE when it exists."
  (url-copy-file url file t))

;;;###autoload
(defun ytm-radio-install-helper (&optional force)
  "Download and install the ytm-radio helper release binary.
With prefix argument FORCE, replace an existing installed helper without
prompting."
  (interactive "P")
  (let* ((url (ytm-radio--helper-release-url))
         (checksum-url (ytm-radio--helper-release-checksum-url))
         (destination (ytm-radio--installed-helper-command))
         (temporary (make-temp-file "ytm-radio-helper-download-"))
         (checksum-file (make-temp-file "ytm-radio-helper-checksum-")))
    (when (and (file-exists-p destination)
               (not force)
               (not (y-or-n-p (format "Replace %s? " destination))))
      (user-error "Helper install cancelled"))
    (unwind-protect
        (progn
          (make-directory (file-name-directory destination) t)
          (message "Downloading ytm-radio helper from %s..." url)
          (ytm-radio--copy-url-to-file url temporary)
          (ytm-radio--copy-url-to-file checksum-url checksum-file)
          (ytm-radio--verify-helper-checksum temporary checksum-file)
          (set-file-modes temporary #o700)
          (rename-file temporary destination t)
          (setq ytm-radio-helper-command destination)
          (message "Installed ytm-radio helper to %s" destination)
          destination)
      (when (file-exists-p temporary)
        (delete-file temporary))
      (when (file-exists-p checksum-file)
        (delete-file checksum-file)))))

(defun ytm-radio--ensure-helper-command ()
  "Return an executable helper, installing the release after confirmation."
  (let ((program (ytm-radio--helper-command)))
    (condition-case error
        (progn
          (ytm-radio--ensure-program program "ytm-radio-helper")
          program)
      (user-error
       (let ((diagnostic (error-message-string error)))
         (if (and (ytm-radio--helper-install-offer-allowed-p)
                  (y-or-n-p
                   (format "Download %s for ytm-radio? "
                           (ytm-radio--helper-release-asset-name))))
             (ytm-radio-install-helper t)
           (user-error
            "%s. Run M-x ytm-radio-install-helper, build the helper with Cargo, or set `ytm-radio-helper-command'"
            diagnostic)))))))

(defun ytm-radio--doctor-program-path (program)
  "Return the executable path for PROGRAM, or nil."
  (when (and (stringp program)
             (not (string-empty-p program)))
    (if (file-name-absolute-p program)
        (when (file-executable-p program)
          (expand-file-name program))
      (executable-find program))))

(defun ytm-radio--doctor-status-line (label status detail)
  "Return a diagnostic line for LABEL with STATUS and DETAIL."
  (format "%-12s %s  %s" label status detail))

(defun ytm-radio--doctor-program-line (label program)
  "Return a diagnostic line for PROGRAM named LABEL."
  (if-let* ((path (ytm-radio--doctor-program-path program)))
      (ytm-radio--doctor-status-line label "OK" path)
    (ytm-radio--doctor-status-line
     label "MISSING" (or program "not configured"))))

(defun ytm-radio--doctor-helper-version-line ()
  "Return a diagnostic line for the helper protocol version."
  (let ((program (ytm-radio--helper-command)))
    (if (not (ytm-radio--program-executable-p program))
        (ytm-radio--doctor-status-line "protocol" "MISSING" "helper not executable")
      (let ((stdout (generate-new-buffer " *ytm-radio-version-stdout*")))
        (unwind-protect
            (let ((exit-code (process-file program nil
                                           (list stdout t)
                                           nil
                                           "version")))
              (if (not (zerop exit-code))
                  (ytm-radio--doctor-status-line
                   "protocol"
                   "ERROR"
                   (ytm-radio--trim-buffer stdout))
                (condition-case error
                    (let* ((envelope (ytm-radio--parse-json-buffer stdout))
                           (_data (ytm-radio--helper-envelope-data envelope)))
                      (ytm-radio--doctor-status-line
                       "protocol"
                       "OK"
                       (format "helper %s protocol %d"
                               (map-elt envelope 'helper-version)
                               (map-elt envelope 'protocol))))
                  (error
                   (ytm-radio--doctor-status-line
                    "protocol"
                    "ERROR"
                    (error-message-string error))))))
          (when (buffer-live-p stdout)
            (kill-buffer stdout)))))))

(defun ytm-radio--doctor-data-line ()
  "Return a diagnostic line for `ytm-radio-data-directory'."
  (let* ((directory (file-name-as-directory
                     (expand-file-name ytm-radio-data-directory)))
         (parent (file-name-directory (directory-file-name directory)))
         (writable (if (file-directory-p directory)
                       (file-writable-p directory)
                     (and parent (file-directory-p parent)
                          (file-writable-p parent)))))
    (ytm-radio--doctor-status-line
     "data-dir"
     (if writable "OK" "MISSING")
     (if (file-directory-p directory)
         directory
       (format "%s (will be created when needed)" directory)))))

(defun ytm-radio--doctor-auth-line ()
  "Return a diagnostic line for `ytm-radio-helper-auth-file'."
  (cond ((and ytm-radio-helper-auth-file
              (file-readable-p ytm-radio-helper-auth-file))
         (ytm-radio--doctor-status-line
          "auth" "OK" (expand-file-name ytm-radio-helper-auth-file)))
        (t
         (ytm-radio--doctor-status-line
          "auth" "MISSING"
          (or ytm-radio-helper-auth-file "not configured")))))

(defun ytm-radio--doctor-report ()
  "Return a setup diagnostic report for ytm-radio."
  (string-join
   (list
    "ytm-radio doctor"
    ""
    (ytm-radio--doctor-program-line "helper" (ytm-radio--helper-command))
    (ytm-radio--doctor-helper-version-line)
    (ytm-radio--doctor-program-line "mpv" ytm-radio-mpv-program)
    (ytm-radio--doctor-program-line "yt-dlp" ytm-radio-yt-dlp-program)
    (ytm-radio--doctor-data-line)
    (ytm-radio--doctor-auth-line)
    ""
    "Set YTM_RADIO_TIMINGS=1 before running Emacs to see helper timings in stderr.")
   "\n"))

(defun ytm-radio--trim-buffer (buffer)
  "Return BUFFER contents without surrounding whitespace."
  (with-current-buffer buffer
    (string-trim (buffer-string))))

(defun ytm-radio--process-buffer-diagnostic (stdout stderr)
  "Return diagnostic text from STDERR buffer, falling back to STDOUT."
  (ytm-radio--diagnostic-text (ytm-radio--trim-buffer stderr)
                              (ytm-radio--trim-buffer stdout)))

(defun ytm-radio--diagnostic-text (diagnostic fallback)
  "Return DIAGNOSTIC, FALLBACK, or a default diagnostic string."
  (cond
   ((not (string-empty-p diagnostic)) diagnostic)
   ((not (string-empty-p fallback)) fallback)
   (t "no diagnostic output")))

(defun ytm-radio--parse-json-buffer (buffer)
  "Parse JSON from BUFFER and return an alist."
  (with-current-buffer buffer
    (goto-char (point-min))
    (json-parse-buffer :object-type 'alist
                       :array-type 'list
                       :null-object nil
                       :false-object nil)))

(defun ytm-radio--call-json-process-async
    (program arguments failure-message success error-callback
             &optional label name failure-parser)
  "Run PROGRAM with ARGUMENTS asynchronously.
SUCCESS is called with parsed JSON.  ERROR-CALLBACK is called with a diagnostic
string.  FAILURE-MESSAGE maps non-zero process diagnostics into user text.
LABEL is used in executable diagnostics.  NAME is the process name.
When FAILURE-PARSER is non-nil, it receives the stdout buffer and diagnostic
text and returns the value passed to ERROR-CALLBACK."
  (ytm-radio--ensure-program program (or label "ytm-radio-helper"))
  (let* ((stdout (generate-new-buffer " *ytm-radio-stdout*"))
         (stderr (generate-new-buffer " *ytm-radio-stderr*"))
         (process
          (make-process
           :name (or name "ytm-radio-helper")
           :buffer stdout
           :stderr stderr
           :command (cons program arguments)
           :noquery t
           :sentinel
           (lambda (process _event)
             (when (memq (process-status process) '(exit signal))
               (unwind-protect
                   (if (zerop (process-exit-status process))
                       (condition-case parse-error
                           (funcall success (ytm-radio--parse-json-buffer stdout))
                         (error
                          (funcall error-callback
                                   (format "Process returned invalid JSON: %s"
                                           (error-message-string parse-error)))))
                     (let ((diagnostic
                            (ytm-radio--process-buffer-diagnostic stdout stderr)))
                       (funcall error-callback
                                (if failure-parser
                                    (funcall failure-parser stdout diagnostic)
                                  (funcall failure-message diagnostic)))))
                 (when (buffer-live-p stdout)
                   (kill-buffer stdout))
                 (when (buffer-live-p stderr)
                   (kill-buffer stderr))))))))
    process))

(defun ytm-radio--yt-dlp-metadata-arguments (url)
  "Return yt-dlp metadata arguments for URL."
  (append ytm-radio-yt-dlp-extra-args
          (ytm-radio--yt-dlp-proxy-arguments)
          (list "--flat-playlist"
                "--dump-single-json"
                url)))

(defun ytm-radio--fetch-source-async (url success error-callback)
  "Fetch URL through yt-dlp asynchronously.
SUCCESS is called with a normalized source.  ERROR-CALLBACK receives a
diagnostic string."
  (ytm-radio--call-json-process-async
   ytm-radio-yt-dlp-program
   (ytm-radio--yt-dlp-metadata-arguments url)
   (lambda (diagnostic)
     (format "Yt-dlp failed for %s: %s" url diagnostic))
   (lambda (json)
     (funcall success (ytm-radio--source-from-json json url)))
   error-callback
   "yt-dlp"
   "ytm-radio-yt-dlp"))

(defun ytm-radio--url-host (url)
  "Return the host component of URL, or an empty string."
  (or (url-host (url-generic-parse-url url)) ""))

(defun ytm-radio--music-url-p (url)
  "Return non-nil when URL points at YouTube Music."
  (string-match-p "\\(?:\\`\\|\\.\\)music\\.youtube\\.com\\'"
                  (ytm-radio--url-host url)))

(defun ytm-radio--url-has-query-key-p (url key)
  "Return non-nil when URL has query parameter KEY."
  (let ((query (url-filename (url-generic-parse-url url))))
    (and query
         (string-match-p
          (concat "[?&]" (regexp-quote key) "=")
          query))))

(defun ytm-radio--source-kind (url json)
  "Return a source kind for URL and yt-dlp JSON."
  (cond ((ytm-radio--music-url-p url)
         (if (or (map-elt json 'entries)
                 (ytm-radio--url-has-query-key-p url "list"))
             'youtube-music-playlist
           'youtube-music-track))
        ((string-match-p "/@" url)
         'youtube-channel)
        ((or (map-elt json 'entries)
             (ytm-radio--url-has-query-key-p url "list"))
         'youtube-playlist)
        (t 'youtube-track)))

(defun ytm-radio--fallback-track-url (source-url id)
  "Return a watch URL for ID using SOURCE-URL to pick the host."
  (format "https://%s/watch?v=%s"
          (if (ytm-radio--music-url-p source-url)
              "music.youtube.com"
            "www.youtube.com")
          id))

(defun ytm-radio--best-thumbnail-url (json)
  "Return the best thumbnail URL in JSON, or nil."
  (or (map-elt json 'thumbnail)
      (when-let* ((thumbnails (map-elt json 'thumbnails))
                  (last-thumbnail (car (last thumbnails))))
        (map-elt last-thumbnail 'url))))

(defun ytm-radio--track-url (json source-url)
  "Return the playable URL for JSON from SOURCE-URL."
  (let ((url (or (map-elt json 'webpage_url)
                 (map-elt json 'original_url)
                 (map-elt json 'url))))
    (cond ((and (stringp url)
                (string-match-p "\\`https?://" url))
           url)
          ((map-elt json 'id)
           (ytm-radio--fallback-track-url source-url (map-elt json 'id)))
          (t source-url))))

(defun ytm-radio--track-from-json (json source-id source-kind source-url)
  "Return a track from JSON.
SOURCE-ID and SOURCE-KIND identify the owner.  SOURCE-URL is used to
build a watch URL when yt-dlp returns only a video id."
  (ytm-radio--make-track
   :id (or (map-elt json 'id) (ytm-radio--track-url json source-url))
   :title (or (map-elt json 'title)
              (map-elt json 'track)
              (map-elt json 'fulltitle)
              "")
   :url (ytm-radio--track-url json source-url)
   :duration (map-elt json 'duration)
   :artist (or (map-elt json 'artist)
               (map-elt json 'uploader)
               (map-elt json 'channel))
   :album (map-elt json 'album)
   :thumbnail-url (ytm-radio--best-thumbnail-url json)
   :source-id source-id
   :source-kind source-kind))

(defun ytm-radio--source-id (json url)
  "Return a stable source id from JSON and URL."
  (or (map-elt json 'playlist_id)
      (map-elt json 'channel_id)
      (map-elt json 'id)
      url))

(defun ytm-radio--source-title-from-json (json url)
  "Return a display title from JSON and URL."
  (or (map-elt json 'title)
      (map-elt json 'playlist_title)
      (map-elt json 'channel)
      url))

(defun ytm-radio--source-from-json (json url)
  "Normalize yt-dlp JSON from URL into a source alist."
  (let* ((id (ytm-radio--source-id json url))
         (kind (ytm-radio--source-kind url json))
         (entries (or (map-elt json 'entries) (list json)))
         (tracks (seq-keep
                  (lambda (entry)
                    (when (and entry
                               (or (map-elt entry 'id)
                                   (map-elt entry 'url)
                                   (not (map-elt json 'entries))))
                      (ytm-radio--track-from-json entry id kind url)))
                  entries)))
    (ytm-radio--make-source
     :id id
     :kind kind
     :title (ytm-radio--source-title-from-json json url)
     :url url
     :tracks tracks
     :items tracks
     :continuation nil)))

(defun ytm-radio--ensure-url-import-idle ()
  "Signal when a URL import is already running."
  (when (process-live-p ytm-radio--add-url-process)
    (user-error "A URL is already being imported")))

(defun ytm-radio--finish-url-import (url source after-success)
  "Finish transient URL import for URL and SOURCE, then call AFTER-SUCCESS."
  (setq ytm-radio--add-url-process nil)
  (if (not (ytm-radio--source-tracks source))
      (message "No playable tracks found for %s" url)
    (funcall after-success source)
    (message "Loaded %s (%d tracks)"
             (ytm-radio--source-display-title source)
             (length (ytm-radio--source-tracks source)))))

(defun ytm-radio--start-url-import (url after-success)
  "Import URL asynchronously and call AFTER-SUCCESS with the new source."
  (ytm-radio--ensure-loaded)
  (ytm-radio--ensure-url-import-idle)
  (message "Importing URL...")
  (setq
   ytm-radio--add-url-process
   (ytm-radio--fetch-source-async
    url
    (lambda (source)
      (ytm-radio--finish-url-import url source after-success))
    (lambda (diagnostic)
      (setq ytm-radio--add-url-process nil)
      (message "%s" diagnostic)))))

;;; Account helper

(defun ytm-radio--account-auth-available-p ()
  "Return non-nil when account-backed helper requests can run now."
  (and ytm-radio-helper-auth-file
       (file-readable-p ytm-radio-helper-auth-file)))

(defun ytm-radio--helper-error-message (helper-error)
  "Return user-facing text for HELPER-ERROR."
  (format "Account helper failed: %s"
          (if (stringp helper-error)
              helper-error
            (or (map-elt helper-error 'message) "unknown helper failure"))))

(defun ytm-radio--helper-error-auth-required-p (helper-error)
  "Return non-nil when HELPER-ERROR requires a new browser login."
  (and (listp helper-error)
       (map-elt helper-error 'auth-required)))

(defun ytm-radio--helper-process-error (stdout diagnostic)
  "Return a structured helper error parsed from STDOUT or DIAGNOSTIC."
  (condition-case nil
      (let* ((envelope (ytm-radio--parse-json-buffer stdout))
             (helper-error (map-elt envelope 'error)))
        (unless (and (not (map-elt envelope 'ok))
                     (equal (map-elt envelope 'schema)
                            ytm-radio--helper-schema-version)
                     (equal (map-elt envelope 'protocol)
                            ytm-radio--helper-protocol-version)
                     (equal (map-elt envelope 'helper-version)
                            ytm-radio--helper-version)
                     (stringp (map-elt helper-error 'code))
                     (stringp (map-elt helper-error 'message)))
          (error "Invalid helper error envelope"))
        helper-error)
    (error
     `((code . "process-failure")
       (message . ,diagnostic)
       (retryable . nil)
       (auth-required . nil)))))

(defun ytm-radio--invalidate-account-auth ()
  "Remove invalid account auth before starting a new browser login."
  (when (and (stringp ytm-radio-helper-auth-file)
             (file-exists-p ytm-radio-helper-auth-file))
    (ignore-errors
      (delete-file ytm-radio-helper-auth-file))))

(defun ytm-radio--start-account-login (action &optional message)
  "Start login and run ACTION after it succeeds.
MESSAGE is shown before opening the login browser."
  (if (process-live-p ytm-radio--login-process)
      (progn
        (setq ytm-radio--login-continuation action)
        (ytm-radio--set-login-status "Login waiting in browser...")
        (message
         "YouTube Music login is already running; finish signing in in the browser"))
    (when message
      (message "%s" message))
    (ytm-radio--start-login (expand-file-name ytm-radio-helper-auth-file)
                            nil
                            action)))

(defun ytm-radio--with-account-auth (action &optional message)
  "Run ACTION when account auth is available, otherwise start login.
MESSAGE is shown when login is required."
  (if (ytm-radio--account-auth-available-p)
      (funcall action)
    (ytm-radio--start-account-login
     action
     (or message "YouTube Music login required"))))

(defun ytm-radio--handle-account-helper-error (helper-error retry-action)
  "Handle HELPER-ERROR, retrying through RETRY-ACTION after auth renewal."
  (if (ytm-radio--helper-error-auth-required-p helper-error)
      (progn
        (ytm-radio--invalidate-account-auth)
        (ytm-radio--start-account-login retry-action "YouTube Music login required"))
    (message "%s" (ytm-radio--helper-error-message helper-error))))

(defun ytm-radio--helper-limit (target)
  "Return the configured helper limit for TARGET."
  (if (equal target "home")
      ytm-radio-helper-home-limit
    ytm-radio-helper-library-limit))

(defun ytm-radio--proxy-url ()
  "Return the configured proxy URL, or nil."
  (when (stringp ytm-radio-proxy-url)
    (let ((proxy (string-trim ytm-radio-proxy-url)))
      (unless (string-empty-p proxy)
        proxy))))

(defun ytm-radio--http-proxy-url-p (proxy)
  "Return non-nil when PROXY is an HTTP proxy URL."
  (and (stringp proxy)
       (let ((case-fold-search t))
         (string-match-p "\\`https?://" proxy))))

(defun ytm-radio--http-proxy-authority (proxy)
  "Return PROXY authority for `url-proxy-services', or nil."
  (when (ytm-radio--http-proxy-url-p proxy)
    (let* ((parsed (url-generic-parse-url proxy))
           (host (url-host parsed))
           (port (url-port parsed))
           (user (url-user parsed))
           (password (url-password parsed)))
      (when host
        (concat
         (cond
          ((and user password) (format "%s:%s@" user password))
          (user (concat user "@")))
         host
         (when port
           (format ":%d" port)))))))

(defun ytm-radio--cover-url-proxy-services ()
  "Return `url-proxy-services' entries for cover downloads, or nil."
  (when-let* ((proxy (ytm-radio--proxy-url))
              (authority (ytm-radio--http-proxy-authority proxy)))
    `(("http" . ,authority)
      ("https" . ,authority))))

(defun ytm-radio--yt-dlp-proxy-arguments ()
  "Return yt-dlp proxy arguments, or nil."
  (when-let* ((proxy (ytm-radio--proxy-url)))
    (list "--proxy" proxy)))

(defun ytm-radio--helper-shared-arguments (&optional fresh)
  "Return shared helper arguments for account requests.
When FRESH is non-nil, bypass cached helper responses."
  (append (when ytm-radio-helper-auth-file
            (list "--auth" (expand-file-name ytm-radio-helper-auth-file)))
          (when-let* ((proxy (ytm-radio--proxy-url)))
            (list "--proxy" proxy))
          (when fresh
            (list "--fresh"))))

(defun ytm-radio--helper-browse-arguments (target &optional initial-only fresh)
  "Return helper arguments for browsing TARGET.
When INITIAL-ONLY is non-nil, request only the first Home page.
When FRESH is non-nil, bypass cached helper responses."
  (append (list "browse" target)
          (ytm-radio--helper-shared-arguments fresh)
          (when initial-only
            (list "--initial-only"))
          (list "--limit"
                (number-to-string (ytm-radio--helper-limit target)))))

(defun ytm-radio--helper-continuation-arguments (token &optional fresh)
  "Return helper arguments for loading continuation TOKEN.
When FRESH is non-nil, bypass cached helper responses."
  (append (list "continuation" token)
          (ytm-radio--helper-shared-arguments fresh)
          (list "--limit"
                (number-to-string ytm-radio-helper-home-limit))))

(defun ytm-radio--helper-browse-id-arguments
    (browse-id &optional params fresh)
  "Return helper arguments for browsing BROWSE-ID and PARAMS.
When FRESH is non-nil, bypass cached helper responses."
  (append (list "browse-id" browse-id)
          (when (and (stringp params)
                     (not (string-empty-p params)))
            (list "--params" params))
          (ytm-radio--helper-shared-arguments fresh)
          (list "--limit"
                (number-to-string ytm-radio-helper-library-limit))))

(defun ytm-radio--helper-search-arguments (query &optional fresh)
  "Return helper arguments for searching YouTube Music for QUERY.
When FRESH is non-nil, bypass cached helper responses."
  (append (list "search" query)
          (ytm-radio--helper-shared-arguments fresh)
          (list "--limit"
                (number-to-string ytm-radio-helper-library-limit))))

(defun ytm-radio--helper-rate-arguments (video-id rating)
  "Return helper arguments for rating VIDEO-ID with RATING."
  (append (list "rate" video-id rating)
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-radio-arguments (video-id)
  "Return helper arguments for starting radio from VIDEO-ID."
  (append (list "radio" video-id)
          (ytm-radio--helper-shared-arguments)
          (list "--limit"
                (number-to-string ytm-radio-helper-library-limit))))

(defun ytm-radio--helper-playlist-options-arguments (video-id)
  "Return helper arguments for playlist options for VIDEO-ID."
  (append (list "playlist-options" video-id)
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-add-to-playlist-arguments (video-id playlist-id)
  "Return helper arguments for adding VIDEO-ID to PLAYLIST-ID."
  (append (list "add-to-playlist" video-id playlist-id)
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-library-arguments (video-id action)
  "Return helper arguments for applying library ACTION to VIDEO-ID."
  (append (list "library" video-id action)
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-item-library-arguments (browse-id action &optional params)
  "Return helper arguments for applying library ACTION to BROWSE-ID."
  (append (list "item-library" browse-id action)
          (when (and (stringp params)
                     (not (string-empty-p params)))
            (list "--params" params))
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-subscription-arguments (browse-id action &optional params)
  "Return helper arguments for applying subscription ACTION to BROWSE-ID."
  (append (list "subscription" browse-id action)
          (when (and (stringp params)
                     (not (string-empty-p params)))
            (list "--params" params))
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-track-status-arguments (video-id)
  "Return helper arguments for reading account status of VIDEO-ID."
  (append (list "track-status" video-id)
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-stream-arguments (video-id)
  "Return helper arguments for resolving authenticated VIDEO-ID playback."
  (append (list "stream" video-id
                "--yt-dlp-program" ytm-radio-yt-dlp-program)
          (when (and (stringp ytm-radio-mpv-ytdl-format)
                     (not (string-empty-p ytm-radio-mpv-ytdl-format)))
            (list "--format" ytm-radio-mpv-ytdl-format))
          (ytm-radio--helper-shared-arguments)))

(defun ytm-radio--helper-login-browser-arguments ()
  "Return explicitly configured login browser and profile arguments."
  (append
   (when (and (stringp ytm-radio-helper-login-profile-directory)
              (not (string-empty-p ytm-radio-helper-login-profile-directory)))
     (list "--profile-dir"
           (expand-file-name ytm-radio-helper-login-profile-directory)))
   (when (and (stringp ytm-radio-helper-login-browser)
              (not (string-empty-p ytm-radio-helper-login-browser)))
     (list "--browser" ytm-radio-helper-login-browser))))

(defun ytm-radio--helper-login-arguments (output &optional restart-running)
  "Return helper arguments for logging in and writing auth to OUTPUT.
When RESTART-RUNNING is non-nil, ask the helper to restart a running browser
that does not expose DevTools."
  (append
   (list "auth"
         "login-window"
         "--output"
         (expand-file-name output)
         "--port"
         (number-to-string ytm-radio-helper-login-cdp-port)
         "--timeout-secs"
         (number-to-string ytm-radio-helper-login-timeout))
   (when-let* ((proxy (ytm-radio--proxy-url)))
     (list "--proxy" proxy))
   (when restart-running
     (list "--restart-running"))
   (ytm-radio--helper-login-browser-arguments)))

(defun ytm-radio--helper-prepare-login-arguments (output)
  "Return helper arguments for preparing an isolated profile beside OUTPUT."
  (append
   (list "auth"
         "prepare-login-profile"
         "--output"
         (expand-file-name output)
         "--timeout-secs"
         (number-to-string ytm-radio-helper-login-timeout))
   (ytm-radio--helper-login-browser-arguments)))

(defun ytm-radio--call-helper-async (arguments success error-callback)
  "Run the external helper with ARGUMENTS asynchronously.
SUCCESS is called with helper data.  ERROR-CALLBACK receives a structured
helper error."
  (ytm-radio--call-json-process-async
   (ytm-radio--ensure-helper-command)
   arguments
   (lambda (diagnostic)
     (format "Account helper failed: %s" diagnostic))
   (lambda (envelope)
     (condition-case error
         (funcall success (ytm-radio--helper-envelope-data envelope))
       (error
        (funcall error-callback (error-message-string error)))))
   error-callback
   nil
   nil
   #'ytm-radio--helper-process-error))

(defun ytm-radio--helper-envelope-data (envelope)
  "Return the data alist from helper ENVELOPE."
  (unless (map-elt envelope 'ok)
    (user-error "Account helper returned an error"))
  (unless (equal (map-elt envelope 'schema) ytm-radio--helper-schema-version)
    (user-error "Unsupported helper schema %S" (map-elt envelope 'schema)))
  (unless (equal (map-elt envelope 'protocol) ytm-radio--helper-protocol-version)
    (user-error
     "Unsupported ytm-radio helper protocol %S; install helper %s"
     (map-elt envelope 'protocol)
     ytm-radio--helper-version))
  (unless (equal (map-elt envelope 'helper-version) ytm-radio--helper-version)
    (user-error
     "Unsupported ytm-radio helper version %S; install helper %s"
     (map-elt envelope 'helper-version)
     ytm-radio--helper-version))
  (or (map-elt envelope 'data)
      (user-error "Account helper returned no data")))

(defun ytm-radio--symbol-value (value fallback)
  "Return VALUE as a symbol, or FALLBACK when VALUE is absent."
  (cond ((symbolp value) value)
        ((stringp value) (intern value))
        (t fallback)))

(defun ytm-radio--track-from-helper-item (item source-id source-kind)
  "Return a ytm-radio track from helper ITEM.
SOURCE-ID and SOURCE-KIND identify the imported helper source."
  (ytm-radio--make-track
   :id (map-elt item 'id)
   :title (map-elt item 'title)
   :url (map-elt item 'url)
   :duration (map-elt item 'duration)
   :artist (map-elt item 'artist)
   :album (map-elt item 'album)
   :thumbnail-url (map-elt item 'thumbnail-url)
   :source-id source-id
   :source-kind source-kind
   :like-status (ytm-radio--symbol-value (map-elt item 'like-status) nil)
   :in-library (map-elt item 'in-library)
   :explicit (map-elt item 'explicit)
   :account-auth t))

(defun ytm-radio--helper-track-item-p (item)
  "Return non-nil when helper ITEM is playable."
  (and item
       (member (or (map-elt item 'type) "track")
               '("track" "episode"))
       (map-elt item 'url)))

(defun ytm-radio--helper-field-present-p (item field)
  "Return non-nil when helper ITEM contains FIELD."
  (and (assq field item) t))

(defun ytm-radio--source-from-helper (source)
  "Return a ytm-radio source from helper SOURCE."
  (let* ((id (map-elt source 'id))
         (kind (ytm-radio--symbol-value (map-elt source 'kind)
                                        'account))
         (items (or (map-elt source 'items)
                    (map-elt source 'tracks)
                    nil))
         (tracks (unless (ytm-radio--container-list-source-id-p id)
                   (seq-keep
                    (lambda (item)
                      (when (ytm-radio--helper-track-item-p item)
                        (ytm-radio--track-from-helper-item item id kind)))
                    items))))
    (ytm-radio--sanitize-source
     (ytm-radio--make-source
      :id id
      :kind kind
      :title (map-elt source 'title)
      :url (map-elt source 'url)
      :tracks tracks
      :items items
      :continuation (map-elt source 'continuation)
      :subtitle (map-elt source 'subtitle)
      :thumbnail-url (map-elt source 'thumbnail-url)
      :in-library (map-elt source 'in-library)
      :subscribed (map-elt source 'subscribed)
      :playlist-id (map-elt source 'playlist-id)
      :in-library-known (ytm-radio--helper-field-present-p source 'in-library)
      :subscribed-known (ytm-radio--helper-field-present-p source 'subscribed)))))

(defun ytm-radio--helper-sources (data)
  "Return normalized sources from helper DATA."
  (seq-keep #'ytm-radio--source-from-helper
            (or (map-elt data 'sources) nil)))

(defun ytm-radio--helper-continuation (data)
  "Return helper DATA's continuation token, or nil."
  (let ((continuation (map-elt data 'continuation)))
    (and (stringp continuation)
         (not (string-empty-p continuation))
         continuation)))

(defun ytm-radio--source-target-p (source target)
  "Return non-nil when SOURCE belongs to browser/helper TARGET."
  (let ((id (or (map-elt source :id) ""))
        (kind (symbol-name (or (map-elt source :kind) 'unknown)))
        (target (if (symbolp target) (symbol-name target) target)))
    (pcase target
      ("home"
       (or (string-prefix-p "ytm:home" id)
           (member kind '("youtube-music-home"
                          "youtube-music-home-section"))))
      ("explore"
       (or (string-prefix-p "ytm:explore" id)
           (member kind '("youtube-music-explore"
                          "youtube-music-explore-section"))))
      ("library"
       (and (not (or (string-prefix-p "ytm:library:liked" id)
                     (string-equal kind "youtube-music-liked")))
            (or (string-prefix-p "ytm:library" id)
                (member kind '("youtube-music-library"
                               "youtube-music-library-section")))))
      ("library-songs"
       (string-prefix-p "ytm:library:songs" id))
      ("library-albums"
       (string-prefix-p "ytm:library:albums" id))
      ("library-artists"
       (string-prefix-p "ytm:library:artists" id))
      ("library-playlists"
       (string-prefix-p "ytm:library:playlists" id))
      ("liked"
       (or (string-prefix-p "ytm:library:liked" id)
           (string-equal kind "youtube-music-liked")))
      ("search"
       (or (string-prefix-p "ytm:search" id)
           (member kind '("youtube-music-search"
                          "youtube-music-search-section"))))
      ("browse"
       (string-prefix-p "ytm:browse" id))
      (_ nil))))

(defun ytm-radio--drop-helper-target-sources (target)
  "Remove existing helper sources for TARGET from state."
  (setf (map-elt ytm-radio--state :sources)
        (seq-remove
         (lambda (cell)
           (ytm-radio--source-target-p (cdr cell) target))
         (ytm-radio--sources))))

(defun ytm-radio--drop-account-helper-sources ()
  "Remove account-backed helper sources and runtime account state."
  (dolist (target '("home" "explore" "library" "liked" "search" "browse"))
    (ytm-radio--drop-helper-target-sources target))
  (clrhash ytm-radio--account-state-index)
  (clrhash ytm-radio--track-status-refreshes)
  (setq ytm-radio--account-state-owner nil))

(defun ytm-radio--helper-track-count (sources)
  "Return total track count across SOURCES."
  (seq-reduce
   (lambda (count source)
     (+ count (length (ytm-radio--source-tracks source))))
   sources
   0))

(defun ytm-radio--apply-home-helper-data (data append &optional restore-entry)
  "Apply Home helper DATA.
When APPEND is non-nil, append new sections instead of replacing Home.
When RESTORE-ENTRY is non-nil, restore that browser position after rendering."
  (let ((sources (ytm-radio--helper-sources data)))
    (unless append
      (ytm-radio--drop-helper-target-sources "home"))
    (dolist (source sources)
      (ytm-radio--put-source source))
    (ytm-radio--set-home-continuation
     (ytm-radio--helper-continuation data))
    (ytm-radio--save)
    (if restore-entry
        (progn
          (ytm-radio--render-browser t restore-entry)
          (ytm-radio--render-now-playing))
      (ytm-radio--render))
    (message "Imported home recommendations: %d sources, %d tracks%s"
             (length sources)
             (ytm-radio--helper-track-count sources)
             (if (ytm-radio--home-continuation)
                 " (more available)"
               ""))))

(defun ytm-radio--ensure-browser-load-idle ()
  "Signal when a browser helper request is already running."
  (when (process-live-p ytm-radio--browser-load-process)
    (user-error "YouTube Music %s is already loading"
                ytm-radio--browser-loading-view)))

(defun ytm-radio--set-browser-loading (message view)
  "Set browser loading MESSAGE for VIEW."
  (setq ytm-radio--browser-loading-message message
        ytm-radio--browser-loading-view view))

(defun ytm-radio--clear-browser-loading ()
  "Clear browser helper loading state."
  (setq ytm-radio--browser-load-process nil
        ytm-radio--browser-load-token nil
        ytm-radio--browser-loading-message nil
        ytm-radio--browser-loading-view nil))

(defun ytm-radio--new-request-token ()
  "Return a fresh asynchronous request identity token."
  (make-symbol "ytm-radio-request"))

(defun ytm-radio--home-loading-message ()
  "Return a Home loading message, or nil."
  (pcase ytm-radio--home-loading
    ('initial "Loading Home...")
    ('more "Loading more Home sections...")
    (_ nil)))

(defun ytm-radio--start-home-load (&optional append restore-entry fresh)
  "Start asynchronous Home loading.
When APPEND is non-nil, load the current Home continuation.
When RESTORE-ENTRY is non-nil, restore that browser position after loading.
When FRESH is non-nil, bypass cached helper responses."
  (ytm-radio--ensure-loaded)
  (when (process-live-p ytm-radio--home-process)
    (user-error "Home is already loading"))
  (ytm-radio--with-account-auth
   (lambda ()
     (let ((arguments (if append
                          (if (ytm-radio--home-continuation)
                              (ytm-radio--helper-continuation-arguments
                               (ytm-radio--home-continuation) fresh)
                            (user-error "No more Home sections"))
                        (ytm-radio--helper-browse-arguments "home" t fresh)))
           (token (ytm-radio--new-request-token)))
       (setq ytm-radio--home-loading (if append 'more 'initial)
             ytm-radio--home-load-token token)
       (unless append
         (setf (map-elt ytm-radio--state :home-continuation) nil))
       (ytm-radio--render-browser (not append) restore-entry)
       (setq
        ytm-radio--home-process
        (ytm-radio--call-helper-async
         arguments
         (lambda (data)
           (when (eq token ytm-radio--home-load-token)
             (setq ytm-radio--home-process nil
                   ytm-radio--home-load-token nil
                   ytm-radio--home-loading nil
                   ytm-radio--initial-home-refreshed t)
             (ytm-radio--apply-home-helper-data data append restore-entry)))
         (lambda (diagnostic)
           (when (eq token ytm-radio--home-load-token)
             (setq ytm-radio--home-process nil
                   ytm-radio--home-load-token nil
                   ytm-radio--home-loading nil)
             (ytm-radio--render-browser nil restore-entry)
             (ytm-radio--handle-account-helper-error
              diagnostic
              (lambda ()
                (ytm-radio--start-home-load append restore-entry fresh)))))))))
   "YouTube Music login required"))

(defun ytm-radio--start-helper-target-load
    (target label view &optional restore-entry fresh)
  "Start asynchronous helper import for TARGET with LABEL in VIEW.
When RESTORE-ENTRY is non-nil, restore that browser position after loading.
When FRESH is non-nil, bypass cached helper responses."
  (ytm-radio--ensure-loaded)
  (ytm-radio--ensure-browser-load-idle)
  (ytm-radio--with-account-auth
   (lambda ()
     (let ((token (ytm-radio--new-request-token)))
       (setq ytm-radio--browser-load-token token)
       (ytm-radio--set-browser-loading
        (format "Loading %s..." (ytm-radio--browser-title))
        view)
       (ytm-radio--render-browser t restore-entry)
       (setq
        ytm-radio--browser-load-process
        (ytm-radio--call-helper-async
         (ytm-radio--helper-browse-arguments target nil fresh)
         (lambda (data)
           (when (eq token ytm-radio--browser-load-token)
             (let ((sources (ytm-radio--helper-sources data)))
               (ytm-radio--clear-browser-loading)
               (ytm-radio--drop-helper-target-sources target)
               (dolist (source sources)
                 (ytm-radio--put-source source))
               (ytm-radio--save)
               (ytm-radio--render-browser t restore-entry)
               (ytm-radio--render-now-playing)
               (message "Imported %s: %d sources, %d tracks"
                        label
                        (length sources)
                        (ytm-radio--helper-track-count sources)))))
         (lambda (diagnostic)
           (when (eq token ytm-radio--browser-load-token)
             (ytm-radio--clear-browser-loading)
             (ytm-radio--render-browser nil restore-entry)
             (ytm-radio--handle-account-helper-error
              diagnostic
              (lambda ()
                (ytm-radio--start-helper-target-load
                 target label view restore-entry fresh)))))))))
   "YouTube Music login required"))

(defun ytm-radio--start-search-load (query &optional replace restore-entry fresh)
  "Start asynchronous YouTube Music search for QUERY.
When REPLACE is non-nil, replace the current browser history entry.
When RESTORE-ENTRY is non-nil, restore that browser position after loading.
When FRESH is non-nil, bypass cached helper responses."
  (ytm-radio--ensure-loaded)
  (ytm-radio--ensure-browser-load-idle)
  (let ((view (list (cons :kind 'search)
                    (cons :query query)
                    (cons :title (format "Search: %s" query)))))
    (ytm-radio--set-browser-view view replace nil restore-entry)
    (ytm-radio--with-account-auth
     (lambda ()
       (let ((token (ytm-radio--new-request-token)))
         (setq ytm-radio--browser-load-token token)
         (ytm-radio--drop-helper-target-sources "search")
         (ytm-radio--set-browser-loading (format "Searching %s..." query) view)
         (ytm-radio--render-browser t restore-entry)
         (setq
          ytm-radio--browser-load-process
          (ytm-radio--call-helper-async
           (ytm-radio--helper-search-arguments query fresh)
           (lambda (data)
             (when (eq token ytm-radio--browser-load-token)
               (let ((sources (ytm-radio--helper-sources data)))
                 (ytm-radio--clear-browser-loading)
                 (dolist (source sources)
                   (ytm-radio--put-source source))
                 (ytm-radio--save)
                 (ytm-radio--render-browser t restore-entry)
                 (ytm-radio--render-now-playing)
                 (message "Imported search results for %s" query))))
           (lambda (diagnostic)
             (when (eq token ytm-radio--browser-load-token)
               (ytm-radio--clear-browser-loading)
               (ytm-radio--render-browser nil restore-entry)
               (ytm-radio--handle-account-helper-error
                diagnostic
                (lambda ()
                  (ytm-radio--start-search-load
                   query replace restore-entry fresh)))))))))
     "YouTube Music login required")))

(defun ytm-radio--item-detail-header-kind (item)
  "Return a detail header source kind for opener ITEM, or nil."
  (let ((browse-id (ytm-radio--item-browse-id item))
        (type (ytm-radio--item-type item)))
    (cond
     ((and browse-id (string-prefix-p "MPRE" browse-id))
      'youtube-music-album)
     ((and browse-id (or (string-prefix-p "VL" browse-id)
                         (string-prefix-p "RD" browse-id)))
      'youtube-music-playlist)
     ((string-equal type "artist")
      'youtube-music-artist)
     ((string-equal type "channel")
      'youtube-channel)
     ((and browse-id (string-prefix-p "UC" browse-id))
      'youtube-music-artist)
     (t
      (pcase type
        ("album" 'youtube-music-album)
        ("playlist" 'youtube-music-playlist)
        (_ nil))))))

(defun ytm-radio--synthetic-detail-header-source (source context &optional id)
  "Return a metadata-only detail header source for SOURCE from CONTEXT.
When ID is non-nil, use it as the header source id."
  (when-let* ((kind (ytm-radio--item-detail-header-kind context))
              (source-id (map-elt source :id)))
    (ytm-radio--make-source
     :id (or id (concat source-id ":header"))
     :kind kind
     :title (ytm-radio--item-title context)
     :url (or (ytm-radio--item-url context)
              (map-elt source :url))
     :items nil
     :tracks nil
     :subtitle (or (map-elt context 'subtitle)
                   (map-elt context :subtitle))
     :thumbnail-url (ytm-radio--item-thumbnail-url context)
     :in-library (ytm-radio--source-or-context-account-state
                  source context 'library)
     :subscribed (ytm-radio--source-or-context-account-state
                  source context 'subscription)
     :in-library-known (ytm-radio--source-or-context-account-state-known-p
                        source context 'library)
     :subscribed-known (ytm-radio--source-or-context-account-state-known-p
                        source context 'subscription)
     :playlist-id (or (map-elt context 'playlist-id)
                      (map-elt context :playlist-id)))))

(defun ytm-radio--detail-account-fields (kind)
  "Return normalized, raw, and known account fields for KIND."
  (pcase kind
    ('library '(:in-library in-library :in-library-known))
    ('subscription '(:subscribed subscribed :subscribed-known))
    (_ (error "Unsupported detail account state kind %S" kind))))

(defun ytm-radio--local-detail-account-state (object kind)
  "Return OBJECT's local account state of KIND, or the missing sentinel."
  (pcase-let ((`(,field ,raw-field ,known-field)
               (ytm-radio--detail-account-fields kind)))
    (cond
     ((and object (assq raw-field object))
      (and (map-elt object raw-field) t))
     ((and object
           (or (map-elt object field)
               (map-elt object known-field)))
      (and (map-elt object field) t))
     (t ytm-radio--account-state-missing))))

(defun ytm-radio--detail-account-state (object kind)
  "Return OBJECT's indexed or local account state of KIND."
  (let ((state (ytm-radio--account-state
                kind (ytm-radio--detail-object-target-ids object))))
    (if (eq state ytm-radio--account-state-missing)
        (ytm-radio--local-detail-account-state object kind)
      state)))

(defun ytm-radio--source-or-context-account-status (source context kind)
  "Return account status of KIND from SOURCE or CONTEXT.
Indexed mutation results take precedence.  Otherwise a positive local state
from either object wins over an explicit negative state."
  (let ((indexed
         (ytm-radio--account-state
          kind
          (delete-dups
           (append (ytm-radio--detail-object-target-ids source)
                   (ytm-radio--detail-object-target-ids context)))))
        (source-state (ytm-radio--local-detail-account-state source kind))
        (context-state (ytm-radio--local-detail-account-state context kind)))
    (cond
     ((not (eq indexed ytm-radio--account-state-missing)) indexed)
     ((or (eq source-state t) (eq context-state t)) t)
     ((or (not (eq source-state ytm-radio--account-state-missing))
          (not (eq context-state ytm-radio--account-state-missing)))
      nil)
     (t ytm-radio--account-state-missing))))

(defun ytm-radio--source-or-context-account-state (source context kind)
  "Return account state of KIND from SOURCE or CONTEXT, or nil."
  (let ((state (ytm-radio--source-or-context-account-status
                source context kind)))
    (unless (eq state ytm-radio--account-state-missing)
      state)))

(defun ytm-radio--source-or-context-account-state-known-p
    (source context kind)
  "Return non-nil when SOURCE or CONTEXT knows account state KIND."
  (not (eq (ytm-radio--source-or-context-account-status source context kind)
           ytm-radio--account-state-missing)))

(defun ytm-radio--detail-header-source-p (source)
  "Return non-nil when SOURCE is a helper detail header source."
  (and source
       (null (ytm-radio--source-items source))
       (stringp (map-elt source :id))
       (string-match-p "\\`ytm:browse:.*:header\\'" (map-elt source :id))))

(defun ytm-radio--browse-detail-sources (sources context)
  "Return detail SOURCES, adding a CONTEXT header when useful."
  (cond
   ((or (null sources) (null context))
    sources)
   ((ytm-radio--detail-header-source-p (car sources))
    (if-let* ((header (ytm-radio--synthetic-detail-header-source
                       (car sources)
                       context
                       (map-elt (car sources) :id))))
        (cons header (cdr sources))
      sources))
   ((null (cdr sources))
    (if-let* ((header (ytm-radio--synthetic-detail-header-source
                       (car sources) context)))
        (list header (car sources))
      sources))
   (t
    (if-let* ((header (ytm-radio--synthetic-detail-header-source
                       (car sources) context)))
        (cons header sources)
      sources))))

(defun ytm-radio--drop-source-ids (source-ids)
  "Remove sources named by SOURCE-IDS from state."
  (setf (map-elt ytm-radio--state :sources)
        (seq-remove
         (lambda (cell)
           (member (car cell) source-ids))
         (ytm-radio--sources))))

(defun ytm-radio--source-browse-id (source)
  "Return SOURCE's YouTube Music browse id, or nil."
  (or (and-let* ((source-id (map-elt source :id))
                 ((string-match "\\`ytm:browse:\\([^:]+\\)" source-id)))
        (match-string 1 source-id))
      (and-let* ((source-id (map-elt source :id))
                 ((string-match "\\`ytm:channel:\\([^:]+\\)" source-id)))
        (match-string 1 source-id))
      (ytm-radio--music-url-detail-browse-id (map-elt source :url))))

(defun ytm-radio--detail-target-ids (browse-id playlist-id)
  "Return stable ids that can identify BROWSE-ID or PLAYLIST-ID."
  (delq nil
        (list browse-id
              playlist-id
              (ytm-radio--playlist-browse-id playlist-id))))

(defun ytm-radio--detail-object-target-ids (object)
  "Return stable browse and playlist ids identifying OBJECT."
  (when object
    (let ((playlist-id (or (ytm-radio--item-playlist-id object)
                           (map-elt object :playlist-id))))
      (delete-dups
       (delq nil
             (list (ytm-radio--source-browse-id object)
                   (ytm-radio--item-browse-id object)
                   playlist-id
                   (ytm-radio--playlist-browse-id playlist-id)
                   (ytm-radio--music-url-detail-browse-id
                    (ytm-radio--item-url object))
                   (ytm-radio--item-detail-browse-id object)
                   (let ((id (ytm-radio--item-id object)))
                     (and (stringp id)
                          (or (string-prefix-p "MP" id)
                              (string-prefix-p "UC" id)
                              (string-prefix-p "VL" id)
                              (string-prefix-p "RD" id))
                          id))))))))

(defun ytm-radio--index-source-account-state (source)
  "Add account state exposed by SOURCE to the runtime index."
  (dolist (kind '(library subscription))
    (let ((value (ytm-radio--local-detail-account-state source kind)))
      (unless (eq value ytm-radio--account-state-missing)
        (ytm-radio--index-account-state-observation
         kind (ytm-radio--detail-object-target-ids source) value))))
  (dolist (track (ytm-radio--source-tracks source))
    (when-let* ((video-id (ytm-radio--item-video-id track)))
      (when-let* ((like-status (ytm-radio--item-like-status track)))
        (ytm-radio--index-account-state-observation
         'like (list video-id) like-status))
      (when (map-elt track :in-library)
        (ytm-radio--index-account-state-observation
         'track-library (list video-id) t))))
  (dolist (item (map-elt source :items))
    (when-let* ((video-id (ytm-radio--item-video-id item)))
      (when-let* ((like-status (ytm-radio--item-like-status item)))
        (ytm-radio--index-account-state-observation
         'like (list video-id) like-status))
      (when (map-elt item 'in-library)
        (ytm-radio--index-account-state-observation
         'track-library (list video-id) t)))
    (dolist (kind '(library subscription))
      (let ((value (ytm-radio--local-detail-account-state item kind)))
        (unless (eq value ytm-radio--account-state-missing)
          (ytm-radio--index-account-state-observation
           kind (ytm-radio--detail-object-target-ids item) value))))))

(defun ytm-radio--record-detail-helper-account-state (data browse-id)
  "Record account state returned by detail mutation DATA for BROWSE-ID."
  (let ((playlist-id (or (map-elt data 'playlist-id)
                         (map-elt data :playlist-id)))
        ids)
    (setq ids (ytm-radio--detail-target-ids browse-id playlist-id))
    (when (assq 'in-library data)
      (ytm-radio--set-account-state
       'library ids (and (map-elt data 'in-library) t)))
    (when (assq 'subscribed data)
      (ytm-radio--set-account-state
       'subscription ids (and (map-elt data 'subscribed) t)))))

(defun ytm-radio--apply-detail-helper-data
    (data browse-id params context &optional restore-entry)
  "Apply refreshed detail DATA for BROWSE-ID, PARAMS, and CONTEXT.
When RESTORE-ENTRY is non-nil, restore that browser position after rendering."
  (ytm-radio--record-detail-helper-account-state data browse-id)
  (let* ((sources (ytm-radio--helper-sources data))
         (detail-sources (ytm-radio--browse-detail-sources sources context)))
    (unless detail-sources
      (user-error "Helper returned no refreshed detail sources for %s" browse-id))
    (ytm-radio--drop-source-ids (ytm-radio--view-value :source-ids))
    (dolist (source detail-sources)
      (ytm-radio--put-source source))
    (setf (map-elt ytm-radio--browser-view :source-ids)
          (mapcar (lambda (source)
                    (map-elt source :id))
                  detail-sources)
          (map-elt ytm-radio--browser-view :browse-id) browse-id
          (map-elt ytm-radio--browser-view :title)
          (ytm-radio--source-display-title (car detail-sources)))
    (if params
        (setf (map-elt ytm-radio--browser-view :browse-params) params)
      (setf (map-elt ytm-radio--browser-view :browse-params) nil))
    (ytm-radio--save)
    (ytm-radio--render-browser nil restore-entry)
    (ytm-radio--render-now-playing)
    detail-sources))

(defun ytm-radio--start-browse-id-load
    (browse-id params &optional context history-entry replace restore-entry fresh)
  "Start asynchronous detail loading for BROWSE-ID and PARAMS.
CONTEXT is optional browser metadata from the item that opened the detail.
HISTORY-ENTRY is the browser location to return to from detail.
When REPLACE is non-nil, replace the current browser history entry.
When RESTORE-ENTRY is non-nil, restore that browser position after loading.
When FRESH is non-nil, bypass cached helper responses."
  (ytm-radio--ensure-loaded)
  (ytm-radio--ensure-browser-load-idle)
  (let ((origin-view (ytm-radio--current-root-view))
        (history-entry (or history-entry
                           (ytm-radio--browser-history-snapshot))))
    (ytm-radio--with-account-auth
     (lambda ()
       (let ((token (ytm-radio--new-request-token)))
         (setq ytm-radio--browser-load-token token)
         (ytm-radio--set-browser-loading "Loading detail..." nil)
         (ytm-radio--render-browser nil restore-entry)
         (setq
          ytm-radio--browser-load-process
          (ytm-radio--call-helper-async
           (ytm-radio--helper-browse-id-arguments browse-id params fresh)
           (lambda (data)
             (when (eq token ytm-radio--browser-load-token)
               (let* ((sources (ytm-radio--helper-sources data))
                      (detail-sources (ytm-radio--browse-detail-sources
                                       sources context)))
                 (ytm-radio--clear-browser-loading)
                 (if (null sources)
                     (progn
                       (ytm-radio--render-browser)
                       (message "No YouTube Music detail returned for %s" browse-id))
                   (dolist (source detail-sources)
                     (ytm-radio--put-source source))
                   (ytm-radio--save)
                   (if (cdr detail-sources)
                       (ytm-radio--set-browser-view
                        (append
                         (list (cons :kind 'detail)
                               (cons :source-ids (mapcar (lambda (source)
                                                            (map-elt source :id))
                                                          detail-sources))
                               (cons :browse-id browse-id)
                               (cons :title
                                     (ytm-radio--source-display-title
                                      (car detail-sources))))
                         (when params
                           (list (cons :browse-params params)))
                         (when context
                           (list (cons :context context)))
                         (when origin-view
                           (list (cons :origin-view origin-view))))
                        replace
                        history-entry
                        restore-entry)
                     (ytm-radio--enter-source
                      (car detail-sources) origin-view history-entry))))))
           (lambda (diagnostic)
             (when (eq token ytm-radio--browser-load-token)
               (ytm-radio--clear-browser-loading)
               (ytm-radio--render-browser nil restore-entry)
               (ytm-radio--handle-account-helper-error
                diagnostic
                (lambda ()
                  (ytm-radio--start-browse-id-load
                   browse-id params context history-entry
                   replace restore-entry fresh)))))))))
     "YouTube Music login required")))

;;; Playback

(defun ytm-radio--mpv-raw-options-argument ()
  "Return the mpv ytdl raw options argument, or nil."
  (let ((options
         (append ytm-radio-ytdl-raw-options
                 (when-let* ((proxy (ytm-radio--proxy-url)))
                   (list (concat "proxy=" proxy))))))
    (when options
      (concat "--ytdl-raw-options="
              (mapconcat #'identity options ",")))))

(defun ytm-radio--mpv-http-proxy-argument ()
  "Return the mpv direct HTTP proxy argument, or nil."
  (when-let* ((proxy (ytm-radio--proxy-url))
              ((ytm-radio--http-proxy-url-p proxy)))
    (concat "--http-proxy=" proxy)))

(defun ytm-radio--mpv-stream-lavf-proxy-argument ()
  "Return the mpv lavf HTTP proxy argument, or nil."
  (when-let* ((proxy (ytm-radio--proxy-url))
              ((ytm-radio--http-proxy-url-p proxy)))
    (concat "--stream-lavf-o-append=http_proxy=" proxy)))

(defun ytm-radio--direct-stream-cache-supported-p ()
  "Return non-nil when cached direct stream URLs preserve proxy routing."
  (let ((proxy (ytm-radio--proxy-url)))
    (or (null proxy)
        (ytm-radio--http-proxy-url-p proxy))))

(defun ytm-radio--mpv-ytdl-format-argument ()
  "Return the mpv ytdl format argument, or nil."
  (when (and (stringp ytm-radio-mpv-ytdl-format)
             (not (string-empty-p ytm-radio-mpv-ytdl-format)))
    (concat "--ytdl-format=" ytm-radio-mpv-ytdl-format)))

(defun ytm-radio--stream-cache-key (track)
  "Return the stream cache key for TRACK."
  (or (map-elt track :id)
      (map-elt track :url)))

(defun ytm-radio--stream-url-expiry (url)
  "Return direct stream URL expiry time, or a conservative fallback."
  (if (and (stringp url)
           (string-match "[?&]expire=\\([0-9]+\\)" url))
      (string-to-number (match-string 1 url))
    (+ (floor (float-time)) 1800)))

(defun ytm-radio--stream-cache-entry-valid-p (entry)
  "Return non-nil when cached stream ENTRY can still be used."
  (and (map-elt entry 'url)
       (> (or (map-elt entry 'expires) 0)
          (+ (floor (float-time)) 300))))

(defun ytm-radio--cached-stream-url (track)
  "Return a cached direct stream URL for TRACK, or nil."
  (when-let* (((ytm-radio--direct-stream-cache-supported-p))
              (key (ytm-radio--stream-cache-key track))
              (entry (gethash key ytm-radio--stream-url-cache)))
    (if (ytm-radio--stream-cache-entry-valid-p entry)
        (map-elt entry 'url)
      (remhash key ytm-radio--stream-url-cache)
      nil)))

(defun ytm-radio--uncache-stream-url (track)
  "Remove TRACK's cached direct stream URL."
  (when-let* ((key (ytm-radio--stream-cache-key track)))
    (remhash key ytm-radio--stream-url-cache)))

(defun ytm-radio--cache-stream-url (track url)
  "Cache direct stream URL for TRACK."
  (when-let* ((key (ytm-radio--stream-cache-key track))
              ((stringp url))
              ((not (string-empty-p url))))
    (puthash key
             (list (cons 'url url)
                   (cons 'expires (ytm-radio--stream-url-expiry url)))
             ytm-radio--stream-url-cache)))

(defun ytm-radio--playback-url-choice (track)
  "Return TRACK playback URL and whether it came from stream cache."
  (if-let* ((cached (ytm-radio--cached-stream-url track)))
      (list cached t)
    (list (map-elt track :url) nil)))

(defun ytm-radio--stream-resolve-arguments (url)
  "Return yt-dlp arguments for resolving direct stream URL from URL."
  (append ytm-radio-yt-dlp-extra-args
          (ytm-radio--yt-dlp-proxy-arguments)
          (list "--no-playlist")
          (when (and (stringp ytm-radio-mpv-ytdl-format)
                     (not (string-empty-p ytm-radio-mpv-ytdl-format)))
            (list "-f" ytm-radio-mpv-ytdl-format))
          (list "-g" url)))

(defun ytm-radio--first-output-line (buffer)
  "Return the first non-empty line from BUFFER."
  (with-current-buffer buffer
    (goto-char (point-min))
    (catch 'line
      (while (not (eobp))
        (let ((line (string-trim
                     (buffer-substring-no-properties
                      (line-beginning-position)
                      (line-end-position)))))
          (unless (string-empty-p line)
            (throw 'line line)))
        (forward-line 1))
      nil)))

(defun ytm-radio--resolve-stream-with-yt-dlp-async
    (track success error-callback)
  "Resolve TRACK with yt-dlp, then call SUCCESS or ERROR-CALLBACK."
  (ytm-radio--ensure-program ytm-radio-yt-dlp-program "yt-dlp")
  (let* ((stdout (generate-new-buffer " *ytm-radio-stream-stdout*"))
         (stderr (generate-new-buffer " *ytm-radio-stream-stderr*"))
         (process
          (make-process
           :name "ytm-radio-stream-resolve"
           :buffer stdout
           :stderr stderr
           :command (cons ytm-radio-yt-dlp-program
                          (ytm-radio--stream-resolve-arguments
                           (map-elt track :url)))
           :noquery t
           :sentinel
           (lambda (process _event)
             (when (memq (process-status process) '(exit signal))
               (unwind-protect
                   (if (zerop (process-exit-status process))
                       (if-let* ((url (ytm-radio--first-output-line stdout)))
                           (funcall success url)
                         (funcall error-callback
                                  "Yt-dlp returned no playable stream URL"))
                     (funcall error-callback
                              (ytm-radio--process-buffer-diagnostic
                               stdout stderr)))
                 (when (buffer-live-p stdout)
                   (kill-buffer stdout))
                 (when (buffer-live-p stderr)
                   (kill-buffer stderr))))))))
    process))

(defun ytm-radio--resolve-stream-with-helper-async
    (track success error-callback)
  "Resolve account TRACK with the helper, then call SUCCESS or ERROR-CALLBACK."
  (ytm-radio--call-helper-async
   (ytm-radio--helper-stream-arguments (map-elt track :id))
   (lambda (data)
     (if-let* ((url (map-elt data 'url))
               ((stringp url))
               ((not (string-empty-p url))))
         (funcall success url)
       (funcall error-callback "Account helper returned no playable stream URL")))
   error-callback))

(defun ytm-radio--resolve-stream-async (track success error-callback)
  "Resolve TRACK asynchronously, then call SUCCESS or ERROR-CALLBACK."
  (if (map-elt track :account-auth)
      (ytm-radio--resolve-stream-with-helper-async track success error-callback)
    (ytm-radio--resolve-stream-with-yt-dlp-async track success error-callback)))

(defun ytm-radio--stream-prefetch-queued-p (key)
  "Return non-nil when stream cache KEY is already queued."
  (seq-some (lambda (track)
              (equal (ytm-radio--stream-cache-key track) key))
            ytm-radio--stream-prefetch-queue))

(defun ytm-radio--stream-prefetch-current-key ()
  "Return the track key currently being prefetched."
  (when (process-live-p ytm-radio--stream-prefetch-process)
    (process-get ytm-radio--stream-prefetch-process 'ytm-radio-track-key)))

(defun ytm-radio--queue-stream-prefetch (track)
  "Queue TRACK for background stream URL prefetch."
  (when-let* ((url (map-elt track :url))
              (key (ytm-radio--stream-cache-key track))
              ((not (ytm-radio--cached-stream-url track)))
              ((not (equal key (ytm-radio--stream-prefetch-current-key))))
              ((not (ytm-radio--stream-prefetch-queued-p key))))
    (setq ytm-radio--stream-prefetch-queue
          (append ytm-radio--stream-prefetch-queue (list track)))))

(defun ytm-radio--start-next-stream-prefetch ()
  "Start the next queued stream prefetch, if any."
  (unless (or (process-live-p ytm-radio--stream-prefetch-process)
              (null ytm-radio--stream-prefetch-queue))
    (let* ((track (pop ytm-radio--stream-prefetch-queue))
           (key (ytm-radio--stream-cache-key track)))
      (if (or (not (map-elt track :url))
              (ytm-radio--cached-stream-url track))
          (ytm-radio--start-next-stream-prefetch)
        (condition-case nil
            (let (process)
              (setq
               process
               (ytm-radio--resolve-stream-async
                track
                (lambda (url)
                  (when (eq process ytm-radio--stream-prefetch-process)
                    (setq ytm-radio--stream-prefetch-process nil)
                    (ytm-radio--cache-stream-url track url)
                    (ytm-radio--start-next-stream-prefetch)))
                (lambda (_diagnostic)
                  (when (eq process ytm-radio--stream-prefetch-process)
                    (setq ytm-radio--stream-prefetch-process nil)
                    (ytm-radio--start-next-stream-prefetch)))))
              (process-put process 'ytm-radio-track track)
              (process-put process 'ytm-radio-track-key key)
              (setq ytm-radio--stream-prefetch-process process))
          (error
           (setq ytm-radio--stream-prefetch-process nil)
           (ytm-radio--start-next-stream-prefetch)))))))

(defun ytm-radio--schedule-stream-prefetch (tracks)
  "Schedule background stream prefetch for TRACKS."
  (when (and (not noninteractive)
             (ytm-radio--direct-stream-cache-supported-p)
             (integerp ytm-radio-stream-prefetch-limit)
             (> ytm-radio-stream-prefetch-limit 0))
    (dolist (track (seq-take tracks ytm-radio-stream-prefetch-limit))
      (ytm-radio--queue-stream-prefetch track))
    (ytm-radio--start-next-stream-prefetch)))

(defun ytm-radio--mpv-arguments (socket url)
  "Return mpv arguments for SOCKET and media URL."
  (append ytm-radio-mpv-network-cache-args
          (delq nil (list (ytm-radio--mpv-ytdl-format-argument)
                          (ytm-radio--mpv-http-proxy-argument)
                          (ytm-radio--mpv-stream-lavf-proxy-argument)
                          "--pause=no"))
          ytm-radio-mpv-extra-args
          (delq nil (list (ytm-radio--mpv-raw-options-argument)
                          "--no-video"
                          (concat "--input-ipc-server=" socket)
                          url))))

(defun ytm-radio--set-status (status)
  "Set player STATUS and refresh the now-playing UI."
  (setf (map-elt ytm-radio--player :status) status)
  (ytm-radio--render-now-playing-without-fit))

(defun ytm-radio--stop-process (&optional preserve-retry-stage)
  "Stop the current mpv process and IPC connection.
When PRESERVE-RETRY-STAGE is non-nil, retain the current retry stage."
  (let ((process (map-elt ytm-radio--player :process))
        (ipc-process (map-elt ytm-radio--player :ipc-process))
        (resolve-process ytm-radio--playback-resolve-process))
    (setq ytm-radio--playback-resolve-process nil)
    (ytm-radio--cancel-progress-render)
    (ytm-radio--reset-title-scroll)
    (setf (map-elt ytm-radio--player :process) nil
          (map-elt ytm-radio--player :ipc-process) nil
          (map-elt ytm-radio--player :socket) nil
          (map-elt ytm-radio--player :position) nil
          (map-elt ytm-radio--player :duration) nil
          (map-elt ytm-radio--player :status) 'stopped
          (map-elt ytm-radio--player :playback-url) nil
          (map-elt ytm-radio--player :using-stream-cache) nil
          (map-elt ytm-radio--player :retry-stage)
          (and preserve-retry-stage
               (map-elt ytm-radio--player :retry-stage)))
    (when (process-live-p ipc-process)
      (delete-process ipc-process))
    (when (process-live-p process)
      (delete-process process))
    (when (process-live-p resolve-process)
      (delete-process resolve-process))
    (setq ytm-radio--last-rendered-progress-key nil)))

(defun ytm-radio--schedule-next-track-prefetch (track)
  "Schedule background stream prefetch for TRACK's successor."
  (when-let* ((next (ytm-radio--next-track track)))
    (ytm-radio--schedule-stream-prefetch (list next))))

(defun ytm-radio--mpv-ready-p ()
  "Return non-nil when the current mpv process can accept IPC commands."
  (let ((process (map-elt ytm-radio--player :process))
        (ipc-process (map-elt ytm-radio--player :ipc-process)))
    (and process
         ipc-process
         (process-live-p process)
         (ytm-radio--mpv-ipc-writable-p ipc-process))))

(defun ytm-radio--mpv-ipc-writable-p (ipc)
  "Return non-nil when IPC process can probably accept writes."
  (and (process-live-p ipc)
       (or (not (processp ipc))
           (memq (process-status ipc) '(open run)))))

(defun ytm-radio--current-mpv-ipc-p (process)
  "Return non-nil when PROCESS is the active mpv IPC connection."
  (eq process (map-elt ytm-radio--player :ipc-process)))

(defun ytm-radio--set-current-track-state
    (track status position playback-url using-stream-cache
           &optional preserve-retry-stage)
  "Set current TRACK playback state.
STATUS, POSITION, PLAYBACK-URL, and USING-STREAM-CACHE describe the new load.
When PRESERVE-RETRY-STAGE is non-nil, retain the current retry stage."
  (let ((duration (or (map-elt track :duration)
                      (and (ytm-radio--same-track-p
                            track
                            (map-elt ytm-radio--player :current-track))
                           (map-elt ytm-radio--player :duration)))))
    (setf (map-elt ytm-radio--player :current-track) track
          (map-elt ytm-radio--player :status) status
          (map-elt ytm-radio--player :position) position
          (map-elt ytm-radio--player :duration) duration
          (map-elt ytm-radio--state :last-track-id) (map-elt track :id)
          (map-elt ytm-radio--player :playback-url) playback-url
          (map-elt ytm-radio--player :using-stream-cache) using-stream-cache
          (map-elt ytm-radio--player :retry-stage)
          (and preserve-retry-stage
               (map-elt ytm-radio--player :retry-stage))))
  (setq ytm-radio--last-rendered-progress-key nil)
  (ytm-radio--reset-title-scroll))

(defun ytm-radio--restart-current-track-in-place (track)
  "Restart TRACK in the current mpv instance when it is already loaded."
  (when-let* ((current (map-elt ytm-radio--player :current-track))
              ((ytm-radio--same-track-p current track))
              ((ytm-radio--mpv-ready-p)))
    (ytm-radio--set-current-track-state
     track
     'playing
     0
     (map-elt ytm-radio--player :playback-url)
     (map-elt ytm-radio--player :using-stream-cache))
    (if (and (ytm-radio--mpv-send (list "seek" 0 "absolute"))
             (ytm-radio--mpv-send
              (list "set_property" "pause" :json-false)))
        (progn
          (ytm-radio--render)
          (ytm-radio--auto-show-now-playing)
          t)
      (ytm-radio--stop-process)
      nil)))

(defun ytm-radio--mpv-load-url (url)
  "Load URL in the current mpv process and ensure playback is unpaused."
  (and (ytm-radio--mpv-send (list "loadfile" url "replace"))
       (ytm-radio--mpv-send
        (list "set_property" "pause" :json-false))))

(defun ytm-radio--load-track-in-current-mpv (track)
  "Load TRACK into the current mpv process when IPC is available."
  (when (ytm-radio--mpv-ready-p)
    (pcase-let ((`(,playback-url ,using-stream-cache)
                 (ytm-radio--playback-url-choice track)))
      (ytm-radio--set-current-track-state
       track 'loading nil playback-url using-stream-cache)
      (ytm-radio--save)
      (if (ytm-radio--mpv-load-url playback-url)
          (progn
            (ytm-radio--render)
            (ytm-radio--auto-show-now-playing)
            t)
        (ytm-radio--stop-process)
        nil))))

(defun ytm-radio--restart-current-track-for-retry (track)
  "Restart mpv for TRACK while preserving one-shot retry state."
  (ytm-radio--stop-process t)
  (ytm-radio--play-track track t))

(defun ytm-radio--reload-current-track-url (track url)
  "Reload TRACK from URL after an automatic playback retry."
  (setf (map-elt ytm-radio--player :using-stream-cache) nil
        (map-elt ytm-radio--player :playback-url) url
        (map-elt ytm-radio--player :status) 'loading
        (map-elt ytm-radio--player :position) nil)
  (setq ytm-radio--last-rendered-progress-key nil)
  (if (ytm-radio--mpv-ready-p)
      (if (ytm-radio--mpv-load-url url)
          (progn
            (ytm-radio--render)
            (ytm-radio--auto-show-now-playing))
        (ytm-radio--restart-current-track-for-retry track))
    (ytm-radio--restart-current-track-for-retry track)))

(defun ytm-radio--retry-current-track-with-original-url ()
  "Retry the current track with its original URL after cached stream failure."
  (when-let* ((track (map-elt ytm-radio--player :current-track))
              (url (map-elt track :url))
              ((map-elt ytm-radio--player :using-stream-cache))
              ((null (map-elt ytm-radio--player :retry-stage))))
    (ytm-radio--uncache-stream-url track)
    (setf (map-elt ytm-radio--player :retry-stage) 'original)
    (ytm-radio--reload-current-track-url track url)
    (message "Cached stream failed; retrying original URL")
    t))

(defun ytm-radio--retry-account-track-after-playback-error ()
  "Refresh the authenticated stream once after an account playback error."
  (when-let* ((track (map-elt ytm-radio--player :current-track))
              ((map-elt track :account-auth))
              ((not (eq (map-elt ytm-radio--player :retry-stage) 'final))))
    (setf (map-elt ytm-radio--player :retry-stage) 'final)
    (ytm-radio--uncache-stream-url track)
    (ytm-radio--play-track track t)
    (message "Playback failed; refreshing authenticated stream")
    t))

(defun ytm-radio--retry-current-track-after-playback-error ()
  "Retry the current track once after a transient mpv playback error."
  (when-let* ((track (map-elt ytm-radio--player :current-track))
              (url (map-elt track :url))
              ((not (map-elt ytm-radio--player :using-stream-cache)))
              ((not (eq (map-elt ytm-radio--player :retry-stage) 'final))))
    (setf (map-elt ytm-radio--player :retry-stage) 'final)
    (ytm-radio--reload-current-track-url track url)
    (message "Playback failed; retrying")
    t))

(defun ytm-radio--retry-current-track-after-error ()
  "Retry the current track after a playback error when it is safe to do so."
  (or (ytm-radio--retry-account-track-after-playback-error)
      (ytm-radio--retry-current-track-with-original-url)
      (ytm-radio--retry-current-track-after-playback-error)))

(defun ytm-radio--play-track-now (track &optional preserve-retry-stage)
  "Play resolved TRACK with mpv.
When PRESERVE-RETRY-STAGE is non-nil, continue an automatic retry."
  (ytm-radio--ensure-program ytm-radio-mpv-program "mpv")
  (unless (map-elt track :url)
    (user-error "Track has no playable URL"))
  (ytm-radio--sync-queue-index track)
  (unless (or (ytm-radio--restart-current-track-in-place track)
              (ytm-radio--load-track-in-current-mpv track))
    (ytm-radio--stop-process preserve-retry-stage)
    (pcase-let* ((`(,playback-url ,using-stream-cache)
                  (ytm-radio--playback-url-choice track))
                 (socket (make-temp-name
                          (file-name-concat temporary-file-directory "ytm-radio-mpv-")))
                 (args (ytm-radio--mpv-arguments socket playback-url))
                 (process (apply #'start-process
                                 "ytm-radio-mpv" nil ytm-radio-mpv-program args)))
      (set-process-sentinel process #'ytm-radio--mpv-sentinel)
      (setf (map-elt ytm-radio--player :process) process
            (map-elt ytm-radio--player :socket) socket)
      (ytm-radio--set-current-track-state
       track 'loading nil playback-url using-stream-cache preserve-retry-stage)
      (ytm-radio--save)
      (ytm-radio--mpv-connect socket process 0)
      (ytm-radio--render)
      (ytm-radio--auto-show-now-playing)))
  (ytm-radio--refresh-track-status track)
  (ytm-radio--schedule-next-track-prefetch track))

(defun ytm-radio--resolve-account-track-and-play
    (track preserve-retry-stage)
  "Resolve account TRACK and play it.
When PRESERVE-RETRY-STAGE is non-nil, retain the automatic retry state."
  (unless (ytm-radio--direct-stream-cache-supported-p)
    (user-error "Authenticated playback requires direct stream proxy support"))
  (ytm-radio--sync-queue-index track)
  (ytm-radio--stop-process preserve-retry-stage)
  (ytm-radio--set-current-track-state
   track 'loading nil nil nil preserve-retry-stage)
  (ytm-radio--save)
  (ytm-radio--render)
  (ytm-radio--auto-show-now-playing)
  (ytm-radio--with-account-auth
   (lambda ()
     (let (process)
       (setq
        process
        (ytm-radio--resolve-stream-async
         track
         (lambda (url)
           (when (eq process ytm-radio--playback-resolve-process)
             (setq ytm-radio--playback-resolve-process nil)
             (ytm-radio--cache-stream-url track url)
             (ytm-radio--play-track-now track preserve-retry-stage)))
         (lambda (helper-error)
           (when (eq process ytm-radio--playback-resolve-process)
             (setq ytm-radio--playback-resolve-process nil)
             (ytm-radio--set-status 'stopped)
             (ytm-radio--handle-account-helper-error
              helper-error
              (lambda ()
                (ytm-radio--play-track track preserve-retry-stage)))))))
       (setq ytm-radio--playback-resolve-process process)))
   "YouTube Music login required"))

(defun ytm-radio--play-track (track &optional preserve-retry-stage)
  "Play TRACK with mpv.
When PRESERVE-RETRY-STAGE is non-nil, continue an automatic retry."
  (if (and (map-elt track :account-auth)
           (not (ytm-radio--cached-stream-url track)))
      (ytm-radio--resolve-account-track-and-play track preserve-retry-stage)
    (ytm-radio--play-track-now track preserve-retry-stage)))

(defun ytm-radio--mpv-connect (socket process attempt)
  "Connect to mpv SOCKET for PROCESS, retrying from ATTEMPT."
  (when (and (< attempt 40)
             (process-live-p process)
             (eq process (map-elt ytm-radio--player :process)))
    (condition-case nil
        (let ((ipc (make-network-process
                    :name "ytm-radio-mpv-ipc"
                    :family 'local
                    :service socket
                    :coding 'utf-8
                    :noquery t
                    :filter #'ytm-radio--mpv-filter)))
          (process-put ipc 'pending "")
          (process-put ipc 'request-id 0)
          (process-put ipc 'callbacks (make-hash-table :test 'eql))
          (setf (map-elt ytm-radio--player :ipc-process) ipc)
          (ytm-radio--mpv-send (list "observe_property" 1 "pause"))
          (ytm-radio--mpv-send (list "observe_property" 2 "core-idle"))
          (ytm-radio--mpv-send (list "observe_property" 3 "time-pos"))
          (ytm-radio--mpv-send (list "observe_property" 4 "duration")))
      (error
       (run-at-time 0.05 nil
                    #'ytm-radio--mpv-connect socket process (1+ attempt))))))

(defun ytm-radio--mpv-send (command)
  "Send COMMAND to the current mpv IPC process."
  (when-let* ((ipc (map-elt ytm-radio--player :ipc-process))
              ((ytm-radio--mpv-ipc-writable-p ipc)))
    (condition-case nil
        (progn
          (process-send-string
           ipc
           (concat (json-encode (list (cons 'command command))) "\n"))
          t)
      (error
       (when (eq ipc (map-elt ytm-radio--player :ipc-process))
         (setf (map-elt ytm-radio--player :ipc-process) nil))
       nil))))

(defun ytm-radio--render-now-playing-without-fit ()
  "Render the now-playing buffer without resizing its child frame."
  (let ((ytm-radio--inhibit-frame-fit t))
    (ytm-radio--render-now-playing)))

(defun ytm-radio--display-second (seconds)
  "Return SECONDS rounded down for display, or nil."
  (and (numberp seconds) (floor seconds)))

(defun ytm-radio--progress-render-key ()
  "Return the progress state currently visible in now-playing."
  (when-let* ((track (ytm-radio--current-track)))
    (list (map-elt track :id)
          (ytm-radio--display-second (map-elt ytm-radio--player :position))
          (ytm-radio--display-second
           (or (map-elt ytm-radio--player :duration)
               (map-elt track :duration))))))

(defun ytm-radio--side-window-visible-p ()
  "Return non-nil when the ytm-radio side-window view is visible."
  (and (window-live-p ytm-radio--side-window)
       (eq (window-buffer ytm-radio--side-window)
           (get-buffer ytm-radio--now-playing-buffer-name))))

(defun ytm-radio--now-playing-visible-p ()
  "Return non-nil when now-playing is visible."
  (or (ytm-radio--side-window-visible-p)
      (and (frame-live-p ytm-radio--frame)
           (frame-visible-p ytm-radio--frame))
      (get-buffer-window ytm-radio--now-playing-buffer-name t)))

(defun ytm-radio--render-visible-now-playing-without-fit ()
  "Render the visible now-playing surface without child-frame fitting."
  (if (and (eq ytm-radio-display-style 'side-window)
           (ytm-radio--side-window-visible-p))
      (ytm-radio--render-side-window)
    (ytm-radio--render-now-playing-without-fit)))

(defun ytm-radio--tty-child-frames-supported-p ()
  "Return non-nil when the current TTY can display child frames."
  (and (not (display-graphic-p))
       (featurep 'tty-child-frames)))

(defun ytm-radio--child-frame-supported-p ()
  "Return non-nil when now-playing child frames can be used."
  (or (display-graphic-p)
      (ytm-radio--tty-child-frames-supported-p)))

(defun ytm-radio--run-progress-render ()
  "Run a pending throttled progress refresh."
  (setq ytm-radio--progress-render-timer nil)
  (when (and (ytm-radio--now-playing-visible-p)
             (not (equal (ytm-radio--progress-render-key)
                         ytm-radio--last-rendered-progress-key)))
    (ytm-radio--render-visible-now-playing-without-fit)))

(defun ytm-radio--schedule-progress-render ()
  "Schedule a throttled now-playing progress refresh."
  (when (and (ytm-radio--now-playing-visible-p)
             (not (equal (ytm-radio--progress-render-key)
                         ytm-radio--last-rendered-progress-key))
             (not (timerp ytm-radio--progress-render-timer)))
    (setq ytm-radio--progress-render-timer
          (run-at-time ytm-radio-progress-refresh-interval
                       nil
                       #'ytm-radio--run-progress-render))))

(defun ytm-radio--cancel-progress-render ()
  "Cancel any pending now-playing progress refresh."
  (when (timerp ytm-radio--progress-render-timer)
    (cancel-timer ytm-radio--progress-render-timer)
    (setq ytm-radio--progress-render-timer nil)))

(defun ytm-radio--reset-title-scroll ()
  "Reset now-playing title marquee state."
  (when (timerp ytm-radio--title-scroll-timer)
    (cancel-timer ytm-radio--title-scroll-timer))
  (setq ytm-radio--title-scroll-timer nil
        ytm-radio--title-scroll-offset 0
        ytm-radio--title-scroll-key nil))

(defun ytm-radio--run-title-scroll ()
  "Advance and render a pending now-playing title marquee frame."
  (setq ytm-radio--title-scroll-timer nil)
  (when (and (ytm-radio--now-playing-visible-p)
             (ytm-radio--current-track))
    (setq ytm-radio--title-scroll-offset
          (1+ ytm-radio--title-scroll-offset))
    (ytm-radio--render-visible-now-playing-without-fit)))

(defun ytm-radio--schedule-title-scroll ()
  "Schedule a now-playing title marquee frame."
  (unless (timerp ytm-radio--title-scroll-timer)
    (setq ytm-radio--title-scroll-timer
          (run-at-time ytm-radio-title-scroll-interval
                       nil
                       #'ytm-radio--run-title-scroll))))

(defun ytm-radio--set-playback-property (property value)
  "Set playback PROPERTY to VALUE and refresh the now-playing view."
  (setf (map-elt ytm-radio--player property) value)
  (if (eq property :position)
      (ytm-radio--schedule-progress-render)
    (ytm-radio--render-visible-now-playing-without-fit)))

(defun ytm-radio--mpv-filter (process output)
  "Parse newline-delimited JSON OUTPUT from mpv PROCESS."
  (when (ytm-radio--current-mpv-ipc-p process)
    (let ((pending (concat (process-get process 'pending) output)))
      (while (string-match "\n" pending)
        (let ((line-end (match-beginning 0))
              (next-start (match-end 0)))
          (ytm-radio--mpv-dispatch process
                                   (substring pending 0 line-end))
          (setq pending (substring pending next-start))))
      (process-put process 'pending pending))))

(defun ytm-radio--mpv-dispatch (process line)
  "Dispatch one mpv JSON message LINE from PROCESS."
  (when-let* (((ytm-radio--current-mpv-ipc-p process))
              (msg (ignore-errors
                     (json-parse-string line
                                        :object-type 'alist
                                        :null-object nil
                                        :false-object nil)))
              (event (map-elt msg 'event)))
    (ytm-radio--mpv-event event msg)))

(defun ytm-radio--mpv-event (event msg)
  "Mirror mpv EVENT and MSG into player state."
  (pcase event
    ("property-change"
     (pcase (map-elt msg 'name)
       ("pause"
        (ytm-radio--set-status (if (map-elt msg 'data) 'paused 'playing)))
       ("core-idle"
        (when (not (map-elt msg 'data))
          (ytm-radio--set-status 'playing)))
       ("time-pos"
        (ytm-radio--set-playback-property :position (map-elt msg 'data)))
       ("duration"
        (ytm-radio--set-playback-property :duration (map-elt msg 'data)))))
    ("end-file"
     (when (equal (map-elt msg 'reason) "error")
       (unless (ytm-radio--retry-current-track-after-error)
         (ytm-radio--set-status 'stopped)
         (message "Playback error: %s"
                  (or (map-elt msg 'file_error) "unknown error")))))))

(defun ytm-radio--mpv-sentinel (process _event)
  "Advance when mpv PROCESS exits cleanly."
  (when (and (not (process-live-p process))
             (eq process (map-elt ytm-radio--player :process)))
    (if-let* ((current (map-elt ytm-radio--player :current-track))
              (exit-code (process-exit-status process))
              (next (and (zerop exit-code)
                         (ytm-radio--next-track current t))))
        (ytm-radio--play-track next)
      (unless (and (not (zerop (process-exit-status process)))
                   (ytm-radio--retry-current-track-after-error))
        (ytm-radio--stop-process)
        (ytm-radio--render)))))

(defun ytm-radio--same-track-p (left right)
  "Return non-nil when LEFT and RIGHT identify the same track."
  (and left
       right
       (equal (map-elt left :id) (map-elt right :id))))

(defun ytm-radio--track-alist-p (item)
  "Return non-nil when ITEM is a runtime track alist."
  (and item
       (map-elt item :url)
       (or (map-elt item :id)
           (map-elt item :title))))

(defun ytm-radio--random-track (&optional except)
  "Return a random known track, avoiding EXCEPT when possible."
  (let* ((tracks (ytm-radio--all-tracks))
         (candidates (seq-remove
                      (lambda (track)
                        (ytm-radio--same-track-p track except))
                      tracks))
         (choices (if candidates candidates tracks)))
    (when choices
      (nth (random (length choices)) choices))))

(defun ytm-radio--neighbor-track (track direction)
  "Return TRACK's neighbor in DIRECTION, either `next' or `previous'."
  (let ((tracks (ytm-radio--all-tracks)))
    (pcase direction
      ('next
       (seq-first
        (cdr (seq-drop-while
              (lambda (other)
                (not (equal (map-elt other :id) (map-elt track :id))))
              tracks))))
      ('previous
       (seq-first
        (seq-reverse
         (seq-take-while
         (lambda (other)
            (not (equal (map-elt other :id) (map-elt track :id))))
          tracks)))))))

(defun ytm-radio--track-index (track tracks)
  "Return TRACK's index in TRACKS, or nil."
  (or (cl-position track tracks :test #'eq)
      (cl-position track tracks :test #'ytm-radio--same-track-p)))

(defun ytm-radio--set-playback-queue (tracks current-track)
  "Set runtime playback queue to TRACKS around CURRENT-TRACK."
  (let* ((tracks (seq-filter #'identity tracks))
         (index (and current-track
                     (ytm-radio--track-index current-track tracks))))
    (setf (map-elt ytm-radio--player :queue) tracks
          (map-elt ytm-radio--player :queue-index) index)))

(defun ytm-radio--queue-source ()
  "Return the runtime playback queue as a browser source."
  (when-let* ((queue (map-elt ytm-radio--player :queue)))
    (ytm-radio--make-source
     :id "ytm:runtime:queue"
     :kind 'runtime-queue
     :title "Queue"
     :tracks queue)))

(defun ytm-radio--queue-current-index (track)
  "Return TRACK's current runtime queue index, or nil."
  (let ((queue (map-elt ytm-radio--player :queue))
        (index (map-elt ytm-radio--player :queue-index)))
    (cond
     ((and queue
           (integerp index)
           (<= 0 index)
           (< index (length queue))
           (eq (nth index queue) track))
      index)
     (queue
      (ytm-radio--track-index track queue)))))

(defun ytm-radio--sync-queue-index (track)
  "Keep the runtime queue index aligned with TRACK when possible."
  (when-let* ((queue (map-elt ytm-radio--player :queue))
              (index (ytm-radio--queue-current-index track)))
    (when (and (<= 0 index) (< index (length queue)))
      (setf (map-elt ytm-radio--player :queue-index) index))))

(defun ytm-radio--ensure-current-queue ()
  "Ensure a runtime queue exists for the current track and return it."
  (let ((track (ytm-radio--current-track)))
    (unless track
      (user-error "Nothing is playing"))
    (unless (map-elt ytm-radio--player :queue)
      (let ((tracks (or (ytm-radio--all-tracks) (list track))))
        (unless (ytm-radio--track-index track tracks)
          (setq tracks (cons track tracks)))
        (ytm-radio--set-playback-queue tracks track)))
    (map-elt ytm-radio--player :queue)))

(defun ytm-radio--queued-neighbor-track (track direction &optional automatic)
  "Return TRACK's neighbor in the runtime queue.
DIRECTION is either `next' or `previous'.  AUTOMATIC honors single-track
repeat when non-nil."
  (let* ((queue (map-elt ytm-radio--player :queue))
         (index (and queue (ytm-radio--queue-current-index track))))
    (when (and queue index)
      (cond
       ((and automatic (eq (ytm-radio--repeat-mode) 'one))
        track)
       ((map-elt ytm-radio--player :shuffle)
        (let* ((candidates (seq-remove
                            (lambda (queued)
                              (ytm-radio--same-track-p queued track))
                            queue))
               (choices (if candidates candidates queue)))
          (when choices
            (nth (random (length choices)) choices))))
       ((eq direction 'next)
        (or (nth (1+ index) queue)
            (and (eq (ytm-radio--repeat-mode) 'all)
                 (car queue))))
       ((eq direction 'previous)
        (or (and (> index 0)
                 (nth (1- index) queue))
            (and (eq (ytm-radio--repeat-mode) 'all)
                 (car (last queue)))))))))

(defun ytm-radio--next-track (track &optional automatic)
  "Return the known track after TRACK.
When AUTOMATIC is non-nil, honor single-track repeat."
  (or (ytm-radio--queued-neighbor-track track 'next automatic)
      (cond
       ((and automatic (eq (ytm-radio--repeat-mode) 'one))
        track)
       ((map-elt ytm-radio--player :shuffle)
        (ytm-radio--random-track track))
       ((ytm-radio--neighbor-track track 'next))
       ((eq (ytm-radio--repeat-mode) 'all)
        (car (ytm-radio--all-tracks))))))

(defun ytm-radio--previous-track (track)
  "Return the known track before TRACK."
  (or (ytm-radio--queued-neighbor-track track 'previous)
      (cond
       ((map-elt ytm-radio--player :shuffle)
        (ytm-radio--random-track track))
       ((ytm-radio--neighbor-track track 'previous))
       ((eq (ytm-radio--repeat-mode) 'all)
        (car (last (ytm-radio--all-tracks)))))))

;;; UI

(defvar ytm-radio--mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "a") #'ytm-radio-add-url)
    (define-key map (kbd "c") #'ytm-radio-now-playing)
    (define-key map (kbd "E") #'ytm-radio-explore)
    (define-key map (kbd "L") #'ytm-radio-library)
    (define-key map (kbd "H") #'ytm-radio-home)
    (define-key map (kbd "RET") #'ytm-radio-open-at-point)
    (define-key map (kbd "m") #'ytm-radio-more)
    (define-key map (kbd "j") #'ytm-radio-next-item)
    (define-key map (kbd "k") #'ytm-radio-previous-item)
    (define-key map (kbd "<down>") #'ytm-radio-next-item)
    (define-key map (kbd "<up>") #'ytm-radio-previous-item)
    (define-key map (kbd "g") #'ytm-radio-refresh)
    (define-key map (kbd "/") #'ytm-radio-search)
    (define-key map (kbd "TAB") #'ytm-radio-next-section)
    (define-key map (kbd "<backtab>") #'ytm-radio-previous-section)
    (define-key map (kbd "b") #'ytm-radio-back)
    (define-key map (kbd "s") #'ytm-radio-play-source)
    (define-key map (kbd "SPC") #'ytm-radio-toggle-pause)
    (define-key map (kbd "n") #'ytm-radio-next)
    (define-key map (kbd "p") #'ytm-radio-previous)
    (define-key map (kbd "A") #'ytm-radio-current-actions)
    (define-key map (kbd "l") #'ytm-radio-like-current-track)
    (define-key map (kbd "d") #'ytm-radio-dislike-current-track)
    (define-key map (kbd "R") #'ytm-radio-start-current-track-mix)
    (define-key map (kbd "P") #'ytm-radio-add-current-track-to-playlist)
    (define-key map (kbd "t") #'ytm-radio-toggle-current-track-library)
    (define-key map (kbd "S") #'ytm-radio-share)
    (define-key map (kbd "Q") #'ytm-radio-queue)
    (define-key map (kbd "f") #'ytm-radio-seek-forward)
    (define-key map (kbd "B") #'ytm-radio-seek-backward)
    (define-key map (kbd "q") #'ytm-radio-hide-browser)
    map)
  "Keymap for `ytm-radio--mode'.")

(defun ytm-radio--disable-ui-line-wrapping ()
  "Disable wrapping and extra line spacing in the current UI buffer."
  (setq-local truncate-lines t)
  (setq-local word-wrap nil)
  ;; Positive `line-spacing' creates visible seams between sliced images.
  (setq-local line-spacing 0))

(defun ytm-radio--buffer-text-scale-factor ()
  "Return the active default-face scale factor for the current buffer."
  (if (and (bound-and-true-p text-scale-mode)
           (boundp 'text-scale-mode-amount)
           (numberp text-scale-mode-amount)
           (boundp 'text-scale-mode-step)
           (numberp text-scale-mode-step))
      (expt text-scale-mode-step text-scale-mode-amount)
    1.0))

(defun ytm-radio--buffer-default-font-height ()
  "Return the current buffer's remapped default-face height in pixels."
  (let ((window (get-buffer-window (current-buffer) t)))
    (max 1
         (or (and (window-live-p window)
                  (ignore-errors (window-font-height window 'default)))
             (ceiling (* (frame-char-height (selected-frame))
                         (ytm-radio--buffer-text-scale-factor)))))))

(define-derived-mode ytm-radio--mode special-mode "ytm-radio"
  "Major mode for the ytm-radio browser buffer."
  (ytm-radio--disable-ui-line-wrapping)
  (setq-local mode-line-format nil)
  (setq-local header-line-format
              '(:eval (ytm-radio--browser-header-line)))
  (setq-local imenu-create-index-function
              #'ytm-radio--imenu-create-index)
  (add-hook 'text-scale-mode-hook
            #'ytm-radio--handle-browser-text-scale-change nil t)
  (add-hook 'post-command-hook #'ytm-radio--maybe-lazy-load-home nil t)
  (add-hook 'window-scroll-functions
            #'ytm-radio--maybe-lazy-load-home-on-scroll nil t))

(defvar ytm-radio--now-playing-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "SPC") #'ytm-radio-toggle-pause)
    (define-key map (kbd "n") #'ytm-radio-next)
    (define-key map (kbd "p") #'ytm-radio-previous)
    (define-key map (kbd "r") #'ytm-radio-cycle-repeat)
    (define-key map (kbd "s") #'ytm-radio-toggle-shuffle)
    (define-key map (kbd "l") #'ytm-radio-like-current-track)
    (define-key map (kbd "d") #'ytm-radio-dislike-current-track)
    (define-key map (kbd "R") #'ytm-radio-start-current-track-mix)
    (define-key map (kbd "P") #'ytm-radio-add-current-track-to-playlist)
    (define-key map (kbd "t") #'ytm-radio-toggle-current-track-library)
    (define-key map (kbd "S") #'ytm-radio-share)
    (define-key map (kbd "Q") #'ytm-radio-queue)
    (define-key map (kbd "q") #'ytm-radio-hide-now-playing)
    (dolist (event '([mouse-1] [down-mouse-1] [drag-mouse-1]
                     [double-mouse-1] [triple-mouse-1]
                     [mouse-2] [down-mouse-2] [drag-mouse-2]
                     [double-mouse-2] [triple-mouse-2]
                     [mouse-3] [down-mouse-3] [drag-mouse-3]
                     [double-mouse-3] [triple-mouse-3]))
      (define-key map event #'ignore))
    (dolist (command '(scroll-up-command scroll-down-command
                       scroll-up scroll-down scroll-left scroll-right
                       mwheel-scroll pixel-scroll-precision))
      (define-key map (vector 'remap command) #'ignore))
    map)
  "Keymap for `ytm-radio--now-playing-mode'.")

(define-derived-mode ytm-radio--now-playing-mode special-mode "ytm-radio-now"
  "Major mode for the ytm-radio now-playing child frame."
  (ytm-radio--disable-ui-line-wrapping)
  (setq-local mode-line-format nil)
  (setq-local cursor-type nil)
  (setq-local overflow-newline-into-fringe t)
  (setq-local fringe-indicator-alist
              (assq-delete-all
               'continuation
               (assq-delete-all 'truncation
                                (copy-tree fringe-indicator-alist))))
  (setq-local left-fringe-width 0)
  (setq-local right-fringe-width 0)
  (setq-local vertical-scroll-bar nil)
  (setq-local horizontal-scroll-bar nil)
  (setq-local indicate-buffer-boundaries nil)
  (setq-local indicate-empty-lines nil)
  (setq-local cursor-in-non-selected-windows nil)
  (add-hook 'window-scroll-functions #'ytm-radio--prevent-scroll nil t))

(defun ytm-radio--prevent-scroll (window start)
  "Keep WINDOW pinned to the top when START is moved by scrolling."
  (when (> start (point-min))
    (set-window-start window (point-min) t)))

(defun ytm-radio--buffer ()
  "Return the ytm-radio browser buffer, creating it when needed."
  (let ((buffer (get-buffer-create ytm-radio--library-buffer-name)))
    (with-current-buffer buffer
      (unless (derived-mode-p 'ytm-radio--mode)
        (ytm-radio--mode))
      (ytm-radio--disable-ui-line-wrapping))
    buffer))

(defun ytm-radio--now-playing-buffer ()
  "Return the now-playing buffer, creating it when needed."
  (let ((buffer (get-buffer-create ytm-radio--now-playing-buffer-name)))
    (with-current-buffer buffer
      (unless (derived-mode-p 'ytm-radio--now-playing-mode)
        (ytm-radio--now-playing-mode))
      (ytm-radio--disable-ui-line-wrapping)
      (setq-local tab-line-format nil))
    buffer))

(defun ytm-radio--track-title (track)
  "Return TRACK's display title."
  (or (and-let* ((title (map-elt track :title))
                 ((not (string-empty-p title))))
        title)
      (map-elt track :id)
      "Untitled"))

(defun ytm-radio--internal-youtube-music-id-p (text)
  "Return non-nil when TEXT looks like a YouTube Music internal id."
  (and (stringp text)
       (or (string-prefix-p "ytm:browse:" text)
           (string-match-p "\\`\\(?:VL\\|RD\\|MPRE\\|MPSP\\|MPED\\|UC[[:alnum:]_-]\\{8,\\}\\)[[:alnum:]_-]+\\'"
                           text))))

(defun ytm-radio--source-internal-title-p (title source)
  "Return non-nil when TITLE should not be shown for SOURCE."
  (and (stringp title)
       (let ((source-id (map-elt source :id)))
         (or (ytm-radio--internal-youtube-music-id-p title)
             (and (stringp source-id)
                  (string-prefix-p "ytm:browse:" source-id)
                  (string-match-p "\\`UC[[:alnum:]_-]+\\'" title)
                  (string-match-p (regexp-quote title) source-id))))))

(defun ytm-radio--source-generic-title (source)
  "Return a generic display title for SOURCE."
  (pcase (map-elt source :kind)
    ('youtube-music-album "Album")
    ('youtube-music-artist "Artist")
    ('youtube-channel "Channel")
    ('youtube-music-playlist "Playlist")
    ('youtube-music-podcast "Podcast")
    ('youtube-music-episode "Episode")
    ('youtube-music-detail "Detail")
    ('youtube-music-detail-section "Section")
    (_ nil)))

(defun ytm-radio--source-display-title (source)
  "Return SOURCE's display title."
  (or (and-let* ((title (map-elt source :title))
                 ((not (string-empty-p title)))
                 ((not (ytm-radio--source-internal-title-p title source))))
        title)
      (ytm-radio--source-generic-title source)
      (and-let* ((source-id (map-elt source :id))
                 ((not (ytm-radio--internal-youtube-music-id-p source-id))))
        source-id)
      "Untitled source"))

(defun ytm-radio--track-label (track)
  "Return the completion label for TRACK."
  (let* ((source (ytm-radio--source (map-elt track :source-id)))
         (source-title (or (and source
                                (ytm-radio--source-display-title source))
                           (map-elt track :source-id))))
    (if source-title
        (format "%s - %s" source-title (ytm-radio--track-title track))
      (ytm-radio--track-title track))))

(defun ytm-radio--format-duration (seconds)
  "Return SECONDS as a compact duration string."
  (when (numberp seconds)
    (setq seconds (floor seconds))
    (if (>= seconds 3600)
	        (format "%d:%02d:%02d"
	                (/ seconds 3600)
	                (% (/ seconds 60) 60)
	                (% seconds 60))
	      (format "%d:%02d" (/ seconds 60) (% seconds 60)))))

(defconst ytm-radio--progress-bar-max-width 16
  "Maximum number of cells used for the now-playing progress bar.")

(defconst ytm-radio--progress-bar-min-width 5
  "Minimum number of cells used for the now-playing progress bar.")

(defconst ytm-radio--progress-line-safety-columns 2
  "Extra text columns reserved to keep the progress line from wrapping.")

(defconst ytm-radio--progress-line-safety-pixels 2
  "Extra pixels reserved to keep the progress line from wrapping.")

(defun ytm-radio--progress-line-pixel-safety ()
  "Return a pixel safety margin for now-playing progress lines."
  (+ ytm-radio--progress-line-safety-pixels
     (* ytm-radio--progress-line-safety-columns
        (frame-char-width (ytm-radio--now-playing-frame)))))

(defun ytm-radio--progress-bar (position duration width)
  "Return a Unicode progress bar for POSITION, DURATION, and WIDTH.
When DURATION is not known, return a fixed-width placeholder bar."
  (when (>= width ytm-radio--progress-bar-min-width)
    (if (and (numberp duration)
             (> duration 0))
        (let* ((position (if (numberp position)
                             (min duration (max 0 position))
                           0))
               (ratio (/ (float position) duration))
               (filled (min width
                            (floor (* ratio width)))))
          (concat
           (propertize (make-string filled ?▰)
                       'face 'ytm-radio-progress-filled)
           (propertize (make-string (- width filled) ?▱) 'face 'shadow)))
      (propertize (make-string width ?▱) 'face 'shadow))))

(defun ytm-radio--progress-line-text (left-label bar right-label)
  "Return progress line text using LEFT-LABEL, BAR, and RIGHT-LABEL."
  (format "%s %s %s" left-label bar right-label))

(defun ytm-radio--progress-line-fits-p (line)
  "Return non-nil when progress LINE fits on one now-playing line."
  (if (display-graphic-p (ytm-radio--now-playing-frame))
      (<= (string-pixel-width line (current-buffer))
          (- (ytm-radio--now-playing-text-pixel-width)
             (ytm-radio--progress-line-pixel-safety)))
    (<= (string-width line)
        (- (ytm-radio--now-playing-text-width)
           ytm-radio--progress-line-safety-columns))))

(defun ytm-radio--progress-bar-width (left-label right-label position duration)
  "Return a progress bar width for POSITION and DURATION.
The bar is measured between LEFT-LABEL and RIGHT-LABEL."
  (let ((available (- (ytm-radio--now-playing-text-width)
                      (string-width left-label)
                      (string-width right-label)
                      2
                      ytm-radio--progress-line-safety-columns)))
    (when (>= available ytm-radio--progress-bar-min-width)
      (cl-loop
       for width downfrom (min ytm-radio--progress-bar-max-width available)
       downto ytm-radio--progress-bar-min-width
       for bar = (ytm-radio--progress-bar position duration width)
       for line = (and bar
                       (ytm-radio--progress-line-text
                        left-label bar right-label))
       when (and line (ytm-radio--progress-line-fits-p line))
       return width))))

(defun ytm-radio--playback-time-label (track)
  "Return a compact playback time label for TRACK."
  (let* ((position (map-elt ytm-radio--player :position))
         (duration (or (map-elt ytm-radio--player :duration)
                       (map-elt track :duration)))
         (position-label (ytm-radio--format-duration position))
         (duration-label (ytm-radio--format-duration duration))
         (left-label (or position-label "0:00"))
         (right-label (or duration-label "--:--")))
    (if-let* ((bar-width (ytm-radio--progress-bar-width left-label
                                                        right-label
                                                        position
                                                        duration))
              (bar (ytm-radio--progress-bar position duration bar-width)))
        (ytm-radio--progress-line-text left-label bar right-label)
      (let ((fallback (format "%s/%s" left-label right-label)))
        (if (ytm-radio--progress-line-fits-p fallback)
            fallback
          (ytm-radio--truncate fallback
                               (ytm-radio--now-playing-text-width)))))))

(defun ytm-radio--item-title (item)
  "Return ITEM's display title."
  (or (map-elt item 'title)
      (map-elt item :title)
      (map-elt item 'id)
      (map-elt item :id)
      "Untitled"))

(defun ytm-radio--item-type (item)
  "Return ITEM's display type."
  (or (map-elt item 'type)
      (map-elt item :type)
      (when (or (map-elt item :source-id)
                (ytm-radio--track-alist-p item)
                (ytm-radio--helper-track-item-p item))
        "track")
      "item"))

(defun ytm-radio--item-url (item)
  "Return ITEM's URL, if any."
  (or (map-elt item 'url)
      (map-elt item :url)))

(defun ytm-radio--item-browse-id (item)
  "Return ITEM's YouTube Music browse id, if any."
  (or (map-elt item 'browse-id)
      (map-elt item :browse-id)))

(defun ytm-radio--item-browse-params (item)
  "Return ITEM's YouTube Music browse params, if any."
  (or (map-elt item 'browse-params)
      (map-elt item :browse-params)))

(defun ytm-radio--item-playlist-id (item)
  "Return ITEM's YouTube Music playlist id, if any."
  (or (map-elt item 'playlist-id)
      (map-elt item :playlist-id)))

(defun ytm-radio--metadata-action-text-p (text)
  "Return non-nil when TEXT is a YouTube Music menu action."
  (let ((text (downcase (string-trim (or text "")))))
    (or (string-suffix-p " will play next" text)
        (string-suffix-p " added to queue" text)
        (and (string-prefix-p "save " text)
             (string-suffix-p " to library" text))
        (and (string-prefix-p "remove " text)
             (string-suffix-p " from library" text))
        (string-prefix-p "add to " text)
        (string-prefix-p "remove from " text)
        (string-prefix-p "save to " text)
        (string-prefix-p "subscribe to" text)
        (string-prefix-p "subscribed to" text)
        (string-prefix-p "unsubscribe from" text)
        (member text
                '("cancel"
                  "change privacy"
                  "create"
                  "download"
                  "edit playlist"
                  "go to album"
                  "go to artist"
                  "learn more"
                  "less"
                  "mix"
                  "more"
                  "more actions"
                  "more options"
                  "play"
                  "play next"
                  "radio"
                  "remove from library"
                  "remove from queue"
                  "save to library"
                  "share"
                  "shuffle"
                  "shuffle play"
                  "start mix"
                  "subscribe"
                  "subscribed"
                  "unsubscribe"
                  "unsubscribed")))))

(defun ytm-radio--source-header-noise-text-p (text)
  "Return non-nil when TEXT is non-metadata artist header noise."
  (let ((text (string-trim (or text ""))))
    (or (member text '("?" "??"))
        (string-match-p "\\`[0-9]+\\'" text))))

(defun ytm-radio--metadata-subtitle (subtitle)
  "Return SUBTITLE without YouTube Music menu actions."
  (when (and (stringp subtitle) (not (string-empty-p subtitle)))
    (let ((parts (seq-remove
                  #'ytm-radio--metadata-action-text-p
                  (mapcar #'string-trim
                          (split-string subtitle " - " t)))))
      (unless (null parts)
        (string-join parts " - ")))))

(defun ytm-radio--item-duration (item)
  "Return ITEM duration, falling back to current player duration."
  (or (map-elt item 'duration)
      (map-elt item :duration)
      (and-let* ((track (ytm-radio--current-track))
                 ((equal (or (map-elt item 'id)
                             (map-elt item :id))
                         (map-elt track :id))))
        (map-elt ytm-radio--player :duration))))

(defun ytm-radio--explicit-p (item)
  "Return non-nil when ITEM is marked as explicit content."
  (or (map-elt item 'explicit)
      (map-elt item :explicit)))

(defun ytm-radio--explicit-badge ()
  "Return the display badge for explicit content."
  (let ((icon (ytm-radio--mdicon "nf-md-alpha_e_box" nil)))
    (propertize (or icon (propertize "E" 'face 'ytm-radio-explicit-badge))
                'help-echo "Explicit")))

(defun ytm-radio--track-secondary-text (track face)
  "Return TRACK secondary text using FACE for non-badge text."
  (let (parts)
    (when (ytm-radio--explicit-p track)
      (push (ytm-radio--explicit-badge) parts))
    (when-let* ((artist (map-elt track :artist))
                ((not (string-empty-p artist))))
      (push (propertize artist 'face face) parts))
    (unless (null parts)
      (string-join (nreverse parts) " "))))

(defun ytm-radio--item-detail (item)
  "Return compact secondary text for ITEM."
  (string-join
   (delq nil
         (list (or (map-elt item 'artist) (map-elt item :artist))
               (or (map-elt item 'album) (map-elt item :album))
               (ytm-radio--metadata-subtitle
                (or (map-elt item 'subtitle) (map-elt item :subtitle)))
               (ytm-radio--format-duration (ytm-radio--item-duration item))))
   " - "))

(defun ytm-radio--item-type-label (item)
  "Return a compact fixed-width type label for ITEM."
  (pcase (ytm-radio--item-type item)
    ("track" (ytm-radio--mdicon "nf-md-music_note" "SONG"))
    ("playlist" (ytm-radio--mdicon "nf-md-playlist_music" "LIST"))
    ("album" (ytm-radio--mdicon "nf-md-album" "ALBM"))
    ("artist" (ytm-radio--mdicon "nf-md-account_music" "ARTS"))
    ("podcast" (ytm-radio--mdicon "nf-md-podcast" "POD"))
    ("episode" (ytm-radio--mdicon "nf-md-podcast" "EP"))
    (_ "ITEM")))

(defun ytm-radio--item-type-face (item)
  "Return the face used for ITEM's compact type label."
  (pcase (ytm-radio--item-type item)
    ("track" 'success)
    ("episode" 'success)
    ((or "playlist" "album") 'font-lock-keyword-face)
    ((or "artist" "podcast") 'font-lock-type-face)
    (_ 'shadow)))

(defun ytm-radio--truncate (text width)
  "Return TEXT truncated to WIDTH display columns."
  (truncate-string-to-width (or text "") width nil nil "..."))

(defun ytm-radio--truncate-to-pixel-width (text width &optional suffix)
  "Return TEXT truncated to WIDTH pixels in the current buffer.
When SUFFIX is non-nil, append it to truncated text."
  (let ((text (or text ""))
        (suffix (or suffix "")))
    (if (<= (string-pixel-width text (current-buffer)) width)
        text
      (cl-loop
       for columns downfrom (string-width text) downto 0
       for candidate = (if (zerop columns)
                           ""
                         (truncate-string-to-width
                          text columns nil nil suffix))
       when (<= (string-pixel-width candidate (current-buffer)) width)
       return candidate
       finally return ""))))

(defun ytm-radio--pad-right (text width)
  "Return TEXT padded on the right to display WIDTH columns."
  (let* ((text (or text ""))
         (padding (max 0 (- width (string-width text)))))
    (concat text (make-string padding ?\s))))

(defun ytm-radio--item-id (item)
  "Return ITEM's id, if any."
  (or (map-elt item 'id)
      (map-elt item :id)))

(defun ytm-radio--youtube-image-cdn-url-p (url)
  "Return non-nil when URL is a YouTube/Google thumbnail CDN URL."
  (and (stringp url)
       (string-match-p
        "\\`https://[^/]*\\(?:googleusercontent\\.com\\|ggpht\\.com\\)/"
        url)))

(defun ytm-radio--higher-resolution-thumbnail-url (url)
  "Return a higher-resolution variant of thumbnail URL when possible."
  (if (not (ytm-radio--youtube-image-cdn-url-p url))
      url
    (cond
     ((string-match "=w[0-9]+-h[0-9]+" url)
      (replace-match "=w544-h544" t t url))
     ((string-match "=s[0-9]+" url)
      (replace-match "=s544" t t url))
     (t url))))

(defun ytm-radio--item-thumbnail-url (item)
  "Return ITEM's thumbnail URL, deriving a YouTube fallback when possible."
  (ytm-radio--higher-resolution-thumbnail-url
   (or (map-elt item 'thumbnail-url)
       (map-elt item :thumbnail-url)
       (when (string-equal (ytm-radio--item-type item) "track")
         (when-let* ((id (ytm-radio--item-id item))
                     ((string-match-p "\\`[[:alnum:]_-]+\\'" id)))
           (format "https://i.ytimg.com/vi/%s/hqdefault.jpg" id))))))

(defun ytm-radio--view-kind ()
  "Return the kind of the current browser view."
  (if (symbolp ytm-radio--browser-view)
      ytm-radio--browser-view
    (or (map-elt ytm-radio--browser-view :kind) 'home)))

(defun ytm-radio--view-value (key)
  "Return current browser view value for KEY."
  (unless (symbolp ytm-radio--browser-view)
    (map-elt ytm-radio--browser-view key)))

(defun ytm-radio--current-root-view ()
  "Return the active top-level browser view, if any."
  (let ((kind (ytm-radio--view-kind))
        (origin (ytm-radio--view-value :origin-view)))
    (or (and (memq origin '(home explore library)) origin)
        (and (memq kind '(home explore library)) kind))))

(defun ytm-radio--root-view-p (view)
  "Return non-nil when VIEW is a root browser view."
  (memq view '(home explore library)))

(defun ytm-radio--browser-history-item-key (item)
  "Return a stable history key for ITEM, or nil."
  (when item
    (list (cons :id (ytm-radio--item-id item))
          (cons :url (ytm-radio--item-url item))
          (cons :title (ytm-radio--item-title item))
          (cons :type (ytm-radio--item-type item)))))

(defun ytm-radio--browser-history-snapshot (&optional source item)
  "Return a snapshot of the current browser view.
When SOURCE or ITEM are non-nil, use them as the semantic return target."
  (let* ((buffer (get-buffer ytm-radio--library-buffer-name))
         (window (and buffer (get-buffer-window buffer t)))
         point
         window-start)
    (when buffer
      (with-current-buffer buffer
        (setq point (if (window-live-p window)
                        (window-point window)
                      (point)))
        (setq window-start (and (window-live-p window)
                                (window-start window)))
        (unless source
          (setq source (ytm-radio--line-source-at-point)))
        (unless item
          (setq item (ytm-radio--line-item-at-point)))))
    (append
     (list (cons :view ytm-radio--browser-view))
     (when point
       (list (cons :point point)))
     (when window-start
       (list (cons :window-start window-start)))
     (when-let* ((source-id (map-elt source :id)))
       (list (cons :source-id source-id)))
     (when-let* ((item-key (ytm-radio--browser-history-item-key item)))
       (list (cons :item-key item-key))))))

(defun ytm-radio--browser-history-entry-view (entry)
  "Return browser view stored in history ENTRY."
  (if (and (listp entry) (assq :view entry))
      (map-elt entry :view)
    entry))

(defun ytm-radio--browser-history-entry-point (entry)
  "Return browser point stored in history ENTRY, or nil."
  (and (listp entry)
       (assq :view entry)
       (map-elt entry :point)))

(defun ytm-radio--browser-history-entry-window-start (entry)
  "Return browser window start stored in history ENTRY, or nil."
  (and (listp entry)
       (assq :view entry)
       (map-elt entry :window-start)))

(defun ytm-radio--browser-history-entry-source-id (entry)
  "Return source id stored in history ENTRY, or nil."
  (and (listp entry)
       (assq :view entry)
       (map-elt entry :source-id)))

(defun ytm-radio--browser-history-entry-item-key (entry)
  "Return item key stored in history ENTRY, or nil."
  (and (listp entry)
       (assq :view entry)
       (map-elt entry :item-key)))

(defun ytm-radio--remember-root-view-position ()
  "Remember point and window position for the current root browser view."
  (let ((view (ytm-radio--view-kind)))
    (when (ytm-radio--root-view-p view)
      (setf (alist-get view ytm-radio--root-view-positions)
            (ytm-radio--browser-history-snapshot)))))

(defun ytm-radio--root-view-position (view)
  "Return remembered browser position for root VIEW, or nil."
  (alist-get view ytm-radio--root-view-positions))

(defun ytm-radio--set-browser-view
    (view &optional replace history-entry restore-entry)
  "Set browser VIEW and remember history unless REPLACE is non-nil.
When HISTORY-ENTRY is non-nil, store it as the return entry.
When RESTORE-ENTRY is non-nil, restore that position after rendering VIEW."
  (ytm-radio--remember-root-view-position)
  (unless replace
    (push (or history-entry
              (ytm-radio--browser-history-snapshot))
          ytm-radio--browser-history))
  (setq ytm-radio--browser-view view)
  (ytm-radio--render-browser t restore-entry))

(defun ytm-radio--home-source-p (source)
  "Return non-nil when SOURCE belongs to the Home view."
  (ytm-radio--source-target-p source 'home))

(defun ytm-radio--library-source-p (source)
  "Return non-nil when SOURCE belongs to the Library view."
  (ytm-radio--source-target-p source 'library))

(defun ytm-radio--explore-source-p (source)
  "Return non-nil when SOURCE belongs to the Explore view."
  (ytm-radio--source-target-p source 'explore))

(defun ytm-radio--search-source-p (source)
  "Return non-nil when SOURCE belongs to the Search view."
  (ytm-radio--source-target-p source 'search))

(defun ytm-radio--browser-sources ()
  "Return sources selected by the current browser view."
  (let ((sources (map-values (ytm-radio--sources))))
    (pcase (ytm-radio--view-kind)
      ('home
       (or (seq-filter #'ytm-radio--home-source-p sources)
           sources))
      ('explore
       (seq-filter #'ytm-radio--explore-source-p sources))
      ('library
       (seq-filter #'ytm-radio--library-source-p sources))
      ('search
       (seq-filter #'ytm-radio--search-source-p sources))
      ('section
       (when-let* ((id (ytm-radio--view-value :source-id))
                   (source (if (string-equal id "ytm:runtime:queue")
                               (ytm-radio--queue-source)
                             (ytm-radio--source id))))
         (list source)))
      ('queue
       (when-let* ((source (ytm-radio--queue-source)))
         (list source)))
      ('detail
       (seq-remove #'ytm-radio--hidden-detail-source-p
                   (seq-keep #'ytm-radio--source
                             (ytm-radio--view-value :source-ids))))
      ('all sources)
      (_ sources))))

(defun ytm-radio--target-sources (target)
  "Return cached sources belonging to helper TARGET."
  (let ((sources (map-values (ytm-radio--sources))))
    (pcase target
      ("home" (seq-filter #'ytm-radio--home-source-p sources))
      ("explore" (seq-filter #'ytm-radio--explore-source-p sources))
      ("library" (seq-filter #'ytm-radio--library-source-p sources))
      (_ (seq-filter (lambda (source)
                       (ytm-radio--source-target-p source target))
                     sources)))))

(defun ytm-radio--target-cached-p (target)
  "Return non-nil when helper TARGET has cached sources."
  (not (null (ytm-radio--target-sources target))))

(defun ytm-radio--browser-title ()
  "Return title for the current browser view."
  (pcase (ytm-radio--view-kind)
    ('home "Home")
    ('explore "Explore")
    ('library "Library")
    ('search (or (ytm-radio--view-value :title) "Search"))
    ('section (or (ytm-radio--view-value :title) "Section"))
    ('queue "Queue")
    ('detail (or (ytm-radio--view-value :title) "Detail"))
    ('all "All")
    (_ "Home")))

(defun ytm-radio--browser-loading-status ()
  "Return a short loading status for the current browser view."
  (cond
   ((and (process-live-p ytm-radio--login-process)
         ytm-radio--login-status)
    ytm-radio--login-status)
   ((and ytm-radio--browser-loading-message
         (or (null ytm-radio--browser-loading-view)
             (equal ytm-radio--browser-loading-view
                    ytm-radio--browser-view)))
    ytm-radio--browser-loading-message)
   ((and (eq (ytm-radio--view-kind) 'home)
         ytm-radio--home-loading)
    (ytm-radio--home-loading-message))))

(defun ytm-radio--set-login-status (status)
  "Set browser login STATUS and refresh the header line."
  (setq ytm-radio--login-status status)
  (when-let* ((buffer (get-buffer ytm-radio--library-buffer-name)))
    (with-current-buffer buffer
      (force-mode-line-update))))

(defun ytm-radio--browser-root-active-p (view)
  "Return non-nil when root VIEW is the active browser root."
  (eq (ytm-radio--current-root-view) view))

(defun ytm-radio--browser-header-keymap (command)
  "Return a header-line keymap that runs COMMAND when clicked."
  (let ((map (make-sparse-keymap)))
    (define-key map [header-line down-mouse-1] #'ignore)
    (define-key map [header-line mouse-1] command)
    (define-key map [follow-link] 'mouse-face)
    map))

(defvar ytm-radio--browser-header-keymaps
  `((home . ,(ytm-radio--browser-header-keymap #'ytm-radio-home))
    (explore . ,(ytm-radio--browser-header-keymap #'ytm-radio-explore))
    (library . ,(ytm-radio--browser-header-keymap #'ytm-radio-library)))
  "Mouse keymaps for root items in the browser header line.")

(defun ytm-radio--browser-header-item (label view)
  "Return a header-line LABEL for root VIEW."
  (let ((active (ytm-radio--browser-root-active-p view)))
    (propertize label
                'face (if active
                          'ytm-radio-header-active
                        'ytm-radio-header-inactive)
                'keymap (alist-get view ytm-radio--browser-header-keymaps)
                'mouse-face 'mode-line-highlight
                'help-echo (format "Mouse-1: Open %s" label)
                'follow-link 'ignore)))

(defun ytm-radio--browser-current-page-header-item ()
  "Return a highlighted non-root page label for the header line, or nil."
  (pcase (ytm-radio--view-kind)
    ('search
     (propertize (or (ytm-radio--view-value :title) "Search")
                 'face 'ytm-radio-header-active))
    ('queue
     (propertize "Queue" 'face 'ytm-radio-header-active))
    (_ nil)))

(defun ytm-radio--faicon (name fallback)
  "Return nerd-icons Font Awesome NAME, or FALLBACK."
  (if (and (require 'nerd-icons nil t)
           (fboundp 'nerd-icons-faicon))
      (condition-case nil
          (funcall #'nerd-icons-faicon name :height 1.0)
        (error fallback))
    fallback))

(defun ytm-radio--append-face (string face)
  "Return a copy of STRING with FACE appended to existing faces."
  (let ((result (copy-sequence string)))
    (add-face-text-property 0 (length result) face t result)
    result))

(defun ytm-radio--browser-header-logo ()
  "Return the YouTube logo for the browser header line."
  (ytm-radio--append-face (ytm-radio--faicon "nf-fa-youtube" "YT")
                          'ytm-radio-header-logo))

(defun ytm-radio--browser-header-line ()
  "Return the ytm-radio browser header line."
  (let ((status (ytm-radio--browser-loading-status))
        (page (ytm-radio--browser-current-page-header-item)))
    (concat
     " "
     (ytm-radio--browser-header-logo)
     "    "
     (string-join
      (list (ytm-radio--browser-header-item "Home" 'home)
            (ytm-radio--browser-header-item "Explore" 'explore)
            (ytm-radio--browser-header-item "Library" 'library))
      "   ")
     (when page
       (concat "   " page))
     (when status
       (concat "  " (propertize status 'face 'shadow))))))

(defun ytm-radio--point-property (property)
  "Return PROPERTY at point or the previous character."
  (or (get-text-property (point) property)
      (and (> (point) (point-min))
           (get-text-property (1- (point)) property))))

(defun ytm-radio--button-at-point ()
  "Return a text button at point or the previous character."
  (or (button-at (point))
      (and (> (point) (point-min))
           (button-at (1- (point))))))

(defun ytm-radio--source-at-point ()
  "Return source stored at point, or nil."
  (ytm-radio--point-property 'ytm-radio-source))

(defun ytm-radio--item-at-point ()
  "Return item stored at point, or nil."
  (ytm-radio--point-property 'ytm-radio-item))

(defun ytm-radio--line-source-at-point ()
  "Return the nearest source stored on the current line."
  (or (ytm-radio--source-at-point)
      (save-excursion
        (beginning-of-line)
        (let ((end (line-end-position))
              source)
          (while (and (not source) (< (point) end))
            (setq source (get-text-property (point) 'ytm-radio-source))
            (goto-char (or (next-single-property-change
                            (point) 'ytm-radio-source nil end)
                           end)))
          source))))

(defun ytm-radio--source-has-hidden-items-p (source)
  "Return non-nil when SOURCE has hidden overview items."
  (and (not (memq (ytm-radio--view-kind) '(section queue)))
       (> (length (ytm-radio--source-items source))
          ytm-radio--browser-section-limit)))

(defun ytm-radio--more-source-at-point ()
  "Return the source at point when it has hidden items."
  (when-let* ((source (ytm-radio--line-source-at-point))
              ((ytm-radio--source-has-hidden-items-p source)))
    source))

(defun ytm-radio--enter-source (source &optional origin-view history-entry)
  "Show SOURCE as a focused section.
ORIGIN-VIEW is the top-level browser view that opened SOURCE.
HISTORY-ENTRY is the browser location to return to from the section."
  (let ((origin-view (or origin-view (ytm-radio--current-root-view))))
    (ytm-radio--set-browser-view
     (append
      (list (cons :kind 'section)
            (cons :source-id (map-elt source :id))
            (cons :title (ytm-radio--source-display-title source)))
      (when origin-view
        (list (cons :origin-view origin-view))))
     nil
     history-entry)))

(defun ytm-radio--playlist-browse-id (playlist-id)
  "Return the YouTube Music browse id for PLAYLIST-ID."
  (when (and (stringp playlist-id)
             (not (string-empty-p playlist-id)))
    (if (or (string-prefix-p "VL" playlist-id)
            (string-prefix-p "RD" playlist-id))
        playlist-id
      (concat "VL" playlist-id))))

(defun ytm-radio--url-query-value (query key)
  "Return KEY's value from URL QUERY string."
  (let ((value (cdr (assoc key (url-parse-query-string (or query ""))))))
    (if (listp value)
        (car value)
      value)))

(defun ytm-radio--music-url-detail-browse-id (url)
  "Return the detail browse id represented by YouTube Music URL."
  (when (and (stringp url)
             (string-match-p "\\`https?://" url))
    (let* ((parsed (url-generic-parse-url url))
           (host (downcase (or (url-host parsed) "")))
           (path (or (url-filename parsed) ""))
           (query-start (string-match-p "\\?" path))
           (path-only (if query-start
                          (substring path 0 query-start)
                        path))
           (query (and query-start
                       (substring path (1+ query-start)))))
      (when (string-suffix-p "music.youtube.com" host)
        (cond
         ((string-match "\\`/browse/\\([^/?#]+\\)" path-only)
          (match-string 1 path-only))
         ((string-equal path-only "/playlist")
          (ytm-radio--playlist-browse-id
           (ytm-radio--url-query-value query "list"))))))))

(defun ytm-radio--browse-endpoint (browse-id &optional params)
  "Return a helper browse endpoint for BROWSE-ID and PARAMS."
  (when (and (stringp browse-id)
             (not (string-empty-p browse-id)))
    (cons browse-id params)))

(defun ytm-radio--item-detail-browse (item)
  "Return ITEM's detail browse endpoint when it should use the helper."
  (let* ((type (ytm-radio--item-type item))
         (id (ytm-radio--item-id item))
         (playlist-browse-id
          (ytm-radio--playlist-browse-id (ytm-radio--item-playlist-id item)))
         (url-browse-id
         (ytm-radio--music-url-detail-browse-id (ytm-radio--item-url item)))
         (fallback-browse-id
          (when (member type '("album" "artist" "channel" "playlist"
                               "podcast" "episode" "item"))
            (cond
             ((and id (string-prefix-p "MPRE" id)) id)
             ((and id (string-prefix-p "MPSP" id)) id)
             ((and id (string-prefix-p "MPED" id)) id)
             ((and id (string-prefix-p "UC" id)) id)
             ((and id (or (string-prefix-p "VL" id)
                          (string-prefix-p "RD" id)))
              id)
             ((and id (string-equal type "playlist"))
              (ytm-radio--playlist-browse-id id))))))
    (or (ytm-radio--browse-endpoint
         (ytm-radio--item-browse-id item)
         (ytm-radio--item-browse-params item))
        (ytm-radio--browse-endpoint playlist-browse-id)
        (ytm-radio--browse-endpoint url-browse-id)
        (ytm-radio--browse-endpoint fallback-browse-id))))

(defun ytm-radio--item-detail-browse-id (item)
  "Return ITEM's detail browse id when it should open through the helper."
  (car-safe (ytm-radio--item-detail-browse item)))

(defun ytm-radio--open-url-as-source (url)
  "Fetch URL asynchronously and play it as a transient source."
  (ytm-radio--start-url-import url #'ytm-radio--play-source-object))

(defun ytm-radio--open-browse-id-as-source
    (browse-id &optional params context history-entry)
  "Fetch YouTube Music BROWSE-ID as a source and show it.
PARAMS is the optional YouTube Music browse endpoint params string.
CONTEXT is optional metadata from the item that opened the detail.
HISTORY-ENTRY is the browser location to return to from detail."
  (ytm-radio--start-browse-id-load browse-id params context history-entry))

(defun ytm-radio--open-item (source item)
  "Open ITEM from SOURCE using the browser's default action."
  (let ((track (ytm-radio--item-track item source))
        (browse (ytm-radio--item-detail-browse item))
        (url (ytm-radio--item-url item)))
    (cond
     (track
      (ytm-radio--set-playback-queue (ytm-radio--source-tracks source) track)
      (ytm-radio--play-track track))
     (browse
      (ytm-radio--open-browse-id-as-source
       (car browse)
       (cdr browse)
       item
       (ytm-radio--browser-history-snapshot source item)))
     (url
      (ytm-radio--open-url-as-source url))
     (t
      (user-error "Item has no action")))))

(defun ytm-radio--section-positions ()
  "Return positions of rendered browser section headings."
  (let (positions)
    (save-excursion
      (goto-char (point-min))
      (while (< (point) (point-max))
        (when (get-text-property (point) 'ytm-radio-section)
          (push (point) positions))
        (goto-char (or (next-single-property-change
                        (point) 'ytm-radio-section nil (point-max))
                       (point-max)))))
    (nreverse positions)))

(defun ytm-radio--imenu-create-index ()
  "Return an imenu index for Home, Explore, and Library sections."
  (when (memq (ytm-radio--view-kind) '(home explore library))
    (let (index)
      (dolist (position (ytm-radio--section-positions))
        (when-let* ((source (get-text-property position 'ytm-radio-source)))
          (push (cons (ytm-radio--source-display-title source) position)
                index)))
      (nreverse index))))

(defun ytm-radio--line-item-at-point ()
  "Return the item stored on the current line, or nil."
  (or (ytm-radio--item-at-point)
      (save-excursion
        (beginning-of-line)
        (let ((end (line-end-position))
              item)
          (while (and (not item) (< (point) end))
            (setq item (get-text-property (point) 'ytm-radio-item))
            (goto-char (or (next-single-property-change
                            (point) 'ytm-radio-item nil end)
                           end)))
          item))))

(defun ytm-radio--first-property-position (property)
  "Return the first buffer position containing PROPERTY, or nil."
  (save-excursion
    (goto-char (point-min))
    (let (position)
      (while (and (not position) (< (point) (point-max)))
        (when (get-text-property (point) property)
          (setq position (point)))
        (goto-char (or (next-single-property-change
                        (point) property nil (point-max))
                       (point-max))))
      position)))

(defun ytm-radio--browser-start-position ()
  "Return the preferred browser content start position."
  (or (ytm-radio--first-property-position 'ytm-radio-item)
      (ytm-radio--first-property-position 'ytm-radio-section)
      (point-min)))

(defun ytm-radio--browser-history-position (entry)
  "Return rendered buffer position for history ENTRY, or nil."
  (let ((source-id (ytm-radio--browser-history-entry-source-id entry))
        (item-key (ytm-radio--browser-history-entry-item-key entry))
        position)
    (when (or source-id item-key)
      (save-excursion
        (goto-char (point-min))
        (while (and (not position) (< (point) (point-max)))
          (let* ((source (get-text-property (point) 'ytm-radio-source))
                 (item (get-text-property (point) 'ytm-radio-item))
                 (current-source-id (map-elt source :id))
                 (current-item-key
                  (and item (ytm-radio--browser-history-item-key item))))
            (when (and (or (null source-id)
                           (equal current-source-id source-id))
                       (or (null item-key)
                           (equal current-item-key item-key)))
              (setq position (point))))
          (forward-char 1))))
    position))

(defun ytm-radio--restore-browser-point (old-point reset &optional history-entry)
  "Restore browser point after render.
OLD-POINT is the buffer position before render.  When RESET is non-nil,
move to the preferred content start.
When HISTORY-ENTRY is non-nil, restore its stored browser position."
  (if history-entry
      (let ((position (or (ytm-radio--browser-history-position history-entry)
                          (ytm-radio--browser-history-entry-point history-entry)
                          (ytm-radio--browser-start-position)))
            (window-start
             (ytm-radio--browser-history-entry-window-start history-entry)))
        (goto-char (min (max position (point-min)) (point-max)))
        (when-let* ((window (get-buffer-window (current-buffer) t))
                    ((window-live-p window)))
          (set-window-point window (point))
          (when (integerp window-start)
            (set-window-start
             window
             (min (max window-start (point-min)) (point-max))
             t))))
    (if reset
        (goto-char (ytm-radio--browser-start-position))
      (goto-char (min (max old-point (point-min)) (point-max)))
      (when (eobp)
        (goto-char (ytm-radio--browser-start-position))))))

(defun ytm-radio--move-item-line (direction)
  "Move point to the next item line in DIRECTION."
  (let ((origin (point))
        (current (ytm-radio--line-item-at-point))
        (step (if (< direction 0) -1 1))
        (found nil))
    (while (and (not found)
                (= 0 (forward-line step)))
      (when-let* ((candidate (ytm-radio--line-item-at-point)))
        (when (or (not current)
                  (not (eq candidate current)))
          (setq found t))))
    (unless found
      (goto-char origin)
      (user-error (if (< direction 0) "No previous item" "No next item")))))

(defun ytm-radio--view-import-spec (view)
  "Return the helper import spec for browser VIEW, or nil."
  (pcase (if (symbolp view) view (map-elt view :kind))
    ('home '("home" . "home recommendations"))
    ('explore '("explore" . "explore"))
    ('library '("library" . "library"))
    (_ nil)))

(defun ytm-radio--source-refresh-spec (source)
  "Return the helper refresh spec for SOURCE, or nil."
  (cond
   ((ytm-radio--source-target-p source "liked")
    '("liked" . "liked songs"))
   ((ytm-radio--source-target-p source "library-songs")
    '("library-songs" . "library songs"))
   ((ytm-radio--source-target-p source "library-albums")
    '("library-albums" . "library albums"))
   ((ytm-radio--source-target-p source "library-artists")
    '("library-artists" . "library artists"))
   ((ytm-radio--source-target-p source "library-playlists")
    '("library-playlists" . "library playlists"))
   ((ytm-radio--source-target-p source "library")
    '("library" . "library"))
   ((ytm-radio--source-target-p source "explore")
    '("explore" . "explore"))
   ((ytm-radio--source-target-p source "home")
    '("home" . "home recommendations"))))

(defun ytm-radio--detail-browse-id ()
  "Return the current detail view's browse id, or nil."
  (or (ytm-radio--view-value :browse-id)
      (when-let* ((source-id (car (ytm-radio--view-value :source-ids)))
                  ((string-match "\\`ytm:browse:\\([^:]+\\)" source-id)))
        (match-string 1 source-id))))

(defun ytm-radio--select-browser-view (view)
  "Switch to browser VIEW, clearing old content before loading when needed."
  (ytm-radio--set-browser-view
   view nil nil
   (and (ytm-radio--root-view-p view)
        (ytm-radio--root-view-position view)))
  (when-let* ((import-spec (ytm-radio--view-import-spec view))
              ((not (ytm-radio--target-cached-p (car import-spec)))))
    (if (eq view 'home)
        (ytm-radio--start-home-load)
      (ytm-radio--start-helper-target-load
       (car import-spec) (cdr import-spec) view))))

(defun ytm-radio--maybe-refresh-initial-home ()
  "Refresh Home once on first browser open, logging in when needed."
  (when (and (eq (ytm-radio--view-kind) 'home)
             (not ytm-radio--initial-home-refreshed)
             (not ytm-radio--home-loading)
             (or (not (ytm-radio--target-cached-p "home"))
                 (not (ytm-radio--home-continuation-known-p))))
    (ytm-radio--start-home-load)))

(defun ytm-radio--home-can-lazy-load-p ()
  "Return non-nil when Home can load its next continuation page."
  (and (eq (ytm-radio--view-kind) 'home)
       (ytm-radio--home-continuation)
       (not ytm-radio--home-loading)
       (not (process-live-p ytm-radio--home-process))))

(defun ytm-radio--near-buffer-end-p (position)
  "Return non-nil when POSITION is near the current buffer end."
  (or (>= position (point-max))
      (<= (count-lines position (point-max))
          ytm-radio-home-lazy-load-margin)))

(defun ytm-radio--home-lazy-load-window-p (window)
  "Return non-nil when WINDOW has reached the lazy-load threshold."
  (and (window-live-p window)
       (eq (window-buffer window) (current-buffer))
       (ytm-radio--home-can-lazy-load-p)
       (ytm-radio--near-buffer-end-p (window-end window t))))

(defun ytm-radio--maybe-lazy-load-home (&optional window)
  "Load the next Home continuation when WINDOW reaches the rendered end."
  (when-let* ((window (or window
                          (get-buffer-window (current-buffer) t)))
              ((ytm-radio--home-lazy-load-window-p window)))
    (ytm-radio--start-home-load t)))

(defun ytm-radio--maybe-lazy-load-home-on-scroll (window _start)
  "Load more Home content when WINDOW scrolls near the end."
  (with-current-buffer (window-buffer window)
    (ytm-radio--maybe-lazy-load-home window)))

(defun ytm-radio--insert-action-button (label action &optional face)
  "Insert a text button with LABEL running ACTION.
When FACE is non-nil, use it as the button face."
  (let ((start (point)))
    (insert-text-button label
                        'action (lambda (_button)
                                  (funcall action))
                        'follow-link t)
    (add-face-text-property start (point)
                            (or face 'ytm-radio-button) t)))

(defun ytm-radio--insert-browser-heading-padding ()
  "Insert thin vertical padding after the browser heading block."
  (insert ytm-radio--browser-heading-padding))

(defun ytm-radio--item-track (item source)
  "Return ITEM as a track owned by SOURCE, or nil."
  (cond
   ((map-elt item :source-id)
    item)
   ((ytm-radio--track-alist-p item)
    item)
   ((ytm-radio--helper-track-item-p item)
    (ytm-radio--track-from-helper-item
     item
     (map-elt source :id)
     (or (map-elt source :kind) 'account)))))

(defun ytm-radio--play-source-object (source)
  "Play the first track in SOURCE."
  (let ((track (car (ytm-radio--source-tracks source))))
    (unless track
      (user-error "Source has no playable tracks"))
    (ytm-radio--set-playback-queue (ytm-radio--source-tracks source) track)
    (ytm-radio--play-track track)))

(defun ytm-radio--browser-thumbnail-split-layout-p ()
  "Return non-nil when thumbnails should be split across item rows."
  (not (eq ytm-radio-browser-thumbnail-layout 'first-line)))

(defun ytm-radio--browser-thumbnail-pixel-size ()
  "Return the thumbnail canvas height for browser item rows."
  (if (ytm-radio--browser-thumbnail-split-layout-p)
      (+ (ytm-radio--browser-thumbnail-content-size)
         (ytm-radio--browser-thumbnail-gap-pixels))
    (ytm-radio--browser-thumbnail-content-size)))

(defun ytm-radio--browser-thumbnail-content-size ()
  "Return the thumbnail content edge size in pixels."
  (* 2 (ytm-radio--browser-thumbnail-row-height)))

(defun ytm-radio--browser-thumbnail-base-row-height ()
  "Return one unscaled text row height in pixels for thumbnails."
  (max (ytm-radio--buffer-default-font-height)
       (ceiling (/ (float ytm-radio-browser-thumbnail-size) 2))))

(defun ytm-radio--browser-thumbnail-row-height ()
  "Return one rendered text row height in pixels for thumbnails."
  (ceiling (* (ytm-radio--browser-thumbnail-base-row-height)
              ytm-radio-browser-item-line-height-scale)))

(defun ytm-radio--browser-thumbnail-gap-pixels ()
  "Return scaled extra thumbnail canvas height in pixels."
  (max 0 (- (ytm-radio--browser-thumbnail-content-size)
            (* 2 (ytm-radio--browser-thumbnail-base-row-height)))))

(defun ytm-radio--browser-thumbnail-slice-height ()
  "Return one split thumbnail slice height in pixels."
  (if (ytm-radio--browser-thumbnail-split-layout-p)
      (ceiling (/ (float (ytm-radio--browser-thumbnail-pixel-size)) 2))
    (ytm-radio--browser-thumbnail-row-height)))

(defun ytm-radio--browser-item-end-gap-height ()
  "Return the relative visual gap after first-line browser items."
  (let ((gap-pixels (ytm-radio--browser-thumbnail-gap-pixels)))
    (when (> gap-pixels 0)
      (/ (float gap-pixels)
         (ytm-radio--buffer-default-font-height)))))

(defun ytm-radio--browser-thumbnail-slot-width ()
  "Return thumbnail slot width in pixels."
  (ytm-radio--browser-thumbnail-content-size))

(defun ytm-radio--browser-thumbnail-columns ()
  "Return the display columns reserved for browser thumbnails."
  (let ((char-width (max 1 (frame-char-width (selected-frame)))))
    (max 6 (ceiling (/ (float (ytm-radio--browser-thumbnail-slot-width))
                       char-width)))))

(defun ytm-radio--item-type-cell (item)
  "Return ITEM's fixed-width type cell."
  (ytm-radio--pad-right (ytm-radio--item-type-label item) 4))

(defun ytm-radio--thumbnail-space ()
  "Return an empty thumbnail-width display string."
  (if (display-graphic-p)
      (propertize " "
                  'display
                  `(space :width (,(ytm-radio--browser-thumbnail-slot-width))))
    (make-string (ytm-radio--browser-thumbnail-columns) ?\s)))

(defun ytm-radio--buffer-u8 (position)
  "Return the unsigned byte at POSITION in the current unibyte buffer."
  (char-after position))

(defun ytm-radio--buffer-u16-be (position)
  "Return an unsigned big-endian 16-bit integer at POSITION."
  (+ (ash (ytm-radio--buffer-u8 position) 8)
     (ytm-radio--buffer-u8 (1+ position))))

(defun ytm-radio--buffer-u16-le (position)
  "Return an unsigned little-endian 16-bit integer at POSITION."
  (+ (ytm-radio--buffer-u8 position)
     (ash (ytm-radio--buffer-u8 (1+ position)) 8)))

(defun ytm-radio--buffer-u32-be (position)
  "Return an unsigned big-endian 32-bit integer at POSITION."
  (+ (ash (ytm-radio--buffer-u8 position) 24)
     (ash (ytm-radio--buffer-u8 (1+ position)) 16)
     (ash (ytm-radio--buffer-u8 (+ position 2)) 8)
     (ytm-radio--buffer-u8 (+ position 3))))

(defun ytm-radio--jpeg-dimensions ()
  "Return JPEG dimensions from the current unibyte buffer, or nil."
  (when (and (>= (point-max) 4)
             (= (ytm-radio--buffer-u8 1) #xff)
             (= (ytm-radio--buffer-u8 2) #xd8))
    (let ((position 3)
          dimensions)
      (while (and (not dimensions) (< position (point-max)))
        (while (and (< position (point-max))
                    (/= (ytm-radio--buffer-u8 position) #xff))
          (setq position (1+ position)))
        (while (and (< position (point-max))
                    (= (ytm-radio--buffer-u8 position) #xff))
          (setq position (1+ position)))
        (when (< position (point-max))
          (let ((marker (ytm-radio--buffer-u8 position)))
            (setq position (1+ position))
            (cond
             ((memq marker '(#xd8 #xd9 #x01)))
             ((= marker #xda)
              (setq position (point-max)))
             ((<= (+ position 8) (point-max))
              (let ((segment-length (ytm-radio--buffer-u16-be position)))
                (when (and (>= segment-length 7)
                           (memq marker '(#xc0 #xc1 #xc2 #xc3
                                           #xc5 #xc6 #xc7
                                           #xc9 #xca #xcb
                                           #xcd #xce #xcf)))
                  (setq dimensions
                        (cons (ytm-radio--buffer-u16-be (+ position 5))
                              (ytm-radio--buffer-u16-be (+ position 3)))))
                (setq position (+ position segment-length))))))))
      dimensions)))

(defun ytm-radio--png-dimensions ()
  "Return PNG dimensions from the current unibyte buffer, or nil."
  (when (and (>= (point-max) 24)
             (equal (buffer-substring-no-properties 1 9)
                    "\211PNG\r\n\032\n")
             (equal (buffer-substring-no-properties 13 17) "IHDR"))
    (cons (ytm-radio--buffer-u32-be 17)
          (ytm-radio--buffer-u32-be 21))))

(defun ytm-radio--gif-dimensions ()
  "Return GIF dimensions from the current unibyte buffer, or nil."
  (when (and (>= (point-max) 10)
             (member (buffer-substring-no-properties 1 7)
                     '("GIF87a" "GIF89a")))
    (cons (ytm-radio--buffer-u16-le 7)
          (ytm-radio--buffer-u16-le 9))))

(defun ytm-radio--file-cache-key (file &rest variants)
  "Return a cache key for FILE and VARIANTS using current file attributes."
  (when-let* (((stringp file))
              (attributes (file-attributes file)))
    (append (list (expand-file-name file)
                  (file-attribute-size attributes)
                  (file-attribute-modification-time attributes))
            variants)))

(defun ytm-radio--image-file-dimensions-uncached (file)
  "Return image dimensions in pixels for FILE, without consulting caches."
  (or (when-let* ((image (ignore-errors (create-image file nil nil))))
        (ignore-errors (image-size image t (selected-frame))))
      (with-temp-buffer
        (set-buffer-multibyte nil)
        (insert-file-contents-literally file nil 0 4096)
        (or (ytm-radio--jpeg-dimensions)
            (ytm-radio--png-dimensions)
            (ytm-radio--gif-dimensions)))))

(defun ytm-radio--image-file-dimensions (file)
  "Return image dimensions in pixels for FILE, or nil."
  (let ((key (ytm-radio--file-cache-key file 'dimensions)))
    (or (and key (gethash key ytm-radio--image-dimensions-cache))
        (let ((dimensions (ytm-radio--image-file-dimensions-uncached file)))
          (when (and key dimensions)
            (ytm-radio--cache-image-value
             ytm-radio--image-dimensions-cache key dimensions))
          dimensions))))

(defun ytm-radio--browser-thumbnail-display-size (file)
  "Return thumbnail display size for FILE without cropping."
  (let* ((content-size (ytm-radio--browser-thumbnail-content-size))
         (dimensions (ytm-radio--image-file-dimensions file)))
    (if (not dimensions)
        (cons content-size content-size)
      (let* ((natural-width (max 1 (ceiling (car dimensions))))
             (natural-height (max 1 (ceiling (cdr dimensions))))
             (scale (min (/ (float content-size) natural-width)
                         (/ (float content-size) natural-height))))
        (cons (max 1 (round (* natural-width scale)))
              (max 1 (round (* natural-height scale))))))))

(defun ytm-radio--image-mime-type (file)
  "Return a MIME type for image FILE, or nil when unsupported."
  (pcase (image-supported-file-p file)
    ('jpeg "image/jpeg")
    ('jpg "image/jpeg")
    ('png "image/png")
    ('gif "image/gif")
    ('webp "image/webp")
    ('svg "image/svg+xml")))

(defun ytm-radio--fit-rect (width height bounds-width bounds-height)
  "Return WIDTH and HEIGHT fitted inside BOUNDS-WIDTH by BOUNDS-HEIGHT."
  (let* ((scale (min (/ (float bounds-width) (max 1 width))
                     (/ (float bounds-height) (max 1 height))))
         (fit-width (max 1 (round (* width scale))))
         (fit-height (max 1 (round (* height scale)))))
    (list fit-width fit-height
          (/ (- bounds-width fit-width) 2)
          (/ (- bounds-height fit-height) 2))))

(defun ytm-radio--detail-header-row-height ()
  "Return one detail header row height in pixels."
  (let* ((char-height (ytm-radio--buffer-default-font-height))
         (padding (ceiling
                   (* char-height
                      ytm-radio--detail-header-row-height-padding-ratio))))
    (+ char-height padding)))

(defun ytm-radio--detail-header-row-count (&optional row-height)
  "Return the number of text rows reserved for detail headers.
When ROW-HEIGHT is non-nil, use it as the row height in pixels."
  (max 6
       (ceiling (/ (float ytm-radio-browser-header-height)
                   (max 1 (or row-height
                              (ytm-radio--detail-header-row-height)))))))

(defun ytm-radio--detail-header-cover-size (&optional row-height row-count)
  "Return detail header cover edge size in pixels.
When ROW-HEIGHT and ROW-COUNT are non-nil, use them for the size."
  (let* ((row-height (or row-height (ytm-radio--detail-header-row-height)))
         (row-count (or row-count
                        (ytm-radio--detail-header-row-count row-height))))
    (* row-count row-height)))

(defun ytm-radio--svg-detail-header-cover-image
    (file &optional row-height row-count)
  "Return a fixed-canvas detail header cover image for FILE.
When ROW-HEIGHT and ROW-COUNT are non-nil, size the canvas from them."
  (when (and (featurep 'svg)
             (image-type-available-p 'svg)
             (fboundp 'svg-create)
             (file-readable-p file))
    (when-let* ((mime-type (ytm-radio--image-mime-type file))
                (dimensions (ytm-radio--image-file-dimensions file)))
      (let* ((size (ytm-radio--detail-header-cover-size row-height row-count))
             (svg (svg-create size size))
             (fit (ytm-radio--fit-rect (ceiling (car dimensions))
                                       (ceiling (cdr dimensions))
                                       size
                                       size)))
        (condition-case nil
            (progn
              (svg-rectangle svg 0 0 size size :fill "#141414")
              (if (fboundp 'svg-embed-base-uri-image)
                  (svg-embed-base-uri-image
                   svg
                   (file-name-nondirectory file)
                   :x (nth 2 fit)
                   :y (nth 3 fit)
                   :width (nth 0 fit)
                   :height (nth 1 fit))
                (svg-embed
                 svg
                 file
                 mime-type
                 nil
                 :x (nth 2 fit)
                 :y (nth 3 fit)
                 :width (nth 0 fit)
                 :height (nth 1 fit)))
              (svg-rectangle svg 0 0 size size
                             :fill "none"
                             :stroke "#4b5050"
                             :stroke-width 1)
              (svg-image svg
                         :ascent 'center
                         :width size
                         :height size
                         :scale 1.0
                         :base-uri file))
          (error nil))))))

(defun ytm-radio--svg-thumbnail-image (file)
  "Return a fixed-canvas SVG thumbnail image for FILE, or nil."
  (when (and ytm-radio-browser-thumbnail-workaround-gaps
             (featurep 'svg)
             (image-type-available-p 'svg)
             (fboundp 'svg-create)
             (file-readable-p file))
    (when-let* ((mime-type (ytm-radio--image-mime-type file))
                (dimensions (ytm-radio--image-file-dimensions file)))
      (let* ((slot-width (ytm-radio--browser-thumbnail-slot-width))
             (slot-height (ytm-radio--browser-thumbnail-pixel-size))
             (content-size (ytm-radio--browser-thumbnail-content-size))
             (content-top (max 0 (/ (- slot-height content-size) 2)))
             (svg (svg-create slot-width slot-height))
             (fit (ytm-radio--fit-rect (ceiling (car dimensions))
                                       (ceiling (cdr dimensions))
                                       content-size
                                       content-size)))
        (condition-case nil
            (progn
              (if (fboundp 'svg-embed-base-uri-image)
                  (svg-embed-base-uri-image
                   svg
                   (file-name-nondirectory file)
                   :x (nth 2 fit)
                   :y (+ content-top (nth 3 fit))
                   :width (nth 0 fit)
                   :height (nth 1 fit))
                (svg-embed
                 svg
                 file
                 mime-type
                 nil
                 :x (nth 2 fit)
                 :y (+ content-top (nth 3 fit))
                 :width (nth 0 fit)
                 :height (nth 1 fit)))
              (svg-image svg
                         :ascent 'center
                         :width slot-width
                         :height slot-height
                         :scale 1.0
                         :base-uri file))
          (error nil))))))

(defun ytm-radio--placeholder-thumbnail-label (item)
  "Return a compact placeholder label for ITEM."
  (pcase (ytm-radio--item-type item)
    ("track" "TR")
    ("playlist" "PL")
    ("album" "AL")
    ("artist" "AR")
    (_ "YT")))

(defun ytm-radio--placeholder-thumbnail-fill (item)
  "Return placeholder fill color for ITEM."
  (pcase (ytm-radio--item-type item)
    ("track" "#23352f")
    ("playlist" "#263244")
    ("album" "#392f46")
    ("artist" "#2f3b35")
    (_ "#303336")))

(defun ytm-radio--placeholder-thumbnail-image (item)
  "Return a fixed-canvas placeholder thumbnail image for ITEM."
  (when (and (display-graphic-p)
             (featurep 'svg)
             (image-type-available-p 'svg)
             (fboundp 'svg-create))
    (let* ((slot-width (ytm-radio--browser-thumbnail-slot-width))
           (slot-height (ytm-radio--browser-thumbnail-pixel-size))
           (content-size (ytm-radio--browser-thumbnail-content-size))
           (content-top (max 0 (/ (- slot-height content-size) 2)))
           (font-size (max 9 (floor (* content-size 0.28))))
           (svg (svg-create slot-width slot-height)))
      (svg-rectangle svg 0 content-top content-size content-size
                     :fill (ytm-radio--placeholder-thumbnail-fill item))
      (svg-rectangle svg 0 content-top content-size content-size
                     :fill "none"
                     :stroke "#4b5050"
                     :stroke-width 1)
      (svg-text svg (ytm-radio--placeholder-thumbnail-label item)
                :x (/ content-size 2)
                :y (+ content-top (/ content-size 2))
                :fill "#d8dfd0"
                :font-size font-size
                :font-family "monospace"
                :font-weight "bold"
                :text-anchor "middle"
                :dominant-baseline "central")
      (list (svg-image svg
                       :ascent 'center
                       :width slot-width
                       :height slot-height
                       :scale 1.0)
            slot-width
            slot-height
            'fixed-canvas))))

(defun ytm-radio--source-placeholder-item (source)
  "Return a placeholder item descriptor for SOURCE."
  `((type . ,(pcase (map-elt source :kind)
               ('youtube-music-playlist "playlist")
               ('youtube-music-album "album")
               (_ "item")))
    (title . ,(ytm-radio--source-display-title source))))

(defun ytm-radio--svg-detail-header-placeholder-image
    (source &optional row-height row-count)
  "Return a fixed-canvas square detail placeholder image for SOURCE.
When ROW-HEIGHT and ROW-COUNT are non-nil, size the canvas from them."
  (when (and (display-graphic-p)
             (featurep 'svg)
             (image-type-available-p 'svg)
             (fboundp 'svg-create))
    (let* ((item (ytm-radio--source-placeholder-item source))
           (size (ytm-radio--detail-header-cover-size row-height row-count))
           (font-size (max 18 (floor (* size 0.18))))
           (svg (svg-create size size)))
      (svg-rectangle svg 0 0 size size
                     :fill (ytm-radio--placeholder-thumbnail-fill item))
      (svg-rectangle svg 0 0 size size
                     :fill "none"
                     :stroke "#4b5050"
                     :stroke-width 1)
      (svg-text svg (ytm-radio--placeholder-thumbnail-label item)
                :x (/ size 2)
                :y (/ size 2)
                :fill "#d8dfd0"
                :font-size font-size
                :font-family "monospace"
                :font-weight "bold"
                :text-anchor "middle"
                :dominant-baseline "central")
      (svg-image svg
                 :ascent 'center
                 :width size
                 :height size
                 :scale 1.0))))

(defun ytm-radio--thumbnail-image-cache-key (file)
  "Return the browser thumbnail image cache key for FILE."
  (ytm-radio--file-cache-key
   file
   'thumbnail
   ytm-radio-browser-thumbnail-size
   ytm-radio-browser-thumbnail-layout
   ytm-radio-browser-item-line-height-scale
   ytm-radio-browser-thumbnail-workaround-gaps
   (ytm-radio--buffer-default-font-height)
   (frame-char-width (selected-frame))))

(defun ytm-radio--thumbnail-image-from-file (file)
  "Return thumbnail image data for FILE."
  (let ((key (ytm-radio--thumbnail-image-cache-key file)))
    (or (and key (gethash key ytm-radio--thumbnail-image-cache))
        (let ((thumbnail
               (when-let* ((size (ytm-radio--browser-thumbnail-display-size file))
                           (image (or (ytm-radio--svg-thumbnail-image file)
                                      (ignore-errors
                                        (create-image file nil nil
                                                      :width (car size)
                                                      :height (cdr size)
                                                      :ascent 'center)))))
                 (when (eq (car-safe image) 'image)
                   (if (eq (plist-get (cdr image) :type) 'svg)
                       (list image
                             (ytm-radio--browser-thumbnail-slot-width)
                             (ytm-radio--browser-thumbnail-pixel-size)
                             'fixed-canvas)
                     (list image (car size) (cdr size)))))))
          (when (and key thumbnail)
            (ytm-radio--cache-image-value
             ytm-radio--thumbnail-image-cache key thumbnail))
          thumbnail))))

(defun ytm-radio--copy-thumbnail-descriptor (thumbnail)
  "Return a mutable copy of THUMBNAIL descriptor."
  (when (and thumbnail (eq (car-safe (car thumbnail)) 'image))
    (let ((copy (copy-sequence thumbnail)))
      (setcar copy (copy-sequence (car thumbnail)))
      copy)))

(defun ytm-radio--browser-thumbnail-state-key (url)
  "Return browser thumbnail state cache key for URL."
  (when (stringp url)
    (list url
          ytm-radio-browser-thumbnail-size
          ytm-radio-browser-thumbnail-layout
          ytm-radio-browser-item-line-height-scale
          ytm-radio-browser-thumbnail-workaround-gaps
          (ytm-radio--buffer-default-font-height)
          (frame-char-width (selected-frame)))))

(defun ytm-radio--remember-browser-thumbnail-state-key (url key)
  "Associate thumbnail state KEY with URL."
  (let ((keys (gethash url ytm-radio--browser-thumbnail-state-keys-by-url)))
    (unless (member key keys)
      (puthash url (cons key keys)
               ytm-radio--browser-thumbnail-state-keys-by-url))))

(defun ytm-radio--thumbnail-layout-compatible-p (state thumbnail)
  "Return non-nil when STATE can be mutated to THUMBNAIL in place."
  (and (eq (nth 3 state) (nth 3 thumbnail))
       (equal (nth 1 state) (nth 1 thumbnail))
       (equal (nth 2 state) (nth 2 thumbnail))))

(defun ytm-radio--mutate-thumbnail-state (state thumbnail)
  "Mutate thumbnail STATE so it displays THUMBNAIL's image."
  (when (and (ytm-radio--thumbnail-layout-compatible-p state thumbnail)
             (eq (car-safe (car state)) 'image)
             (eq (car-safe (car thumbnail)) 'image))
    (ignore-errors (image-flush (car state)))
    (setcdr (car state) (copy-sequence (cdr (car thumbnail))))
    (setf (nth 1 state) (nth 1 thumbnail)
          (nth 2 state) (nth 2 thumbnail)
          (nth 3 state) (nth 3 thumbnail))
    t))

(defun ytm-radio--browser-thumbnail-state (url thumbnail &optional update)
  "Return mutable thumbnail state for URL initialized from THUMBNAIL.
When UPDATE is non-nil, mutate an existing compatible state to THUMBNAIL."
  (when-let* ((key (ytm-radio--browser-thumbnail-state-key url)))
    (let ((state (gethash key ytm-radio--browser-thumbnail-state-cache)))
      (cond
       ((and state update)
        (if (ytm-radio--mutate-thumbnail-state state thumbnail)
            state
          (remhash key ytm-radio--browser-thumbnail-state-cache)
          (ytm-radio--browser-thumbnail-state url thumbnail)))
       (state state)
       ((setq state (ytm-radio--copy-thumbnail-descriptor thumbnail))
        (puthash key state ytm-radio--browser-thumbnail-state-cache)
        (ytm-radio--remember-browser-thumbnail-state-key url key)
        state)))))

(defun ytm-radio--remember-pending-browser-thumbnail (url)
  "Remember URL as a visible thumbnail still waiting to be downloaded."
  (when (and url (not (member url ytm-radio--browser-thumbnail-pending-urls)))
    (setq ytm-radio--browser-thumbnail-pending-urls
          (append ytm-radio--browser-thumbnail-pending-urls (list url)))))

(defun ytm-radio--browser-thumbnail-download-allowed-p (url)
  "Return non-nil when URL may start a thumbnail download now."
  (or (null ytm-radio--browser-thumbnail-download-budget)
      (ytm-radio--cover-download-in-flight-p url)
      (and (> ytm-radio--browser-thumbnail-download-budget 0)
           (progn
             (setq ytm-radio--browser-thumbnail-download-budget
                   (1- ytm-radio--browser-thumbnail-download-budget))
             t))))

(defun ytm-radio--item-thumbnail-image (item)
  "Return ITEM's thumbnail image data when available."
  (when (display-graphic-p)
    (if-let* ((url (ytm-radio--item-thumbnail-url item)))
        (if-let* ((file (ytm-radio--cover-file url))
                  (thumbnail (ytm-radio--thumbnail-image-from-file file)))
            (ytm-radio--browser-thumbnail-state url thumbnail t)
          (let ((state (ytm-radio--browser-thumbnail-state
                        url
                        (ytm-radio--placeholder-thumbnail-image item))))
            (cond
             ((ytm-radio--cover-download-in-flight-p url)
              (ytm-radio--ensure-cover-file
               url #'ytm-radio--thumbnail-download-finished))
             ((and (ytm-radio--cover-cache-path url)
                   (ytm-radio--browser-thumbnail-download-allowed-p url))
              (ytm-radio--ensure-cover-file
               url #'ytm-radio--thumbnail-download-finished))
             (t
              (ytm-radio--remember-pending-browser-thumbnail url)))
            state))
      (ytm-radio--placeholder-thumbnail-image item))))

(defun ytm-radio--thumbnail-slice (thumbnail slice)
  "Return THUMBNAIL display string for top or bottom SLICE."
  (let* ((slice-height (ytm-radio--browser-thumbnail-slice-height))
         (display (if (eq (nth 3 thumbnail) 'fixed-canvas)
                      `((slice 0
                               ,(if (eq slice 'top)
                                    0
                                  (max 0 (1- slice-height)))
                               1.0
                               ,slice-height)
                        ,(car thumbnail))
                    `((slice 0.0
                             ,(if (eq slice 'top) 0.0 0.49)
                             1.0001
                             0.51005)
                      ,(car thumbnail)))))
    (propertize " " 'display display 'line-height t)))

(defun ytm-radio--thumbnail-full (thumbnail)
  "Return THUMBNAIL display string for a full thumbnail cell."
  (propertize " " 'display (car thumbnail) 'line-height t))

(defun ytm-radio--insert-pixel-space (pixels)
  "Insert a horizontal display space of PIXELS."
  (when (> pixels 0)
    (insert (propertize " "
                        'display `(space :width (,pixels))))))

(defun ytm-radio--insert-thumbnail-cell (thumbnail slice)
  "Insert a thumbnail cell using THUMBNAIL and SLICE.
SLICE is either `top', `bottom', or nil for the full placeholder."
  (when (or thumbnail (display-graphic-p))
    (insert "  ")
    (cond
     ((and thumbnail (memq slice '(top bottom)))
      (let* ((image-width (cadr thumbnail))
             (empty-width (max 0 (- (ytm-radio--browser-thumbnail-slot-width)
                                    image-width)))
             (left-pad (/ empty-width 2))
             (right-pad (- empty-width left-pad)))
        (ytm-radio--insert-pixel-space left-pad)
        (insert (ytm-radio--thumbnail-slice thumbnail slice))
        (ytm-radio--insert-pixel-space right-pad)))
     (thumbnail
      (let* ((image-width (cadr thumbnail))
             (empty-width (max 0 (- (ytm-radio--browser-thumbnail-slot-width)
                                    image-width)))
             (left-pad (/ empty-width 2))
             (right-pad (- empty-width left-pad)))
        (ytm-radio--insert-pixel-space left-pad)
        (insert (ytm-radio--thumbnail-full thumbnail))
        (ytm-radio--insert-pixel-space right-pad)))
     (t
      (insert (ytm-radio--thumbnail-space))))
    (insert "  ")))

(defun ytm-radio--item-prefix-string (index _type-cell _item)
  "Return the first-line item prefix for INDEX."
  (propertize (format "%02d " index) 'face 'shadow))

(defun ytm-radio--item-detail-prefix-string (_index type-cell item)
  "Return the second-line item prefix for TYPE-CELL and ITEM."
  (ytm-radio--append-face type-cell (ytm-radio--item-type-face item)))

(defun ytm-radio--insert-aligned-prefix (prefix peer-prefix)
  "Insert PREFIX padded to align with PEER-PREFIX, plus a text gap."
  (insert prefix)
  (if (display-graphic-p)
      (let* ((prefix-width (string-pixel-width prefix (current-buffer)))
             (peer-width (string-pixel-width peer-prefix (current-buffer)))
             (gap-width (string-pixel-width "  " (current-buffer)))
             (target-width (+ (max prefix-width peer-width) gap-width)))
        (ytm-radio--insert-pixel-space (- target-width prefix-width)))
    (insert (make-string
             (+ (max 0 (- (string-width peer-prefix)
                          (string-width prefix)))
                2)
             ?\s))))

(defun ytm-radio--insert-item-prefix (prefix peer-prefix)
  "Insert item PREFIX aligned with PEER-PREFIX."
  (ytm-radio--insert-aligned-prefix prefix peer-prefix))

(defun ytm-radio--insert-detail-prefix (prefix peer-prefix)
  "Insert detail PREFIX aligned with PEER-PREFIX."
  (ytm-radio--insert-aligned-prefix prefix peer-prefix))

(defun ytm-radio--insert-item-row-newline (gapless)
  "Insert a row newline.
When GAPLESS is non-nil, remove extra line spacing between thumbnail
slices so covers do not appear split in the middle."
  (insert (if gapless
              (propertize "\n" 'line-height t)
            "\n")))

(defun ytm-radio--insert-item-end-newline (&optional gap-height)
  "Insert an item-ending newline with optional visual GAP-HEIGHT."
  (insert (if (and gap-height (> gap-height 0))
              (propertize "\n" 'display `((height ,gap-height)))
            "\n")))

(defun ytm-radio--item-metadata (item)
  "Return structured metadata tokens for ITEM."
  (or (map-elt item 'metadata)
      (map-elt item :metadata)))

(defun ytm-radio--metadata-token-text (token)
  "Return display text for metadata TOKEN."
  (or (map-elt token 'text)
      (map-elt token :text)
      ""))

(defun ytm-radio--metadata-token-browse-id (token)
  "Return browse id for metadata TOKEN."
  (or (map-elt token 'browse-id)
      (map-elt token :browse-id)))

(defun ytm-radio--metadata-token-browse-params (token)
  "Return browse params for metadata TOKEN."
  (or (map-elt token 'browse-params)
      (map-elt token :browse-params)))

(defun ytm-radio--insert-metadata-token (token)
  "Insert one metadata TOKEN."
  (let ((text (ytm-radio--metadata-token-text token))
        (browse-id (ytm-radio--metadata-token-browse-id token))
        (params (ytm-radio--metadata-token-browse-params token)))
    (if (and browse-id (not (string-empty-p browse-id)))
        (ytm-radio--insert-action-button
         text
         (lambda () (ytm-radio--open-browse-id-as-source browse-id params))
         'shadow)
      (insert (propertize text 'face 'shadow)))))

(defun ytm-radio--insert-item-detail (item fallback-detail)
  "Insert ITEM detail, falling back to FALLBACK-DETAIL."
  (when (ytm-radio--explicit-p item)
    (insert (ytm-radio--explicit-badge))
    (insert (propertize " " 'face 'shadow)))
  (if-let* ((metadata (ytm-radio--item-metadata item)))
      (progn
        (mapc #'ytm-radio--insert-metadata-token metadata)
        (when-let* ((duration (ytm-radio--format-duration
                               (ytm-radio--item-duration item))))
          (insert (propertize " - " 'face 'shadow))
          (insert (propertize duration 'face 'shadow))))
    (unless (string-empty-p fallback-detail)
      (insert (propertize fallback-detail 'face 'shadow)))))

(defun ytm-radio--track-rating-indicator (track)
  "Return a display marker for TRACK's like status, or nil."
  (pcase (ytm-radio--track-like-status track)
    ('like
     (concat " " (ytm-radio--mdicon "nf-md-thumb_up" "▲")))
    ('dislike
     (concat " " (ytm-radio--mdicon "nf-md-thumb_down" "▼")))
    (_ nil)))

(defun ytm-radio--truthy-field-p (object field)
  "Return non-nil when OBJECT has truthy FIELD."
  (pcase field
    (:in-library
     (if (member (ytm-radio--item-type object) '("track" "episode"))
         (ytm-radio--track-library-status-p object)
       (eq (ytm-radio--detail-account-state object 'library) t)))
    (:subscribed
     (eq (ytm-radio--detail-account-state object 'subscription) t))
    (_
     (or (map-elt object field)
         (map-elt object (intern (substring (symbol-name field) 1)))))))

(defun ytm-radio--library-status-kind-p (kind)
  "Return non-nil when KIND can have a library bookmark state."
  (memq kind '(youtube-music-album youtube-music-playlist)))

(defun ytm-radio--subscription-status-kind-p (kind)
  "Return non-nil when KIND can have a subscription state."
  (memq kind '(youtube-music-artist youtube-channel)))

(defun ytm-radio--item-library-status-p (item)
  "Return non-nil when ITEM should show a library bookmark marker."
  (and (member (ytm-radio--item-type item) '("album" "playlist"))
       (ytm-radio--truthy-field-p item :in-library)))

(defun ytm-radio--item-subscription-status-p (item)
  "Return non-nil when ITEM should show a subscribed marker."
  (and (member (ytm-radio--item-type item) '("artist" "channel"))
       (ytm-radio--truthy-field-p item :subscribed)))

(defun ytm-radio--subscribed-icon ()
  "Return the icon used for subscribed artists and channels."
  (ytm-radio--mdicon "nf-md-account_check" "[✔]"))

(defun ytm-radio--item-status-indicator (source item)
  "Return a display marker for ITEM's account state in SOURCE, or nil."
  (cond
   ((and (not (ytm-radio--library-source-p source))
         (ytm-radio--item-library-status-p item))
    (concat " " (ytm-radio--mdicon "nf-md-bookmark" "[B]")))
   ((ytm-radio--item-subscription-status-p item)
    (concat " " (ytm-radio--subscribed-icon)))))

(defun ytm-radio--source-status-indicator (source)
  "Return a display marker for SOURCE's account state, or nil."
  (cond
   ((and (ytm-radio--library-status-kind-p (map-elt source :kind))
         (ytm-radio--truthy-field-p source :in-library))
    (concat " " (ytm-radio--mdicon "nf-md-bookmark" "[B]")))
   ((and (ytm-radio--subscription-status-kind-p (map-elt source :kind))
         (ytm-radio--truthy-field-p source :subscribed))
    (concat " " (ytm-radio--subscribed-icon)))))

(defun ytm-radio--track-title-width (width indicator)
  "Return title WIDTH after reserving room for INDICATOR."
  (if indicator
      (max 1 (- width (string-width indicator)))
    width))

(defun ytm-radio--insert-source-item (source item index)
  "Insert ITEM from SOURCE at one-based INDEX."
  (let* ((start (point))
         (detail (ytm-radio--truncate (ytm-radio--item-detail item) 84))
         (metadata (ytm-radio--item-metadata item))
         (explicit (ytm-radio--explicit-p item))
         (type-cell (ytm-radio--item-type-cell item))
         (prefix (ytm-radio--item-prefix-string index type-cell item))
         (detail-prefix
          (ytm-radio--item-detail-prefix-string index type-cell item))
         (thumbnail (ytm-radio--item-thumbnail-image item))
         (two-line-p (or thumbnail
                         metadata
                         explicit
                         (not (string-empty-p detail))))
         (split-layout-p (ytm-radio--browser-thumbnail-split-layout-p))
         (split-thumbnail-p (and thumbnail
                                 two-line-p
                                 split-layout-p))
         (first-line-thumbnail-p
          (and thumbnail
               (not split-layout-p)))
         (end-gap-height
          (and first-line-thumbnail-p
               two-line-p
               (ytm-radio--browser-item-end-gap-height)))
         (track (ytm-radio--item-track item source))
         (rating-indicator (ytm-radio--track-rating-indicator track))
         (item-status-indicator (ytm-radio--item-status-indicator source item))
         (status-indicator (or rating-indicator item-status-indicator))
         (title (ytm-radio--truncate
                 (ytm-radio--item-title item)
                 (ytm-radio--track-title-width 56 status-indicator)))
         (actionable (or track
                         (ytm-radio--item-detail-browse-id item)
                         (ytm-radio--item-url item))))
    (ytm-radio--insert-thumbnail-cell thumbnail
                                      (if split-thumbnail-p
                                          'top
                                        nil))
    (ytm-radio--insert-item-prefix prefix detail-prefix)
    (if actionable
      (ytm-radio--insert-action-button
       title
       (lambda () (ytm-radio--open-item source item))
       'ytm-radio-item-title)
    (insert title))
    (cond
     (rating-indicator
      (insert rating-indicator))
     (item-status-indicator
      (insert item-status-indicator)))
    (ytm-radio--insert-item-row-newline split-thumbnail-p)
    (when two-line-p
      (if split-thumbnail-p
          (ytm-radio--insert-thumbnail-cell thumbnail 'bottom)
        (ytm-radio--insert-thumbnail-cell nil nil))
      (ytm-radio--insert-detail-prefix detail-prefix prefix)
      (ytm-radio--insert-item-detail item detail)
      (ytm-radio--insert-item-end-newline end-gap-height))
    (add-text-properties start (point)
                         (list 'ytm-radio-source source
                               'ytm-radio-item item))))

(defun ytm-radio--source-items (source)
  "Return display items for SOURCE."
  (if (ytm-radio--container-list-source-p source)
      (or (map-elt source :items) nil)
    (or (map-elt source :items)
        (ytm-radio--source-tracks source)
        nil)))

(defun ytm-radio--count-label (count singular plural)
  "Return COUNT followed by SINGULAR or PLURAL."
  (format "%d %s" count (if (= count 1) singular plural)))

(defun ytm-radio--source-summary (source)
  "Return a compact item/track summary for SOURCE."
  (let* ((item-count (length (ytm-radio--source-items source)))
         (track-count (length (ytm-radio--source-tracks source))))
    (cond
     ((= item-count track-count)
      (ytm-radio--count-label track-count "track" "tracks"))
     ((zerop track-count)
      (ytm-radio--count-label item-count "item" "items"))
     (t
      (format "%s / %s"
              (ytm-radio--count-label item-count "item" "items")
              (ytm-radio--count-label track-count "track" "tracks"))))))

(defun ytm-radio--detail-context-item ()
  "Return the item metadata that opened the current detail view, if any."
  (ytm-radio--view-value :context))

(defun ytm-radio--source-context-item (source)
  "Return the context item that can enrich SOURCE, if any."
  (when-let* ((item (ytm-radio--detail-context-item)))
    (let ((item-type (ytm-radio--item-type item)))
      (when (or (and (eq (map-elt source :kind) 'youtube-music-album)
                     (string-equal item-type "album"))
                (and (eq (map-elt source :kind) 'youtube-music-playlist)
                     (string-equal item-type "playlist"))
                (and (eq (map-elt source :kind) 'youtube-music-artist)
                     (string-equal item-type "artist"))
                (and (eq (map-elt source :kind) 'youtube-channel)
                     (string-equal item-type "channel")))
        item))))

(defun ytm-radio--header-metadata-text (text)
  "Return TEXT formatted as compact header metadata."
  (when-let* ((text (ytm-radio--metadata-subtitle text)))
    (string-join (mapcar #'string-trim (split-string text " - " t)) " • ")))

(defun ytm-radio--source-subtitle (source)
  "Return SOURCE subtitle, if any."
  (when-let* ((subtitle (or (ytm-radio--header-metadata-text
                             (or (map-elt source :subtitle)
                                 (map-elt source 'subtitle)))
                            (and-let* ((item (ytm-radio--source-context-item
                                              source)))
                              (ytm-radio--header-metadata-text
                               (or (map-elt item 'subtitle)
                                   (map-elt item :subtitle)))))))
    (if (eq (map-elt source :kind) 'youtube-music-artist)
        (let ((parts (seq-remove
                      #'ytm-radio--source-header-noise-text-p
                      (mapcar #'string-trim (split-string subtitle " • " t)))))
          (unless (null parts)
            (string-join parts " • ")))
      subtitle)))

(defun ytm-radio--source-thumbnail-url (source)
  "Return SOURCE thumbnail URL, if any."
  (ytm-radio--higher-resolution-thumbnail-url
   (or (map-elt source :thumbnail-url)
       (map-elt source 'thumbnail-url)
       (and-let* ((item (ytm-radio--source-context-item source)))
         (ytm-radio--item-thumbnail-url item)))))

(defun ytm-radio--source-header-p (source)
  "Return non-nil when SOURCE is a metadata-only detail header."
  (and (null (ytm-radio--source-items source))
       (or (ytm-radio--source-subtitle source)
           (ytm-radio--source-thumbnail-url source)
           (ytm-radio--source-meaningful-square-header-p source))))

(defun ytm-radio--source-square-header-p (source)
  "Return non-nil when SOURCE should use a square detail cover."
  (memq (map-elt source :kind)
        '(youtube-music-album youtube-music-playlist youtube-music-artist
                              youtube-channel)))

(defun ytm-radio--source-generic-header-title-p (source)
  "Return non-nil when SOURCE only has its generic fallback title."
  (when-let* ((generic (ytm-radio--source-generic-title source)))
    (string-equal (ytm-radio--source-display-title source) generic)))

(defun ytm-radio--source-meaningful-square-header-p (source)
  "Return non-nil when SOURCE is an album/playlist header worth showing."
  (and (ytm-radio--source-square-header-p source)
       (not (ytm-radio--source-generic-header-title-p source))))

(defun ytm-radio--empty-detail-header-p (source)
  "Return non-nil when SOURCE is an empty helper detail header."
  (and (eq (ytm-radio--view-kind) 'detail)
       (ytm-radio--detail-header-source-p source)
       (not (ytm-radio--source-subtitle source))
       (not (ytm-radio--source-thumbnail-url source))
       (not (ytm-radio--source-meaningful-square-header-p source))))

(defun ytm-radio--generic-section-title-p (source)
  "Return non-nil when SOURCE has an internal fallback section title."
  (and (eq (ytm-radio--view-kind) 'detail)
       (eq (map-elt source :kind) 'youtube-music-detail-section)
       (let ((title (ytm-radio--source-display-title source)))
         (string-match-p "\\`\\(?:Home section\\|Section\\) [0-9]+\\'" title))))

(defun ytm-radio--synthetic-detail-content-source-p (source)
  "Return non-nil when SOURCE is content below a synthetic detail header."
  (and (eq (ytm-radio--view-kind) 'detail)
       (stringp (map-elt source :id))
       (when-let* ((header (ytm-radio--source
                            (concat (map-elt source :id) ":header"))))
         (ytm-radio--source-header-p header))))

(defun ytm-radio--empty-synthetic-detail-body-p (source)
  "Return non-nil when SOURCE is empty below a visible detail header."
  (and (eq (ytm-radio--view-kind) 'detail)
       (null (ytm-radio--source-items source))
       (ytm-radio--synthetic-detail-content-source-p source)))

(defun ytm-radio--hidden-detail-source-p (source)
  "Return non-nil when SOURCE should be omitted from a detail view."
  (or (ytm-radio--empty-detail-header-p source)
      (ytm-radio--empty-synthetic-detail-body-p source)))

(defun ytm-radio--headingless-detail-source-p (source)
  "Return non-nil when SOURCE should render without its own heading."
  (or (ytm-radio--generic-section-title-p source)
      (ytm-radio--synthetic-detail-content-source-p source)))

(defun ytm-radio--source-header-cover-image (source)
  "Return a sliced detail header cover image descriptor for SOURCE."
  (let* ((row-height (ytm-radio--detail-header-row-height))
         (row-count (ytm-radio--detail-header-row-count row-height))
         (cover
          (when-let* ((url (and (display-graphic-p)
                                (ytm-radio--source-thumbnail-url source)))
                      (file (ytm-radio--ensure-cover-file
                             url
                             (lambda (_url file)
                               (when file
                                 (ytm-radio--render-browser))))))
            (ytm-radio--svg-detail-header-cover-image
             file row-height row-count))))
    (when (and (not cover)
               (display-graphic-p)
               (ytm-radio--source-square-header-p source))
      (setq cover (ytm-radio--svg-detail-header-placeholder-image
                   source row-height row-count)))
    (when cover
      (list cover
            (ytm-radio--detail-header-cover-size row-height row-count)
            row-height
            row-count))))

(defun ytm-radio--detail-view-tracks ()
  "Return playable tracks in the current detail view."
  (seq-mapcat (lambda (source)
                (ytm-radio--source-tracks source))
              (ytm-radio--browser-sources)
              'list))

(defun ytm-radio--detail-view-items ()
  "Return display items in the current detail view."
  (seq-mapcat (lambda (source)
                (or (ytm-radio--source-items source) nil))
              (ytm-radio--browser-sources)
              'list))

(defun ytm-radio--format-long-total-duration (seconds)
  "Return SECONDS as a long human duration label."
  (when (and (numberp seconds) (> seconds 0))
    (let* ((seconds (floor seconds))
           (hours (/ seconds 3600))
           (minutes (% (/ seconds 60) 60))
           (parts nil))
      (when (> hours 0)
        (push (format "%d %s" hours (if (= hours 1) "hour" "hours")) parts))
      (when (> minutes 0)
        (push (format "%d %s" minutes
                      (if (= minutes 1) "minute" "minutes"))
              parts))
      (string-join (nreverse parts) ", "))))

(defun ytm-radio--detail-header-summary (source)
  "Return a user-facing detail header summary for SOURCE."
  (let* ((tracks (ytm-radio--detail-view-tracks))
         (items (ytm-radio--detail-view-items))
         (track-count (length tracks))
         (item-count (length items))
         (duration (seq-reduce
                    (lambda (total track)
                      (+ total (or (map-elt track :duration) 0)))
                    tracks
                    0))
         (count-label
          (cond
           ((and tracks
                 items
                 (/= item-count track-count))
            (format "%s / %s"
                    (ytm-radio--count-label item-count "item" "items")
                    (ytm-radio--count-label track-count "track" "tracks")))
           ((and tracks
                 (ytm-radio--source-square-header-p source))
            (ytm-radio--count-label track-count "song" "songs"))
           (tracks
            (ytm-radio--count-label track-count "track" "tracks"))
           (items
            (ytm-radio--count-label item-count "item" "items"))))
         (duration-label (ytm-radio--format-long-total-duration duration)))
    (string-join (delq nil (list count-label duration-label)) " • ")))

(defun ytm-radio--play-detail-view (&optional shuffle)
  "Play the current detail view.
When SHUFFLE is non-nil, start from a random track."
  (let* ((tracks (ytm-radio--detail-view-tracks))
         (track (and tracks
                     (if shuffle
                         (nth (random (length tracks)) tracks)
                       (car tracks)))))
    (unless tracks
      (user-error "Detail view has no playable tracks"))
    (when shuffle
      (setf (map-elt ytm-radio--player :shuffle) t))
    (ytm-radio--set-playback-queue tracks track)
    (ytm-radio--play-track track)))

(defun ytm-radio--detail-header-cover-slice (cover row)
  "Return COVER display slice for ROW."
  (let* ((row-height (nth 2 cover))
         (overlap (min ytm-radio--detail-header-cover-slice-overlap
                       (max 0 (1- row-height))))
         (slice-y (if (zerop row)
                      0
                    (max 0 (- (* row row-height) overlap)))))
    (propertize " "
                'display `((slice 0
                                  ,slice-y
                                  1.0
                                  ,row-height)
                            ,(car cover))
                'line-height t)))

(defun ytm-radio--detail-header-row-newline (cover)
  "Return a newline with the same display row height as COVER slices."
  (propertize "\n"
              'line-height
              (if cover
                  (let ((row-height (nth 2 cover)))
                    (cons row-height row-height))
                t)))

(defun ytm-radio--detail-header-apply-row-height (line cover)
  "Return LINE with the same row height as COVER, when available."
  (if cover
      (let ((row-height (nth 2 cover)))
        (propertize line 'line-height (cons row-height row-height)))
    line))

(defun ytm-radio--insert-detail-header-cover-cell (cover row)
  "Insert COVER cell for ROW."
  (when cover
    (insert "  ")
    (insert (ytm-radio--detail-header-cover-slice cover row))
    (insert "  ")))

(defun ytm-radio--detail-library-source-p (source)
  "Return non-nil when SOURCE supports library toggling."
  (ytm-radio--library-status-kind-p (map-elt source :kind)))

(defun ytm-radio--detail-subscription-source-p (source)
  "Return non-nil when SOURCE supports subscription toggling."
  (ytm-radio--subscription-status-kind-p (map-elt source :kind)))

(defun ytm-radio--detail-library-button-label (source)
  "Return the detail header library button label for SOURCE."
  (if (ytm-radio--truthy-field-p source :in-library)
      (concat (ytm-radio--mdicon "nf-md-bookmark" "B") " Saved")
    (concat (ytm-radio--mdicon "nf-md-bookmark_outline" "B") " Save")))

(defun ytm-radio--detail-subscription-button-label (source)
  "Return the detail header subscription button label for SOURCE."
  (if (ytm-radio--truthy-field-p source :subscribed)
      (concat (ytm-radio--subscribed-icon) " Subscribed")
    (concat (ytm-radio--mdicon "nf-md-account_plus_outline" "[+]") " Subscribe")))

(defun ytm-radio--detail-header-actions-p (source)
  "Return non-nil when SOURCE has any detail header action."
  (or (ytm-radio--detail-view-tracks)
      (and source
           (or (ytm-radio--detail-library-source-p source)
               (ytm-radio--detail-subscription-source-p source)))))

(defun ytm-radio--insert-detail-header-actions (&optional source)
  "Insert detail header action buttons for SOURCE."
  (when (ytm-radio--detail-view-tracks)
    (ytm-radio--insert-action-button
     (concat (ytm-radio--mdicon "nf-md-play" ">") " Play")
     (lambda () (ytm-radio--play-detail-view)))
    (insert "  ")
    (ytm-radio--insert-action-button
     (concat (ytm-radio--mdicon "nf-md-shuffle_variant" "S") " Shuffle")
     (lambda () (ytm-radio--play-detail-view t))))
  (when (and source (ytm-radio--detail-library-source-p source))
    (when (ytm-radio--detail-view-tracks)
      (insert "  "))
    (ytm-radio--insert-action-button
     (ytm-radio--detail-library-button-label source)
     (lambda () (ytm-radio-toggle-detail-library))))
  (when (and source (ytm-radio--detail-subscription-source-p source))
    (when (or (ytm-radio--detail-view-tracks)
              (ytm-radio--detail-library-source-p source))
      (insert "  "))
    (ytm-radio--insert-action-button
     (ytm-radio--detail-subscription-button-label source)
     (lambda () (ytm-radio-toggle-detail-subscription)))))

(defun ytm-radio--detail-title-with-indicator (title indicator width)
  "Return TITLE with INDICATOR while fitting WIDTH columns."
  (concat (propertize
           (ytm-radio--truncate
            title
            (ytm-radio--track-title-width width indicator))
           'face 'ytm-radio-detail-title)
          indicator))

(defun ytm-radio--detail-header-line (row title subtitle summary indicator)
  "Return detail header text for ROW using TITLE, SUBTITLE, SUMMARY, and INDICATOR."
  (pcase row
    (0 (ytm-radio--detail-title-with-indicator title indicator 48))
    (1 (unless (string-empty-p subtitle)
         (propertize (ytm-radio--truncate subtitle 64) 'face 'shadow)))
    (2 (unless (string-empty-p summary)
         (propertize summary 'face 'shadow)))
    (_ nil)))

(defun ytm-radio--detail-header-metadata-row-count (subtitle summary)
  "Return rows needed before detail header actions for SUBTITLE and SUMMARY."
  (cond
   ((not (string-empty-p summary)) 3)
   ((not (string-empty-p subtitle)) 2)
   (t 1)))

(defun ytm-radio--insert-source-header (source &optional omit-leading-space)
  "Insert metadata-only SOURCE as a detail header.
When OMIT-LEADING-SPACE is non-nil, do not insert the leading blank line."
  (let* ((title (ytm-radio--source-display-title source))
         (subtitle (or (ytm-radio--source-subtitle source) ""))
         (summary (ytm-radio--detail-header-summary source))
         (indicator (or (ytm-radio--source-status-indicator source) ""))
         (square-header-p (ytm-radio--source-square-header-p source)))
    (let* ((cover (and square-header-p
                       (ytm-radio--source-header-cover-image source)))
           (row-count (or (nth 3 cover) 5))
           (metadata-row-count
            (ytm-radio--detail-header-metadata-row-count subtitle summary))
           (inline-actions-p
            (and (ytm-radio--detail-header-actions-p source)
                 (< metadata-row-count row-count)))
           (start (point)))
      (unless omit-leading-space
        (insert "\n"))
      (dotimes (row row-count)
        (ytm-radio--insert-detail-header-cover-cell cover row)
        (if (and inline-actions-p
                 (= row (1- row-count)))
            (ytm-radio--insert-detail-header-actions source)
          (when-let* ((line (ytm-radio--detail-header-line
                             row title subtitle summary indicator)))
            (insert (ytm-radio--detail-header-apply-row-height
                     line cover))))
        (insert (ytm-radio--detail-header-row-newline cover)))
      (unless inline-actions-p
        (when (ytm-radio--detail-header-actions-p source)
          (insert "  ")
          (ytm-radio--insert-detail-header-actions source)
          (insert "\n")))
      (ytm-radio--insert-browser-heading-padding)
      (add-text-properties start (point)
                           (list 'ytm-radio-section t
                                 'ytm-radio-source source)))))

(defun ytm-radio--render ()
  "Render all visible ytm-radio buffers."
  (ytm-radio--render-browser)
  (ytm-radio--render-now-playing))

(defun ytm-radio--handle-browser-text-scale-change ()
  "Resize browser images after changing the current buffer text scale."
  (when (derived-mode-p 'ytm-radio--mode)
    (ytm-radio--render-browser)))

(defun ytm-radio--insert-source-section (source &optional omit-leading-space)
  "Insert SOURCE as a browser section.
When OMIT-LEADING-SPACE is non-nil, do not insert the leading blank line."
  (if (ytm-radio--source-header-p source)
      (ytm-radio--insert-source-header source omit-leading-space)
    (let* ((items (ytm-radio--source-items source))
           (overview (not (memq (ytm-radio--view-kind) '(section queue))))
           (visible-items (if overview
                              (seq-take items ytm-radio--browser-section-limit)
                            items))
           (headingless (ytm-radio--headingless-detail-source-p source))
           (start (point)))
      (unless (or omit-leading-space headingless)
        (insert "\n"))
      (unless headingless
        (insert-text-button (ytm-radio--source-display-title source)
                            'action (lambda (_button)
                                      (ytm-radio--enter-source source))
                            'follow-link t
                            'face 'ytm-radio-section-title)
        (add-text-properties start (point)
                             (list 'ytm-radio-section t
                                   'ytm-radio-source source))
        (insert "  "
                (propertize
                 (ytm-radio--source-summary source)
                 'face 'shadow)
                "\n")
        (ytm-radio--insert-browser-heading-padding))
      (cl-loop for item in visible-items
               for index from 1
               do (ytm-radio--insert-source-item source item index))
      (when (and overview (> (length items) (length visible-items)))
        (let ((more-start (point)))
          (insert "       ")
          (ytm-radio--insert-action-button
           (format "%d more" (- (length items) (length visible-items)))
           (lambda () (ytm-radio--enter-source source)))
          (add-text-properties more-start (point)
                               (list 'ytm-radio-source source)))
        (insert "\n")))))

(defun ytm-radio--render-browser (&optional reset-point history-entry)
  "Render the current package state into the browser buffer.
When RESET-POINT is non-nil, move point to the first browser content item.
When HISTORY-ENTRY is non-nil, restore its stored browser position."
  (when-let* ((buffer (get-buffer ytm-radio--library-buffer-name)))
    (with-current-buffer buffer
      (clrhash ytm-radio--browser-thumbnail-state-cache)
      (clrhash ytm-radio--browser-thumbnail-state-keys-by-url)
      (let ((inhibit-read-only t)
            (sources (ytm-radio--browser-sources))
            (old-point (point))
            (ytm-radio--browser-thumbnail-download-budget
             (when (numberp ytm-radio-browser-thumbnail-downloads-per-render)
               (max 0 ytm-radio-browser-thumbnail-downloads-per-render))))
        (setq ytm-radio--browser-thumbnail-pending-urls nil)
        (erase-buffer)
        (ytm-radio--insert-browser-heading-padding)
        (when (and (ytm-radio--empty-catalog-p)
                   (not sources))
          (insert "Add a URL, or import your YouTube Music library/home.\n")
          (insert "YouTube Music login opens automatically when needed.\n"))
        (cond
         ((and ytm-radio--browser-loading-message
               (or (null ytm-radio--browser-loading-view)
                   (equal ytm-radio--browser-loading-view
                          ytm-radio--browser-view)))
          (insert (propertize ytm-radio--browser-loading-message
                              'face 'shadow)
                  "\n"))
         ((and (eq ytm-radio--home-loading 'initial)
               (eq (ytm-radio--view-kind) 'home))
          (insert (propertize (or (ytm-radio--home-loading-message)
                                  "Loading Home...")
                              'face 'shadow)
                  "\n"))
         ((and (ytm-radio--empty-catalog-p)
               (not sources))
          (insert "No YouTube Music pages imported yet.\n"))
         ((not sources)
          (insert "No content in this view yet.\n"))
         (t
          (let ((omit-first-leading-space
                 (not (eq (ytm-radio--view-kind) 'library))))
            (cl-loop for source in sources
                     for first = t then nil
                     do (ytm-radio--insert-source-section
                        source
                        (and first omit-first-leading-space))))))
        (ytm-radio--restore-browser-point old-point reset-point history-entry)
        (ytm-radio--maybe-lazy-load-home)))))

(defun ytm-radio--update-browser-thumbnail-states (url file)
  "Update mutable browser thumbnail states for URL from FILE.
Return `updated' when cached image specs were mutated, `unsupported'
when matching states exist but cannot be safely updated in place, and
nil when no matching states exist."
  (when-let* ((thumbnail (and file
                              (file-readable-p file)
                              (ytm-radio--thumbnail-image-from-file file)))
              (keys (gethash url
                             ytm-radio--browser-thumbnail-state-keys-by-url)))
    (let (updated unsupported)
      (dolist (key keys)
        (when-let* ((state (gethash key
                                    ytm-radio--browser-thumbnail-state-cache)))
          (if (ytm-radio--mutate-thumbnail-state state thumbnail)
              (setq updated t)
            (setq unsupported t))))
      (cond
       (updated
        (when-let* ((buffer (get-buffer ytm-radio--library-buffer-name)))
          (force-window-update buffer))
        'updated)
       (unsupported 'unsupported)))))

(defun ytm-radio--start-pending-thumbnail-downloads ()
  "Start a bounded batch of pending browser thumbnail downloads."
  (let ((ytm-radio--browser-thumbnail-download-budget
         (when (numberp ytm-radio-browser-thumbnail-downloads-per-render)
           (max 0 ytm-radio-browser-thumbnail-downloads-per-render)))
        remaining)
    (catch 'budget-exhausted
      (while ytm-radio--browser-thumbnail-pending-urls
        (let ((url (pop ytm-radio--browser-thumbnail-pending-urls))
              file)
          (cond
           ((setq file (ytm-radio--cover-file url))
            (ytm-radio--update-browser-thumbnail-states url file))
           ((ytm-radio--cover-download-in-flight-p url)
            (ytm-radio--ensure-cover-file
             url #'ytm-radio--thumbnail-download-finished))
           ((not (ytm-radio--cover-cache-path url)))
           ((ytm-radio--browser-thumbnail-download-allowed-p url)
            (ytm-radio--ensure-cover-file
             url #'ytm-radio--thumbnail-download-finished))
           (t
            (push url remaining)
            (throw 'budget-exhausted nil))))))
    (setq ytm-radio--browser-thumbnail-pending-urls
          (append (nreverse remaining)
                  ytm-radio--browser-thumbnail-pending-urls))))

(defun ytm-radio--thumbnail-download-finished (url file)
  "Update browser thumbnail image states after URL was cached in FILE."
  (when (eq (ytm-radio--update-browser-thumbnail-states url file) 'unsupported)
    (ytm-radio--render-browser))
  (ytm-radio--start-pending-thumbnail-downloads))

(defun ytm-radio--cover-cache-path (url)
  "Return the local cache path for cover URL, or nil."
  (when (and (stringp url)
             (string-match-p "\\`https?://" url))
    (expand-file-name (concat (secure-hash 'sha1 url) ".jpg")
                      ytm-radio-cover-cache-directory)))

(defun ytm-radio--cover-file (url)
  "Return a cached local cover file for URL, or nil."
  (when-let* ((file (ytm-radio--cover-cache-path url)))
    (when (file-readable-p file)
      file)))

(defun ytm-radio--cover-download-in-flight-p (url)
  "Return non-nil when cover URL is currently being downloaded."
  (not (eq (gethash url ytm-radio--cover-downloads :not-found)
           :not-found)))

(defun ytm-radio--cover-download-callbacks (url)
  "Return registered completion callbacks for cover URL."
  (gethash url ytm-radio--cover-downloads))

(defun ytm-radio--register-cover-download-callback (url callback)
  "Register CALLBACK for the in-flight cover download at URL."
  (let ((callbacks (ytm-radio--cover-download-callbacks url)))
    (when callback
      (cl-pushnew callback callbacks :test #'eq))
    (puthash url callbacks ytm-radio--cover-downloads)))

(defun ytm-radio--run-cover-download-callbacks (url file)
  "Run registered cover download callbacks for URL and FILE."
  (let ((callbacks (ytm-radio--cover-download-callbacks url))
        (completed-file (and file (file-readable-p file) file)))
    (remhash url ytm-radio--cover-downloads)
    (dolist (callback callbacks)
      (funcall callback url completed-file))))

(defun ytm-radio--cache-cover (url callback)
  "Fetch cover URL asynchronously and call CALLBACK with URL and file."
  (when-let* ((file (ytm-radio--cover-cache-path url)))
    (unless (file-readable-p file)
      (let ((already-downloading (ytm-radio--cover-download-in-flight-p url)))
        (ytm-radio--register-cover-download-callback url callback)
        (unless already-downloading
          (condition-case nil
            (progn
              (make-directory ytm-radio-cover-cache-directory t)
              (let* ((url-show-status nil)
                     (url-proxy-services
                      (or (ytm-radio--cover-url-proxy-services)
                          url-proxy-services))
                     (process
                      (url-retrieve
                       url
                       (lambda (status)
                         (unwind-protect
                             (progn
                               (unless (plist-get status :error)
                                 (goto-char (point-min))
                                 (when (search-forward "\n\n" nil t)
                                   (let ((coding-system-for-write 'binary))
                                     (write-region (point) (point-max)
                                                   file nil 'silent))))
                               (ytm-radio--run-cover-download-callbacks
                                url file))
                           (kill-buffer (current-buffer))))
                       nil t t)))
                (unless process
                  (ytm-radio--run-cover-download-callbacks url file))))
            (error
             (ytm-radio--run-cover-download-callbacks url file))))))))

(defun ytm-radio--ensure-cover-file (url callback)
  "Return cached cover file for URL, scheduling CALLBACK if it is missing."
  (or (ytm-radio--cover-file url)
      (progn
        (ytm-radio--cache-cover url callback)
        nil)))

(defun ytm-radio--scaled-image-size
    (natural-width natural-height max-width max-height)
  "Return image size fitting NATURAL-WIDTH and NATURAL-HEIGHT.
MAX-WIDTH and MAX-HEIGHT bound the returned display size."
  (let* ((natural-width (max 1 natural-width))
         (natural-height (max 1 natural-height))
         (scale (min (/ (float max-width) natural-width)
                     (/ (float max-height) natural-height))))
    (cons (max 1 (round (* natural-width scale)))
          (max 1 (round (* natural-height scale))))))

(defun ytm-radio--scaled-cover-size (natural-width natural-height)
  "Return cover display size for NATURAL-WIDTH and NATURAL-HEIGHT."
  (ytm-radio--scaled-image-size natural-width
                                natural-height
                                ytm-radio-cover-max-width
                                ytm-radio-cover-max-height))

(defun ytm-radio--cover-display-size (file)
  "Return display size for cover FILE, or nil."
  (when-let* ((image (ignore-errors (create-image file nil nil)))
              (dimensions (ignore-errors
                            (image-size image t
                                        (ytm-radio--now-playing-frame)))))
    (ytm-radio--scaled-cover-size (ceiling (car dimensions))
                                  (ceiling (cdr dimensions)))))

(defun ytm-radio--cover-refresh-current-track (url file)
  "Refresh now-playing when FILE was cached for the current track's URL."
  (when-let* ((file)
              (current (ytm-radio--current-track)))
    (when (equal url (ytm-radio--track-thumbnail-url current))
      (ytm-radio--render-now-playing))))

(defun ytm-radio--cover-spec (track)
  "Return an image spec and display size for TRACK's cover."
  (when-let* ((thumbnail (ytm-radio--track-thumbnail-url track))
              (file (and (display-graphic-p)
                         (ytm-radio--ensure-cover-file
                          thumbnail
                          #'ytm-radio--cover-refresh-current-track)))
              (size (ytm-radio--cover-display-size file))
              (image (ignore-errors
                       (create-image file nil nil
                                     :width (car size)
                                     :height (cdr size)))))
    (list image size)))

(defun ytm-radio--track-thumbnail-url (track)
  "Return TRACK's thumbnail URL, deriving a YouTube fallback when needed."
  (ytm-radio--higher-resolution-thumbnail-url
   (or (map-elt track :thumbnail-url)
       (when-let* ((id (map-elt track :id))
                   ((string-match-p "\\`[[:alnum:]_-]+\\'" id)))
         (format "https://i.ytimg.com/vi/%s/hqdefault.jpg" id)))))

(defun ytm-radio--insert-cover (cover-spec)
  "Insert COVER-SPEC's image or graphical placeholder.
Return non-nil when a cover row was inserted."
  (if-let* ((image (car-safe cover-spec))
            (cover-width (car-safe (cadr cover-spec))))
      (progn
        (insert ytm-radio--now-playing-top-padding)
        (ytm-radio--insert-pixel-space
         (ytm-radio--now-playing-cover-left-padding cover-width))
        (insert-image image "cover")
        (insert "\n")
        t)
    (when (display-graphic-p (ytm-radio--now-playing-frame))
      (insert ytm-radio--now-playing-top-padding)
      (ytm-radio--insert-centered-now-playing-line "[cover]")
      t)))

(defconst ytm-radio--now-playing-control-separator "  "
  "Separator used between compact now-playing controls.")

(defun ytm-radio--now-playing-controls-text ()
  "Return plain fallback text width for now-playing controls."
  (string-join (mapcar #'car (ytm-radio--now-playing-controls))
               ytm-radio--now-playing-control-separator))

(defun ytm-radio--now-playing-frame ()
  "Return the now-playing frame, or the selected frame as fallback."
  (if (frame-live-p ytm-radio--frame)
      ytm-radio--frame
    (selected-frame)))

(defun ytm-radio--now-playing-controls-pixel-width (frame)
  "Return fallback controls width in pixels for FRAME."
  (* (string-width (ytm-radio--now-playing-controls-text))
     (max 1 (frame-char-width frame))))

(defun ytm-radio--now-playing-layout-pixel-width-for-cover (cover-width frame)
  "Return layout pixel width needed for COVER-WIDTH in FRAME."
  (+ ytm-radio--now-playing-cover-left-padding-pixels
     ytm-radio--now-playing-cover-right-padding-pixels
     (max 1 cover-width (ytm-radio--now-playing-controls-pixel-width frame))))

(defun ytm-radio--now-playing-layout-pixel-width ()
  "Return the target now-playing layout width in pixels."
  (ytm-radio--now-playing-layout-pixel-width-for-cover
   (or ytm-radio--cover-render-width ytm-radio-cover-max-width)
   (ytm-radio--now-playing-frame)))

(defun ytm-radio--now-playing-cover-left-padding (cover-width)
  "Return pixel padding before COVER-WIDTH in the final layout."
  (let* ((frame (ytm-radio--now-playing-frame))
         (layout-width
          (ytm-radio--now-playing-layout-pixel-width-for-cover
           cover-width frame)))
    (min (max 0 (- layout-width cover-width))
         ytm-radio--now-playing-cover-left-padding-pixels)))

(defun ytm-radio--now-playing-text-width ()
  "Return the text width used below the now-playing cover."
  (let ((frame (ytm-radio--now-playing-frame)))
    (max 8
         (ceiling (ytm-radio--now-playing-layout-pixel-width)
                  (max 1 (frame-char-width frame))))))

(defun ytm-radio--now-playing-safe-text-width ()
  "Return conservative text columns for single-line now-playing text."
  (max 1 (- (ytm-radio--now-playing-text-width)
            ytm-radio--progress-line-safety-columns
            1)))

(defun ytm-radio--now-playing-window-body-pixel-width ()
  "Return the now-playing child frame body width in pixels, or nil."
  (when (frame-live-p ytm-radio--frame)
    (let ((window (frame-root-window ytm-radio--frame)))
      (when (window-live-p window)
        (window-body-width window t)))))

(defun ytm-radio--insert-centered-now-playing-line (text &optional face width)
  "Insert TEXT centered in the now-playing layout, optionally using FACE.
When WIDTH is non-nil, truncate and center against that column width."
  (let* ((width (or width (ytm-radio--now-playing-text-width)))
         (text (ytm-radio--truncate text width)))
    (if (display-graphic-p (ytm-radio--now-playing-frame))
        (progn
          (setq text
                (ytm-radio--truncate-to-pixel-width
                 text (ytm-radio--now-playing-content-pixel-width)))
          (let ((padding
                (max 0 (/ (- (ytm-radio--now-playing-text-pixel-width)
                             (string-pixel-width text (current-buffer)))
                          2))))
            (ytm-radio--insert-pixel-space padding)))
      (let ((padding (max 0 (/ (- width (string-width text)) 2))))
        (insert (make-string padding ?\s))))
    (insert (if face (propertize text 'face face) text))
    (insert "\n")))

(defconst ytm-radio--title-scroll-gap "   "
  "Gap inserted between repeated title marquee copies.")

(defun ytm-radio--marquee-text (text width offset)
  "Return a marquee slice of TEXT with WIDTH columns at OFFSET.
Short TEXT is returned unchanged."
  (let ((text (or text "")))
    (if (<= (string-width text) width)
        text
      (let* ((cycle-width (+ (string-width text)
                             (string-width ytm-radio--title-scroll-gap)))
             (offset (mod (max 0 offset) cycle-width))
             (loop-text (concat text
                                ytm-radio--title-scroll-gap
                                text)))
        (truncate-string-to-width loop-text (+ offset width) offset nil)))))

(defun ytm-radio--title-scroll-key (track width)
  "Return the marquee state key for TRACK at WIDTH."
  (list (map-elt track :id)
        (ytm-radio--track-title track)
        width))

(defun ytm-radio--scrolling-track-title (track width)
  "Return TRACK title rendered for the current marquee WIDTH."
  (let* ((title (ytm-radio--track-title track))
         (key (ytm-radio--title-scroll-key track width)))
    (unless (equal key ytm-radio--title-scroll-key)
      (setq ytm-radio--title-scroll-key key
            ytm-radio--title-scroll-offset 0))
    (if (> (string-width title) width)
        (progn
          (ytm-radio--schedule-title-scroll)
          (ytm-radio--marquee-text title width ytm-radio--title-scroll-offset))
      (ytm-radio--reset-title-scroll)
      title)))

(defun ytm-radio--fit-title-with-rating-to-pixels
    (title indicator title-face pixel-width)
  "Return TITLE plus INDICATOR fitted to PIXEL-WIDTH.
When TITLE-FACE is non-nil, apply it to the title text only."
  (let* ((indicator (or indicator ""))
         (title (if title-face
                    (propertize title 'face title-face)
                  title))
         (text (concat title indicator)))
    (if (or (not pixel-width)
            (not (display-graphic-p (ytm-radio--now-playing-frame)))
            (<= (string-pixel-width text (current-buffer)) pixel-width))
        text
      (let* ((indicator-width
              (string-pixel-width indicator (current-buffer)))
             (title-width (max 0 (- pixel-width indicator-width)))
             (title (ytm-radio--truncate-to-pixel-width
                     title title-width)))
        (concat title indicator)))))

(defun ytm-radio--scrolling-track-title-with-rating
    (track width &optional title-face pixel-width)
  "Return TRACK title plus rating marker, fitting inside WIDTH.
When TITLE-FACE is non-nil, apply it to the title text only.
When PIXEL-WIDTH is non-nil, also fit the result to that pixel width."
  (let* ((indicator (ytm-radio--track-rating-indicator track))
         (title-width (ytm-radio--track-title-width width indicator))
         (title (ytm-radio--scrolling-track-title track title-width)))
    (ytm-radio--fit-title-with-rating-to-pixels
     title indicator title-face pixel-width)))

(defun ytm-radio--now-playing-text-pixel-width ()
  "Return the now-playing text width in pixels."
  (let ((layout-width (ytm-radio--now-playing-layout-pixel-width))
        (body-width (ytm-radio--now-playing-window-body-pixel-width)))
    (if body-width
        (max 1 (min layout-width body-width))
      layout-width)))

(defun ytm-radio--now-playing-content-pixel-width ()
  "Return the pixel width available for now-playing text content."
  (max 1
       (- (ytm-radio--now-playing-text-pixel-width)
          ytm-radio--now-playing-cover-left-padding-pixels
          ytm-radio--now-playing-cover-right-padding-pixels)))

(defun ytm-radio--mdicon (name fallback)
  "Return Material Design icon NAME, or FALLBACK when unavailable."
  (if (and (require 'nerd-icons nil t)
           (fboundp 'nerd-icons-mdicon))
      (condition-case nil
          (funcall #'nerd-icons-mdicon name :height 1.0)
        (error fallback))
    fallback))

(defvar ytm-radio--now-playing-inert-button-map
  (let ((map (make-sparse-keymap)))
    (dolist (event '([mouse-1] [down-mouse-1] [drag-mouse-1]
                     [double-mouse-1] [triple-mouse-1]
                     [mouse-2] [down-mouse-2] [drag-mouse-2]
                     [double-mouse-2] [triple-mouse-2]
                     [mouse-3] [down-mouse-3] [drag-mouse-3]
                     [double-mouse-3] [triple-mouse-3]))
      (define-key map event #'ignore))
    map)
  "Keymap for inert now-playing surface buttons.")

(defvar ytm-radio--now-playing-button-map
  (let ((map (copy-keymap button-map)))
    (dolist (event '([down-mouse-1] [drag-mouse-1]
                     [double-mouse-1] [triple-mouse-1]
                     [down-mouse-2] [drag-mouse-2]
                     [double-mouse-2] [triple-mouse-2]
                     [mouse-3] [down-mouse-3] [drag-mouse-3]
                     [double-mouse-3] [triple-mouse-3]))
      (define-key map event #'ignore))
    (define-key map [mouse-1] #'ytm-radio--push-now-playing-button)
    (define-key map [mouse-2] #'ytm-radio--push-now-playing-button)
    map)
  "Keymap for now-playing controls that does not select their window.")

(define-button-type 'ytm-radio-now-playing-button
  'follow-link t
  'face 'default
  'mouse-face 'highlight
  'keymap ytm-radio--now-playing-button-map)

(defvar ytm-radio--now-playing-drag-map
  (let ((map (make-sparse-keymap)))
    (define-key map [down-mouse-1] #'ytm-radio--drag-now-playing)
    map)
  "Keymap for dragging the now-playing child frame from text areas.")

(defun ytm-radio--now-playing-button-at-event (event)
  "Return the now-playing button at mouse EVENT, or nil."
  (let* ((position (event-start event))
         (window (posn-window position))
         (point (posn-point position)))
    (when (and (window-live-p window)
               (integer-or-marker-p point))
      (with-current-buffer (window-buffer window)
        (or (button-at point)
            (and (> point (point-min))
                 (button-at (1- point))))))))

(defun ytm-radio--now-playing-button-event-p (event)
  "Return non-nil when mouse EVENT starts on a button."
  (and (ytm-radio--now-playing-button-at-event event) t))

(defun ytm-radio--push-now-playing-button (event)
  "Push the now-playing button at mouse EVENT without selecting its window."
  (interactive "e")
  (let* ((position (event-start event))
         (window (posn-window position))
         (point (posn-point position)))
    (when (and (window-live-p window)
               (integer-or-marker-p point))
      (with-current-buffer (window-buffer window)
        (when-let* ((button (or (button-at point)
                                (and (> point (point-min))
                                     (button-at (1- point))))))
          (button-activate button t))))))

(defun ytm-radio--drag-now-playing (event)
  "Drag the now-playing child frame from mouse EVENT."
  (interactive "e")
  (when (and ytm-radio-child-frame-draggable
             (not (ytm-radio--now-playing-button-event-p event)))
    (let* ((position (event-start event))
           (window (posn-window position))
           (frame (if (window-live-p window)
                      (window-frame window)
                    window)))
      (when (and (frame-live-p ytm-radio--frame)
                 (eq frame ytm-radio--frame))
        (let ((start (mouse-absolute-pixel-position))
              (origin (frame-position frame))
              moved)
          (when (and (consp start)
                     (numberp (car start))
                     (numberp (cdr start)))
            (track-mouse
              (while (eq (car-safe (setq event (read-event)))
                         'mouse-movement)
                (when-let* ((current (mouse-absolute-pixel-position))
                            ((numberp (car current)))
                            ((numberp (cdr current))))
                  (let ((new-position
                         (ytm-radio--constrain-frame-position
                          frame
                          (cons (+ (car origin)
                                   (- (car current) (car start)))
                                (+ (cdr origin)
                                   (- (cdr current) (cdr start)))))))
                    (set-frame-position frame
                                        (car new-position)
                                        (cdr new-position))
                    (setq ytm-radio--frame-manual-position new-position
                          moved t)))))
            (when moved
              (ytm-radio--remember-frame-position frame))))))))

(defun ytm-radio--add-now-playing-drag-bindings ()
  "Add child-frame drag bindings to non-button text in the current buffer."
  (when (and ytm-radio-child-frame-draggable
             (eq ytm-radio-display-style 'child-frame)
             (display-graphic-p (ytm-radio--now-playing-frame)))
    (let ((position (point-min))
          (end (point-max)))
      (while (< position end)
        (let ((next (or (next-single-property-change position 'button nil end)
                        end)))
          (unless (get-text-property position 'button)
            (add-text-properties
             position next
             `(keymap ,ytm-radio--now-playing-drag-map
               help-echo "Drag to move now-playing")))
          (setq position next))))))

(defun ytm-radio--add-now-playing-inert-button-properties ()
  "Make non-control now-playing text behave like inert buttons."
  (let ((position (point-min))
        (end (point-max)))
    (while (< position end)
      (let ((next (or (next-single-property-change position 'button nil end)
                      end)))
        (unless (get-text-property position 'button)
          (add-text-properties
           position next
           `(button ,(list t)
             category t
             follow-link t
             keymap ,ytm-radio--now-playing-inert-button-map
             action ignore
             mouse-action ignore
             rear-nonsticky t)))
        (setq position next)))))

(defun ytm-radio--insert-now-playing-control (icon command help &optional face)
  "Insert a now-playing ICON button running COMMAND with HELP text.
When FACE is non-nil, use it for the button label."
  (let ((start (point)))
    (insert-text-button (format "%s" icon)
                        'type 'ytm-radio-now-playing-button
                        'action (lambda (_button)
                                  (call-interactively command))
                        'mouse-action (lambda (_button)
                                        (call-interactively command))
                        'help-echo help
                        'mouse-face 'highlight)
    (add-face-text-property start (point) (or face 'default) t)))

(defun ytm-radio--repeat-control ()
  "Return the repeat control button spec."
  (pcase (ytm-radio--repeat-mode)
    ('one
     (list (ytm-radio--mdicon "nf-md-repeat_once" "1")
           #'ytm-radio-cycle-repeat
           "Repeat one"
           'bold))
    ('all
     (list (ytm-radio--mdicon "nf-md-repeat" "R")
           #'ytm-radio-cycle-repeat
           "Repeat all"
           'bold))
    (_
     (list (ytm-radio--mdicon "nf-md-repeat" "R")
           #'ytm-radio-cycle-repeat
           "Repeat off"
           'shadow))))

(defun ytm-radio--shuffle-control ()
  "Return the shuffle control button spec."
  (if (map-elt ytm-radio--player :shuffle)
      (list (ytm-radio--mdicon "nf-md-shuffle" "S")
            #'ytm-radio-toggle-shuffle
            "Shuffle on"
            'bold)
    (list (ytm-radio--mdicon "nf-md-shuffle" "S")
          #'ytm-radio-toggle-shuffle
          "Shuffle off"
          'shadow)))

(defun ytm-radio--now-playing-controls ()
  "Return now-playing controls as button specs."
  (list
   (ytm-radio--repeat-control)
   (list (ytm-radio--mdicon "nf-md-skip_previous" "<<")
         #'ytm-radio-previous
         "Previous track")
   (list (if (eq (map-elt ytm-radio--player :status) 'playing)
             (ytm-radio--mdicon "nf-md-pause" "||")
           (ytm-radio--mdicon "nf-md-play" ">"))
         #'ytm-radio-toggle-pause
         "Play or pause")
   (list (ytm-radio--mdicon "nf-md-skip_next" ">>")
         #'ytm-radio-next
         "Next track")
   (ytm-radio--shuffle-control)))

(defun ytm-radio--side-window-cover (track)
  "Return TRACK's cover image for the side-window view."
  (or (when-let* ((thumbnail (ytm-radio--track-thumbnail-url track))
                  (file (and (ytm-radio--side-window-graphic-p)
                             (ytm-radio--ensure-cover-file
                              thumbnail
                              #'ytm-radio--cover-refresh-current-track)))
                  (dimensions (ytm-radio--image-file-dimensions file))
                  (size (ytm-radio--scaled-image-size
                         (car dimensions)
                         (cdr dimensions)
                         ytm-radio-side-window-cover-size
                         ytm-radio-side-window-cover-size))
                  (image (ignore-errors
                           (create-image file nil nil
                                         :width (car size)
                                         :height (cdr size)
                                         :ascent 'center))))
        (propertize " " 'display image))
      (ytm-radio--append-face (ytm-radio--mdicon "nf-md-music_box" "♪")
                              'ytm-radio-side-window-title)))

(defconst ytm-radio--side-window-line-separator "    "
  "Separator between side-window layout sections.")

(defconst ytm-radio--side-window-min-track-columns 18
  "Minimum track columns preferred before hiding side-window controls.")

(defun ytm-radio--side-window-content-width ()
  "Return available columns for side-window content."
  (max 1
       (1-
        (or (and (window-live-p ytm-radio--side-window)
                 (window-body-width ytm-radio--side-window))
            (frame-width (selected-frame))))))

(defun ytm-radio--side-window-graphic-p ()
  "Return non-nil when the side-window target frame is graphical."
  (display-graphic-p
   (and (window-live-p ytm-radio--side-window)
        (window-frame ytm-radio--side-window))))

(defun ytm-radio--side-window-window-height ()
  "Return the effective side-window height for the current display."
  (if (ytm-radio--side-window-graphic-p)
      (max 2 ytm-radio-side-window-height)
    ytm-radio-side-window-height))

(defun ytm-radio--side-window-content-pixel-width ()
  "Return available side-window content pixels, or nil."
  (when (and (window-live-p ytm-radio--side-window)
             (ytm-radio--side-window-graphic-p))
    (window-body-width ytm-radio--side-window t)))

(defun ytm-radio--side-window-track-text (track &optional width)
  "Return TRACK title and artist text for the side-window view.
When WIDTH is non-nil, fit the returned text within WIDTH columns."
  (let* ((width (max 1 (or width ytm-radio-side-window-title-width)))
         (artist-separator "  ")
         (secondary (ytm-radio--track-secondary-text
                     track 'ytm-radio-side-window-artist))
         (secondary-width (and secondary
                            (min (string-width secondary)
                                 (max 8 (/ width 2)))))
         (include-artist
          (and secondary-width
               (>= (- width (string-width artist-separator) secondary-width)
                   8)))
         (title-width (if include-artist
                          (- width
                             (string-width artist-separator)
                             secondary-width)
                        width))
         (title (ytm-radio--scrolling-track-title-with-rating
                 track title-width 'ytm-radio-side-window-title))
         (text (concat
                title
                (when include-artist
                  (concat
                   artist-separator
                   (ytm-radio--truncate secondary secondary-width))))))
    (ytm-radio--truncate text width)))

(defun ytm-radio--side-window-track-line (track width)
  "Return the side-window track line for TRACK fitting WIDTH columns."
  (let* ((width (max 1 width))
         (prefix (concat " " (ytm-radio--side-window-cover track) "  "))
         (text-width (max 1 (- width (string-width prefix)))))
    (ytm-radio--truncate
     (concat prefix (ytm-radio--side-window-track-text track text-width))
     width)))

(defun ytm-radio--insert-side-window-controls ()
  "Insert compact playback controls for the side-window view."
  (let ((separator ytm-radio--now-playing-control-separator))
    (cl-loop for (icon command help face) in (ytm-radio--now-playing-controls)
             for first = t then nil
             unless first do (insert separator)
             do (ytm-radio--insert-now-playing-control icon command help face))))

(defun ytm-radio--side-window-progress-min-width (track)
  "Return the minimum useful progress label width for TRACK."
  (let* ((duration (or (map-elt ytm-radio--player :duration)
                       (map-elt track :duration)))
         (left-label (or (ytm-radio--format-duration
                          (map-elt ytm-radio--player :position))
                         "0:00"))
         (right-label (or (ytm-radio--format-duration duration)
                          "--:--")))
    (+ (string-width left-label)
       1
       ytm-radio--progress-bar-min-width
       1
       (string-width right-label))))

(defun ytm-radio--side-window-progress-preferred-width (track)
  "Return the preferred progress label width for TRACK."
  (+ (ytm-radio--side-window-progress-min-width track)
     (- ytm-radio--progress-bar-max-width
        ytm-radio--progress-bar-min-width)))

(defun ytm-radio--side-window-progress-label (track width)
  "Return a side-window progress label for TRACK fitting WIDTH columns."
  (let* ((width (max 1 width))
         (position (map-elt ytm-radio--player :position))
         (duration (or (map-elt ytm-radio--player :duration)
                       (map-elt track :duration)))
         (left-label (or (ytm-radio--format-duration position) "0:00"))
         (right-label (or (ytm-radio--format-duration duration) "--:--"))
         (bar-width (- width
                       (string-width left-label)
                       (string-width right-label)
                       2))
         (label
          (if (>= bar-width ytm-radio--progress-bar-min-width)
              (ytm-radio--progress-line-text
               left-label
               (ytm-radio--progress-bar
                position duration
                (min ytm-radio--progress-bar-max-width bar-width))
               right-label)
            (ytm-radio--truncate
             (format "%s/%s" left-label right-label)
             width))))
    label))

(defun ytm-radio--side-window-show-controls-p (track width)
  "Return non-nil when side-window controls fit TRACK at WIDTH columns."
  (let* ((separator-width (string-width ytm-radio--side-window-line-separator))
         (controls-width (string-width (ytm-radio--now-playing-controls-text)))
         (progress-preferred-width
          (ytm-radio--side-window-progress-preferred-width track)))
    (>= width
        (+ ytm-radio--side-window-min-track-columns
           progress-preferred-width
           controls-width
           (* 2 separator-width)))))

(defun ytm-radio--side-window-line-fits-p (start)
  "Return non-nil when the text after START fits the side-window pixels."
  (if-let* ((pixel-width (ytm-radio--side-window-content-pixel-width)))
      (<= (string-pixel-width
           (buffer-substring start (point))
           (current-buffer))
          pixel-width)
    t))

(defun ytm-radio--insert-side-window-line-layout (track width show-controls)
  "Insert one side-window TRACK line at WIDTH columns.
When SHOW-CONTROLS is non-nil, include playback controls."
  (let* ((width (max 1 width))
         (separator ytm-radio--side-window-line-separator)
         (separator-width (string-width separator))
         (controls-width (string-width (ytm-radio--now-playing-controls-text)))
         (progress-preferred-width
          (ytm-radio--side-window-progress-preferred-width track))
         (progress-width
          (max 1
               (min progress-preferred-width
                    (- width
                       ytm-radio--side-window-min-track-columns
                       (if show-controls (+ controls-width (* 2 separator-width))
                         separator-width)))))
         (progress (ytm-radio--side-window-progress-label track progress-width))
         (track-width
          (max 1
               (- width
                  (string-width progress)
                  separator-width
                  (if show-controls (+ controls-width separator-width) 0)))))
    (insert (ytm-radio--side-window-track-line track track-width))
    (insert separator)
    (insert progress)
    (when show-controls
      (insert separator)
      (ytm-radio--insert-side-window-controls))))

(defun ytm-radio--insert-side-window-line (track)
  "Insert the single side-window layout line for TRACK."
  (let* ((width (ytm-radio--side-window-content-width))
         (start (point))
         (show-controls (ytm-radio--side-window-show-controls-p track width))
         (render (lambda ()
                   (delete-region start (point))
                   (goto-char start)
                   (ytm-radio--insert-side-window-line-layout
                    track width show-controls))))
    (ytm-radio--insert-side-window-line-layout track width show-controls)
    (when (and show-controls
               (not (ytm-radio--side-window-line-fits-p start)))
      (setq show-controls nil)
      (funcall render))
    (while (and (> width 1)
                (not (ytm-radio--side-window-line-fits-p start)))
      (setq width (1- width))
      (funcall render))))

(defun ytm-radio--insert-side-window-empty-line ()
  "Insert the side-window line when no track is active."
  (insert
   (ytm-radio--truncate
    (concat " "
            (ytm-radio--append-face
             (ytm-radio--mdicon "nf-md-music_box" "♪")
             'ytm-radio-side-window-title)
            " "
            (propertize "No track" 'face 'ytm-radio-side-window-artist))
    (ytm-radio--side-window-content-width))))

(defun ytm-radio--insert-side-window-fill ()
  "Insert a stretch glyph covering the rest of the side-window row."
  (insert (propertize " " 'display '(space :align-to right))))

(defun ytm-radio--side-window-centered-line-height ()
  "Return a line-height value for centering the graphical side-window line."
  (let ((height (ytm-radio--side-window-window-height)))
    (when (and (ytm-radio--side-window-graphic-p)
               (> height 1))
      (list (/ (1+ height) 2.0)
            (float height)))))

(defun ytm-radio--finish-side-window-lines ()
  "Fill the remaining configured side-window rows."
  (let ((line-height (ytm-radio--side-window-centered-line-height)))
    (ytm-radio--insert-side-window-fill)
    (insert (if line-height
                (propertize "\n" 'line-height line-height)
              "\n"))
    (unless line-height
      (dotimes (_ (max 0 (1- (ytm-radio--side-window-window-height))))
        (ytm-radio--insert-side-window-fill)
        (insert "\n")))))

(defun ytm-radio--render-side-window ()
  "Render the now-playing buffer for the side-window display style."
  (when-let* ((buffer (get-buffer ytm-radio--now-playing-buffer-name)))
    (with-current-buffer buffer
      (let ((inhibit-read-only t)
            (track (ytm-radio--current-track)))
        (erase-buffer)
        (if track
            (ytm-radio--insert-side-window-line track)
          (ytm-radio--reset-title-scroll)
          (ytm-radio--insert-side-window-empty-line))
        (ytm-radio--finish-side-window-lines)
        (ytm-radio--add-now-playing-inert-button-properties)
        (setq ytm-radio--last-rendered-progress-key
              (ytm-radio--progress-render-key))
        (goto-char (point-min))))))

(defun ytm-radio--insert-now-playing-controls ()
  "Insert centered now-playing controls."
  (let* ((separator ytm-radio--now-playing-control-separator)
         (controls (ytm-radio--now-playing-controls))
         (labels (mapcar #'car controls))
         (controls-text (string-join labels separator)))
    (if (display-graphic-p (ytm-radio--now-playing-frame))
        (let* ((controls-width
                (string-pixel-width controls-text (current-buffer)))
               (padding (max 0 (/ (- (ytm-radio--now-playing-text-pixel-width)
                                     controls-width)
                                  2))))
          (ytm-radio--insert-pixel-space padding))
      (let* ((controls-width (string-width controls-text))
             (padding (max 0 (/ (- (ytm-radio--now-playing-text-width)
                                  controls-width)
                               2))))
        (insert (make-string padding ?\s))))
    (cl-loop for (icon command help face) in controls
             for first = t then nil
             unless first do (insert separator)
             do (ytm-radio--insert-now-playing-control icon command help face))))

(defun ytm-radio--render-now-playing ()
  "Render the now-playing buffer."
  (when-let* ((buffer (get-buffer ytm-radio--now-playing-buffer-name)))
    (with-current-buffer buffer
      (let ((inhibit-read-only t)
            (old-point (point))
            (track (ytm-radio--current-track)))
        (erase-buffer)
        (if track
            (let* ((cover-spec (ytm-radio--cover-spec track))
                   (cover-size (cadr cover-spec))
                   (ytm-radio--cover-render-width (car-safe cover-size))
                   (text-width (ytm-radio--now-playing-safe-text-width)))
              (when (ytm-radio--insert-cover cover-spec)
                (insert ytm-radio--now-playing-thin-padding))
              (ytm-radio--insert-centered-now-playing-line
               (ytm-radio--scrolling-track-title-with-rating
                track
                text-width
                'bold
                (ytm-radio--now-playing-content-pixel-width))
               nil
               text-width)
              (when-let* ((artist (ytm-radio--track-secondary-text
                                   track 'shadow)))
                (ytm-radio--insert-centered-now-playing-line
                 (ytm-radio--truncate artist text-width)
                 nil
                 text-width))
              (when-let* ((time-label (ytm-radio--playback-time-label track)))
                (ytm-radio--insert-centered-now-playing-line
                 time-label))
              (insert ytm-radio--now-playing-thin-padding)
              (ytm-radio--insert-now-playing-controls)
              (insert "\n")
              (insert ytm-radio--now-playing-bottom-padding))
          (progn
            (ytm-radio--reset-title-scroll)
            (ytm-radio--insert-centered-now-playing-line "No track")))
        (ytm-radio--add-now-playing-drag-bindings)
        (setq ytm-radio--last-rendered-progress-key
              (ytm-radio--progress-render-key))
        (goto-char (min (max old-point (point-min)) (point-max)))
        (when (eobp)
          (goto-char (point-min)))))
    (when (and (frame-live-p ytm-radio--frame)
               (not ytm-radio--inhibit-frame-fit))
      (ytm-radio--fit-frame ytm-radio--frame buffer)
      (ytm-radio--position-frame ytm-radio--frame))
    (when (ytm-radio--side-window-visible-p)
      (ytm-radio--render-side-window))))

(defun ytm-radio--show-regular-buffer (buffer)
  "Show BUFFER in a regular Emacs window."
  (pop-to-buffer buffer))

(defun ytm-radio--show-child-frame-or-buffer (buffer focus)
  "Show BUFFER in a child frame, falling back to a regular window.
FOCUS is passed through to `ytm-radio--show-child-frame'."
  (if (ytm-radio--child-frame-supported-p)
      (condition-case error
          (ytm-radio--show-child-frame buffer focus)
        (error
         (message "Cannot show ytm-radio child frame; using buffer: %s"
                  (error-message-string error))
         (ytm-radio--show-regular-buffer buffer)))
    (ytm-radio--show-regular-buffer buffer)))

(defun ytm-radio--delete-frame ()
  "Delete the now-playing child frame, if any."
  (when (frame-live-p ytm-radio--frame)
    (let ((parent (frame-parent ytm-radio--frame)))
      (redirect-frame-focus ytm-radio--frame nil)
      (delete-frame ytm-radio--frame)
      (when (frame-live-p parent)
        (select-frame-set-input-focus parent))))
  (setq ytm-radio--frame nil
        ytm-radio--frame-manual-position nil)
  (remove-hook 'window-size-change-functions
               #'ytm-radio--reposition-on-resize))

(defun ytm-radio--buffer-image (buffer)
  "Return the first image displayed in BUFFER, or nil."
  (with-current-buffer buffer
    (save-excursion
      (goto-char (point-min))
      (let (image)
        (while (and (not image) (not (eobp)))
          (when-let* ((display (get-text-property (point) 'display))
                      ((eq (car-safe display) 'image)))
            (setq image display))
          (goto-char (or (next-single-property-change (point) 'display)
                         (point-max))))
        image))))

(defun ytm-radio--now-playing-line-count (buffer)
  "Return BUFFER's line count."
  (with-current-buffer buffer
    (line-number-at-pos (point-max))))

(defun ytm-radio--now-playing-frame-height (frame buffer image)
  "Return FRAME height needed for BUFFER containing IMAGE."
  (let ((window (frame-root-window frame)))
    (or (with-current-buffer buffer
          (when-let* ((size (ignore-errors
                              (window-text-pixel-size
                               window (point-min) (point-max) nil nil))))
            (ceiling (cdr size))))
        (let ((dimensions (image-size image t frame))
              (lines (ytm-radio--now-playing-line-count buffer)))
          (+ (ceiling (cdr dimensions))
             (* (max 0 (1- lines))
                (frame-char-height frame)))))))

(defun ytm-radio--now-playing-debug-data ()
  "Return live geometry data for the now-playing child frame."
  (unless (frame-live-p ytm-radio--frame)
    (user-error "No live ytm-radio child frame"))
  (let* ((frame ytm-radio--frame)
         (window (frame-root-window frame))
         (buffer (window-buffer window))
         (image (ytm-radio--buffer-image buffer))
         (inside (window-inside-pixel-edges window))
         (window-edges (window-pixel-edges window))
         (image-size (and image
                          (ignore-errors (image-size image t frame))))
         first-line-size)
    (with-current-buffer buffer
      (save-excursion
        (goto-char (point-min))
        (setq first-line-size
              (ignore-errors
                (window-text-pixel-size
                 window (point-min) (line-end-position) t nil)))))
    `((frame-pixel-width . ,(frame-pixel-width frame))
      (frame-inner-width . ,(frame-inner-width frame))
      (frame-text-width . ,(frame-text-width frame))
      (frame-char-width . ,(frame-char-width frame))
      (cover-left-padding-pixels
       . ,ytm-radio--now-playing-cover-left-padding-pixels)
      (cover-right-padding-pixels
       . ,ytm-radio--now-playing-cover-right-padding-pixels)
      (window-pixel-width . ,(window-pixel-width window))
      (window-body-width-px . ,(window-body-width window t))
      (window-body-width-cols . ,(window-body-width window))
      (window-pixel-edges . ,window-edges)
      (window-inside-pixel-edges . ,inside)
      (window-inside-width . ,(- (nth 2 inside) (nth 0 inside)))
      (image-size . ,image-size)
      (first-line-text-pixel-size . ,first-line-size)
      (right-gap-from-first-line . ,(and first-line-size
                                         (- (- (nth 2 inside) (nth 0 inside))
                                            (car first-line-size))))
      (right-gap-from-image . ,(and image-size
                                    (- (- (nth 2 inside) (nth 0 inside))
                                       (car image-size))))
      (truncate-lines . ,truncate-lines)
      (overflow-newline-into-fringe . ,overflow-newline-into-fringe)
      (fringes . ,(window-fringes window))
      (margins . ,(window-margins window))
      (scroll-bars . ,(window-scroll-bars window))
      (frame-left-fringe . ,(frame-parameter frame 'left-fringe))
      (frame-right-fringe . ,(frame-parameter frame 'right-fringe))
      (frame-scroll-bar-width . ,(frame-parameter frame 'scroll-bar-width))
      (frame-internal-border-width
       . ,(frame-parameter frame 'internal-border-width))
      (frame-child-frame-border-width
       . ,(frame-parameter frame 'child-frame-border-width)))))

(defun ytm-radio--fit-frame (frame buffer)
  "Size FRAME to fit BUFFER's image and text."
  (let ((frame-resize-pixelwise t))
    (if-let* ((image (ytm-radio--buffer-image buffer)))
        (let* ((image-size (image-size image t frame))
               (width (ytm-radio--now-playing-layout-pixel-width-for-cover
                       (car image-size)
                       frame)))
          (set-frame-width frame width nil t)
          (set-frame-height
           frame
           (ytm-radio--now-playing-frame-height frame buffer image)
           nil
           t))
      (make-frame-visible frame)
      (fit-frame-to-buffer frame)
      (set-frame-width frame (max ytm-radio-child-frame-width
                                  (+ 2 (frame-width frame)))))))

(defun ytm-radio--constrain-frame-position (frame position)
  "Return POSITION constrained within FRAME's parent."
  (if-let* ((parent (frame-parent frame)))
      (cons (max 0 (min (car position)
                        (max 0 (- (frame-pixel-width parent)
                                  (frame-pixel-width frame)))))
            (max 0 (min (cdr position)
                        (max 0 (- (frame-pixel-height parent)
                                  (frame-pixel-height frame))))))
    position))

(defun ytm-radio--default-frame-position (frame)
  "Return FRAME's default lower-right child-frame position."
  (when-let* ((parent (frame-parent frame)))
    (let* ((bottom-window (car (window-at-side-list parent 'bottom)))
           (mode-line-height (if bottom-window
                                 (window-mode-line-height bottom-window)
                               0))
           (content-bottom (- (frame-pixel-height parent)
                              (window-pixel-height (minibuffer-window parent))
                              mode-line-height))
           (x-margin (* 2 (frame-char-width parent)))
           (y-margin (frame-char-height parent)))
      (cons (max 0 (- (frame-pixel-width parent)
                      (frame-pixel-width frame)
                      x-margin))
            (max 0 (- content-bottom
                      (frame-pixel-height frame)
                      y-margin))))))

(defun ytm-radio--remember-frame-position (frame)
  "Remember FRAME's current manual child-frame position."
  (setq ytm-radio--frame-manual-position
        (ytm-radio--constrain-frame-position frame (frame-position frame))))

(defun ytm-radio--position-frame (frame)
  "Position child FRAME at its manual or default position."
  (when-let* ((position (or ytm-radio--frame-manual-position
                            (ytm-radio--default-frame-position frame))))
    (setq position (ytm-radio--constrain-frame-position frame position))
    (when ytm-radio--frame-manual-position
      (setq ytm-radio--frame-manual-position position))
    (set-frame-position frame (car position) (cdr position))))

(defun ytm-radio--apply-child-frame-border-face (frame)
  "Apply ytm-radio child-frame border styling to FRAME."
  (let ((background (face-background 'ytm-radio-child-frame-border frame t)))
    (set-face-background 'child-frame-border
                         (or background "gray50")
                         frame)))

(defun ytm-radio--ensure-frame (buffer)
  "Return a child frame showing the now-playing BUFFER."
  (unless (frame-live-p ytm-radio--frame)
    (setq ytm-radio--frame-manual-position nil)
    (let* ((parent (selected-frame))
           (frame-resize-pixelwise t)
           (frame (make-frame
                   `((parent-frame . ,parent)
                     (minibuffer . nil)
                     (undecorated . t)
                     (skip-taskbar . t)
                     (no-other-frame . t)
                     (unsplittable . t)
                     (left-fringe . 0)
                     (right-fringe . 0)
                     (vertical-scroll-bars . nil)
                     (horizontal-scroll-bars . nil)
                     (scroll-bar-width . 0)
                     (scroll-bar-height . 0)
                     (right-divider-width . 0)
                     (bottom-divider-width . 0)
                     (menu-bar-lines . 0)
                     (tool-bar-lines . 0)
                     (tab-bar-lines . 0)
                     (internal-border-width . 0)
                     (child-frame-border-width . ,ytm-radio--frame-border-width)
                     (no-focus-on-map . t)
                     (no-accept-focus . t)
                     (visibility . nil)))))
      (redirect-frame-focus frame parent)
      (setq ytm-radio--frame frame)))
  (add-hook 'window-size-change-functions #'ytm-radio--reposition-on-resize)
  (ytm-radio--apply-child-frame-border-face ytm-radio--frame)
  (let ((window (frame-root-window ytm-radio--frame)))
    (when-let* ((parent (frame-parent ytm-radio--frame)))
      (redirect-frame-focus ytm-radio--frame parent))
    (set-window-buffer window buffer)
    (set-window-dedicated-p window t)
    (set-window-parameter window 'no-other-window t)
    (set-window-parameter window 'no-delete-other-windows t)
    (set-window-fringes window 0 0 nil t)
    (set-window-margins window 0 0)
    (set-window-scroll-bars window 0 nil 0 nil t))
  (ytm-radio--fit-frame ytm-radio--frame buffer)
  (ytm-radio--position-frame ytm-radio--frame)
  ytm-radio--frame)

(defun ytm-radio--show-child-frame (buffer &optional _focus)
  "Show now-playing BUFFER in a non-focusable child frame."
  (let ((selected-frame (selected-frame))
        (selected-window (selected-window))
        (frame (ytm-radio--ensure-frame buffer)))
    (unwind-protect
        (progn
          (unless (frame-visible-p frame)
            (make-frame-visible frame))
          frame)
      (when (frame-live-p selected-frame)
        (select-frame selected-frame)
        (when (window-live-p selected-window)
          (select-window selected-window))))))

(defun ytm-radio--reposition-on-resize (frame)
  "Re-pin the now-playing child frame when parent FRAME changes size."
  (if (frame-live-p ytm-radio--frame)
      (when (eq frame (frame-parent ytm-radio--frame))
        (ytm-radio--position-frame ytm-radio--frame))
    (remove-hook 'window-size-change-functions
                 #'ytm-radio--reposition-on-resize)))

(defun ytm-radio--show-buffer (buffer)
  "Show browser BUFFER in a regular Emacs window."
  (ytm-radio--show-regular-buffer buffer))

(defun ytm-radio--show-side-window (buffer)
  "Show BUFFER in a top side window."
  (ytm-radio--render-side-window)
  (let* ((selected-window (selected-window))
         (window
          (display-buffer
           buffer
           `((display-buffer-in-side-window)
             (side . top)
             (slot . -1)
             (window-height . ,(ytm-radio--side-window-window-height))
             (dedicated . side)
             (post-command-select-window . nil)
             (window-parameters
              . ((no-other-window . t)
                 (no-delete-other-windows . t)
                 (mode-line-format . none)
                 (header-line-format . none)))))))
    (setq ytm-radio--side-window window)
    (when (window-live-p window)
      (set-window-dedicated-p window 'side)
      (set-window-fringes
       window 0 (if (ytm-radio--side-window-graphic-p) nil 0) nil t)
      (set-window-margins window 0 0)
      (set-window-scroll-bars window 0 nil 0 nil t)
      (window-preserve-size window nil t)
      (ytm-radio--render-side-window))
    (when (window-live-p selected-window)
      (select-window selected-window 'norecord))
    window))

(defun ytm-radio--hide-side-window ()
  "Hide the side-window now-playing view."
  (when (window-live-p ytm-radio--side-window)
    (let ((window ytm-radio--side-window))
      (setq ytm-radio--side-window nil)
      (set-window-dedicated-p window nil)
      (delete-window window)))
  (setq ytm-radio--side-window nil))

(defun ytm-radio--show-now-playing (&optional focus)
  "Show the now-playing view using `ytm-radio-display-style'.
FOCUS is accepted for compatibility; child frames stay non-focusable."
  (let ((buffer (ytm-radio--now-playing-buffer)))
    (ytm-radio--render-now-playing)
    (pcase ytm-radio-display-style
      ('side-window
       (ytm-radio--delete-frame)
       (ytm-radio--quit-buffer-window ytm-radio--now-playing-buffer-name)
       (ytm-radio--show-side-window buffer))
      ('child-frame
       (ytm-radio--hide-side-window)
       (ytm-radio--show-child-frame-or-buffer buffer focus))
      (_
       (ytm-radio--hide-side-window)
       (ytm-radio--show-regular-buffer buffer)))))

(defun ytm-radio--auto-show-now-playing ()
  "Show the now-playing view after playback changes when configured."
  (when ytm-radio-auto-show-now-playing
    (ytm-radio--show-now-playing nil)))

;;; Commands

;;;###autoload
(defun ytm-radio-open-at-point ()
  "Open the ytm-radio source or item at point."
  (interactive)
  (ytm-radio--ensure-loaded)
  (if-let* ((button (ytm-radio--button-at-point)))
      (push-button button)
    (if-let* ((item (ytm-radio--item-at-point))
              (source (ytm-radio--line-source-at-point)))
        (ytm-radio--open-item source item)
      (if-let* ((source (ytm-radio--source-at-point)))
          (if (and (eq (ytm-radio--view-kind) 'detail)
                   (ytm-radio--source-header-p source))
              (user-error "Detail header has no section")
            (ytm-radio--enter-source source))
        (user-error "No ytm-radio item at point")))))

;;;###autoload
(defun ytm-radio-back ()
  "Return to the previous ytm-radio browser view."
  (interactive)
  (if-let* ((previous (pop ytm-radio--browser-history)))
      (progn
        (setq ytm-radio--browser-view
              (ytm-radio--browser-history-entry-view previous))
        (ytm-radio--render-browser nil previous))
    (user-error "No previous ytm-radio view")))

;;;###autoload
(defun ytm-radio-next-item ()
  "Move point to the next item row."
  (interactive)
  (ytm-radio--move-item-line 1))

;;;###autoload
(defun ytm-radio-previous-item ()
  "Move point to the previous item row."
  (interactive)
  (ytm-radio--move-item-line -1))

;;;###autoload
(defun ytm-radio-next-section ()
  "Move point to the next ytm-radio browser section."
  (interactive)
  (let* ((positions (ytm-radio--section-positions))
         (next (seq-find (lambda (position) (> position (point)))
                         positions)))
    (if next
        (goto-char next)
      (user-error "No next section"))))

;;;###autoload
(defun ytm-radio-previous-section ()
  "Move point to the previous ytm-radio browser section."
  (interactive)
  (let* ((positions (reverse (ytm-radio--section-positions)))
         (previous (seq-find (lambda (position) (< position (point)))
                             positions)))
    (if previous
        (goto-char previous)
      (user-error "No previous section"))))

;;;###autoload
(defun ytm-radio-refresh ()
  "Refresh the current ytm-radio browser view."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((restore-entry (ytm-radio--browser-history-snapshot)))
    (pcase (ytm-radio--view-kind)
      ('home
       (ytm-radio--start-home-load nil restore-entry t))
      ('explore
       (ytm-radio--start-helper-target-load
        "explore" "explore" 'explore restore-entry t))
      ('library
       (ytm-radio--start-helper-target-load
        "library" "library" 'library restore-entry t))
      ('search
       (if-let* ((query (ytm-radio--view-value :query)))
           (ytm-radio--start-search-load query t restore-entry t)
         (call-interactively #'ytm-radio-search)))
      ('section
       (if-let* ((source-id (ytm-radio--view-value :source-id))
                 (source (ytm-radio--source source-id))
                 (import-spec (ytm-radio--source-refresh-spec source)))
           (if (string-equal (car import-spec) "home")
               (ytm-radio--start-home-load nil restore-entry t)
             (ytm-radio--start-helper-target-load
              (car import-spec)
              (cdr import-spec)
              ytm-radio--browser-view
              restore-entry
              t))
         (ytm-radio--render-browser nil restore-entry)))
      ('detail
       (if-let* ((browse-id (ytm-radio--detail-browse-id)))
           (ytm-radio--start-browse-id-load
            browse-id
            (ytm-radio--view-value :browse-params)
            (ytm-radio--view-value :context)
            (ytm-radio--browser-history-snapshot)
            t
            restore-entry
            t)
         (ytm-radio--render-browser nil restore-entry)))
      (_
       (ytm-radio--render-browser nil restore-entry)))))

;;;###autoload
(defun ytm-radio-home ()
  "Switch to the YouTube Music Home view."
  (interactive)
  (ytm-radio--ensure-loaded)
  (ytm-radio--select-browser-view 'home))

;;;###autoload
(defun ytm-radio-explore ()
  "Switch to the YouTube Music Explore view."
  (interactive)
  (ytm-radio--ensure-loaded)
  (ytm-radio--select-browser-view 'explore))

;;;###autoload
(defun ytm-radio-library ()
  "Switch to the YouTube Music Library view."
  (interactive)
  (ytm-radio--ensure-loaded)
  (ytm-radio--select-browser-view 'library))

;;;###autoload
(defun ytm-radio-search (query)
  "Search YouTube Music for QUERY through the Rust helper."
  (interactive (list (read-string "YouTube Music search: ")))
  (ytm-radio--start-search-load query))

(defun ytm-radio--login-restart-needed-p (helper-error)
  "Return non-nil when HELPER-ERROR means the login browser needs restart."
  (and (listp helper-error)
       (equal (map-elt helper-error 'code) "browser-restart-required")))

(defun ytm-radio--start-login (output &optional restart-running after-success)
  "Start asynchronous login into OUTPUT.
When RESTART-RUNNING is non-nil, allow the helper to restart the browser.
When AFTER-SUCCESS is non-nil, call it after importing auth."
  (when after-success
    (setq ytm-radio--login-continuation after-success))
  (message "Opening YouTube Music login window...")
  (ytm-radio--set-login-status "Login waiting in browser...")
  (setq
   ytm-radio--login-process
   (ytm-radio--call-helper-async
    (ytm-radio--helper-login-arguments output restart-running)
    (lambda (_data)
     (setq ytm-radio--login-process nil
            ytm-radio-helper-auth-file (expand-file-name output)
            ytm-radio--initial-home-refreshed nil)
      (ytm-radio--set-home-continuation nil)
      (ytm-radio--set-login-status nil)
      (ytm-radio--drop-account-helper-sources)
      (ytm-radio--save)
      (if-let* ((continuation ytm-radio--login-continuation))
          (progn
            (setq ytm-radio--login-continuation nil)
            (funcall continuation))
        (ytm-radio--set-browser-view 'home t)
        (ytm-radio--start-home-load))
      (message "YouTube Music login imported"))
    (lambda (diagnostic)
      (setq ytm-radio--login-process nil)
      (ytm-radio--set-login-status nil)
      (if (and (not restart-running)
               (ytm-radio--login-restart-needed-p diagnostic)
               (yes-or-no-p
                "Restart the login browser once to enable import? "))
          (ytm-radio--start-login output t after-success)
        (setq ytm-radio--login-continuation nil)
        (message "%s" (ytm-radio--helper-error-message diagnostic)))))))

;;;###autoload
(defun ytm-radio-prepare-login ()
  "Prepare an isolated Firefox-family profile and import its account session."
  (interactive)
  (when (process-live-p ytm-radio--login-process)
    (user-error "YouTube Music login is already running"))
  (let ((output (expand-file-name ytm-radio-helper-auth-file)))
    (message "Sign in to YouTube Music, then close the isolated browser...")
    (ytm-radio--set-login-status
     "Sign in, then close the isolated login browser...")
    (setq
     ytm-radio--login-process
     (ytm-radio--call-helper-async
      (ytm-radio--helper-prepare-login-arguments output)
      (lambda (_data)
        (setq ytm-radio--login-process nil)
        (ytm-radio--set-login-status nil)
        (message "Login profile prepared; importing account session...")
        (ytm-radio--start-login output))
      (lambda (diagnostic)
        (setq ytm-radio--login-process nil)
        (ytm-radio--set-login-status nil)
        (message "%s" (ytm-radio--helper-error-message diagnostic)))))))

;;;###autoload
(defun ytm-radio-doctor ()
  "Show a ytm-radio setup diagnostic report."
  (interactive)
  (let ((buffer (get-buffer-create ytm-radio--doctor-buffer-name)))
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert (ytm-radio--doctor-report))
        (goto-char (point-min))
        (special-mode)))
    (pop-to-buffer buffer)))

;;;###autoload
(defun ytm-radio ()
  "Open the ytm-radio YouTube Music browser."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((buffer (ytm-radio--buffer)))
    (ytm-radio--render)
    (ytm-radio--show-buffer buffer)
    (ytm-radio--maybe-refresh-initial-home)))

;;;###autoload
(defun ytm-radio-now-playing ()
  "Show or hide the configured now-playing view."
  (interactive)
  (ytm-radio--ensure-loaded)
  (if (ytm-radio--now-playing-visible-p)
      (ytm-radio-hide-now-playing)
    (ytm-radio--show-now-playing t)))

;;;###autoload
(defun ytm-radio-queue ()
  "Show the current runtime playback queue."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((buffer (ytm-radio--buffer)))
    (unless (map-elt ytm-radio--player :queue)
      (ytm-radio--ensure-current-queue))
    (ytm-radio--set-browser-view 'queue)
    (ytm-radio--show-buffer buffer)))

;;;###autoload
(defun ytm-radio-debug-now-playing-frame ()
  "Copy now-playing child-frame geometry diagnostics to the kill ring."
  (interactive)
  (let ((text (prin1-to-string (ytm-radio--now-playing-debug-data))))
    (kill-new text)
    (message "ytm-radio child-frame diagnostics copied: %s" text)))

;;;###autoload
(defun ytm-radio-add-url (url)
  "Play URL as a transient source."
  (interactive (list (read-string "YouTube or YouTube Music URL: ")))
  (ytm-radio--ensure-loaded)
  (ytm-radio--start-url-import url #'ytm-radio--play-source-object))

;;;###autoload
(defun ytm-radio-import-ytmusic-library ()
  "Import YouTube Music library sources through the Rust helper."
  (interactive)
  (ytm-radio--set-browser-view 'library t)
  (ytm-radio--start-helper-target-load "library" "library" 'library))

;;;###autoload
(defun ytm-radio-import-ytmusic-home ()
  "Import YouTube Music home recommendations through the Rust helper."
  (interactive)
  (ytm-radio--set-browser-view 'home t)
  (ytm-radio--start-home-load))

;;;###autoload
(defun ytm-radio-more ()
  "Open more content for the current section."
  (interactive)
  (ytm-radio--ensure-loaded)
  (if-let* ((source (ytm-radio--more-source-at-point)))
      (ytm-radio--enter-source source)
    (user-error "No more content at point")))

;;;###autoload
(defun ytm-radio-load-more-home ()
  "Load the next page of YouTube Music Home sections."
  (interactive)
  (ytm-radio--ensure-loaded)
  (unless (eq (ytm-radio--view-kind) 'home)
    (ytm-radio--set-browser-view 'home t))
  (ytm-radio--start-home-load t))

;;;###autoload
(defun ytm-radio-import-ytmusic-explore ()
  "Import YouTube Music explore sections through the Rust helper."
  (interactive)
  (ytm-radio--set-browser-view 'explore t)
  (ytm-radio--start-helper-target-load "explore" "explore" 'explore))

;;;###autoload
(defun ytm-radio-play-track ()
  "Select and play a known track."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((choices (mapcar (lambda (track)
                           (cons (ytm-radio--track-label track) track))
                         (ytm-radio--all-tracks))))
    (unless choices
      (user-error "No tracks; add a URL first"))
    (let ((track (cdr (assoc (completing-read "Track: " choices nil t)
                             choices))))
      (ytm-radio--set-playback-queue (ytm-radio--all-tracks) track)
      (ytm-radio--play-track track))))

;;;###autoload
(defun ytm-radio-play-source ()
  "Select a source and play its first track."
  (interactive)
  (ytm-radio--ensure-loaded)
  (if-let* ((source (ytm-radio--line-source-at-point)))
      (ytm-radio--play-source-object source)
    (let ((choices (mapcar (lambda (source)
                             (cons (ytm-radio--source-display-title source) source))
                           (map-values (ytm-radio--sources)))))
      (unless choices
        (user-error "No sources; add a URL first"))
      (let* ((source (cdr (assoc (completing-read "Source: " choices nil t)
                                 choices))))
        (ytm-radio--play-source-object source)))))

(defun ytm-radio--youtube-host-p (host)
  "Return non-nil when HOST is youtube.com or one of its subdomains."
  (or (string-equal host "youtube.com")
      (string-suffix-p ".youtube.com" host)))

(defun ytm-radio--youtube-video-id (id)
  "Return ID when it has the shape of a YouTube video id."
  (and (stringp id)
       (string-match-p "\\`[A-Za-z0-9_-]\\{11\\}\\'" id)
       id))

(defun ytm-radio--track-video-id-from-url (url)
  "Return a YouTube video id from URL, or nil."
  (when (and (stringp url)
             (string-match-p "\\`https?://" url))
    (let* ((parsed (url-generic-parse-url url))
           (host (downcase (or (url-host parsed) "")))
           (path (or (url-filename parsed) ""))
           (query-start (string-match-p "\\?" path))
           (path-only (if query-start
                          (substring path 0 query-start)
                        path))
           (query (and query-start
                       (substring path (1+ query-start)))))
      (cond
       ((ytm-radio--youtube-host-p host)
        (ytm-radio--youtube-video-id (ytm-radio--url-query-value query "v")))
       ((and (string-equal host "youtu.be")
             (string-match "\\`/\\([^/?#]+\\)" path-only))
        (ytm-radio--youtube-video-id (match-string 1 path-only)))))))

(defun ytm-radio--track-video-id (track)
  "Return TRACK's YouTube video id, or nil."
  (or (ytm-radio--track-video-id-from-url (map-elt track :url))
      (ytm-radio--youtube-video-id (map-elt track :id))))

(defun ytm-radio--normalized-like-status (status)
  "Return canonical like STATUS as a symbol, or nil."
  (pcase (ytm-radio--symbol-value status nil)
    ('like 'like)
    ('dislike 'dislike)
    (_ nil)))

(defun ytm-radio--item-video-id (item)
  "Return ITEM's YouTube video id, or nil."
  (or (ytm-radio--track-video-id-from-url (ytm-radio--item-url item))
      (ytm-radio--youtube-video-id (ytm-radio--item-id item))))

(defun ytm-radio--item-same-track-p (item track)
  "Return non-nil when ITEM identifies TRACK."
  (let ((item-video-id (ytm-radio--item-video-id item))
        (track-video-id (ytm-radio--item-video-id track))
        (item-id (ytm-radio--item-id item))
        (track-id (ytm-radio--item-id track))
        (item-url (ytm-radio--item-url item))
        (track-url (ytm-radio--item-url track)))
    (or (and item-video-id track-video-id
             (equal item-video-id track-video-id))
        (and item-id track-id (equal item-id track-id))
        (and item-url track-url (equal item-url track-url)))))

(defun ytm-radio--item-like-status (item)
  "Return ITEM's normalized like status, or nil."
  (when item
    (ytm-radio--normalized-like-status
     (or (map-elt item :like-status)
         (map-elt item 'like-status)))))

(defun ytm-radio--track-like-status (track)
  "Return TRACK's indexed or locally exposed like status."
  (when track
    (let* ((video-id (ytm-radio--item-video-id track))
           (indexed (and video-id
                         (ytm-radio--account-state 'like (list video-id)))))
      (if (or (null video-id)
              (eq indexed ytm-radio--account-state-missing))
          (ytm-radio--item-like-status track)
        indexed))))

(defun ytm-radio--track-library-status-p (track)
  "Return non-nil when TRACK is saved in the account library."
  (when track
    (let* ((video-id (ytm-radio--item-video-id track))
           (indexed (and video-id
                         (ytm-radio--account-state
                          'track-library (list video-id)))))
      (if (or (null video-id)
              (eq indexed ytm-radio--account-state-missing))
          (and (or (map-elt track :in-library)
                   (map-elt track 'in-library))
               t)
        indexed))))

(defun ytm-radio--helper-command-available-p ()
  "Return non-nil when the account helper can run without prompting."
  (ytm-radio--program-executable-p (ytm-radio--helper-command)))

(defun ytm-radio--track-status-refresh-available-p ()
  "Return non-nil when track account status can be refreshed silently."
  (and (ytm-radio--account-auth-available-p)
       (ytm-radio--helper-command-available-p)))

(defun ytm-radio--set-track-like-status (track status)
  "Set TRACK like STATUS and refresh visible playback UI."
  (when-let* ((video-id (ytm-radio--item-video-id track)))
    (ytm-radio--set-account-state
     'like (list video-id) (ytm-radio--normalized-like-status status)))
  (ytm-radio--render-now-playing)
  (when (get-buffer ytm-radio--library-buffer-name)
    (ytm-radio--render-browser)))

(defun ytm-radio--apply-track-status (track data)
  "Apply account status DATA to TRACK and refresh visible UI."
  (when (assq 'like-status data)
    (when-let* ((video-id (ytm-radio--item-video-id track)))
      (ytm-radio--set-account-state
       'like
       (list video-id)
       (ytm-radio--normalized-like-status (map-elt data 'like-status)))))
  (when (assq 'in-library data)
    (when-let* ((video-id (ytm-radio--item-video-id track)))
      (ytm-radio--set-account-state
       'track-library
       (list video-id)
       (and (map-elt data 'in-library) t))))
  (when (ytm-radio--item-same-track-p track (ytm-radio--current-track))
    (ytm-radio--render-now-playing))
  (when (get-buffer ytm-radio--library-buffer-name)
    (ytm-radio--render-browser)))

(defun ytm-radio--track-status-refresh-needed-p (video-id)
  "Return non-nil when VIDEO-ID account status should be requested."
  (let ((state (gethash video-id ytm-radio--track-status-refreshes)))
    (or (null state)
        (and (numberp state)
             (> (- (float-time) state)
                ytm-radio--track-status-refresh-ttl)))))

(defun ytm-radio--refresh-track-status (track)
  "Refresh TRACK account status in the background when possible."
  (when-let* ((video-id (ytm-radio--track-video-id track))
              ((ytm-radio--track-status-refresh-available-p))
              ((ytm-radio--track-status-refresh-needed-p video-id)))
    (puthash video-id 'pending ytm-radio--track-status-refreshes)
    (ytm-radio--call-helper-async
     (ytm-radio--helper-track-status-arguments video-id)
     (lambda (data)
       (puthash video-id (float-time) ytm-radio--track-status-refreshes)
       (ytm-radio--apply-track-status track data))
     (lambda (_diagnostic)
       (remhash video-id ytm-radio--track-status-refreshes)))))

(defun ytm-radio--rating-label (status)
  "Return a user-facing label for rating STATUS."
  (pcase status
    ('like "liked")
    ('dislike "disliked")
    (_ "unrated")))

(defun ytm-radio--current-track-video-id ()
  "Return the current track and its video id."
  (let* ((track (or (ytm-radio--current-track)
                    (user-error "Nothing is playing")))
         (video-id (or (ytm-radio--track-video-id track)
                       (user-error "Current track has no video id"))))
    (cons track video-id)))

(defun ytm-radio--rate-current-track (rating)
  "Rate the current track with RATING through the account helper."
  (ytm-radio--ensure-loaded)
  (let ((action nil))
    (setq
     action
     (lambda ()
       (let* ((target (ytm-radio--current-track-video-id))
              (track (car target))
              (video-id (cdr target))
              (rating-argument (pcase rating
                                 ('like "like")
                                 ('dislike "dislike")
                                 (_ "indifferent")))
              (local-status (pcase rating
                              ('like 'like)
                              ('dislike 'dislike)
                              (_ nil))))
         (ytm-radio--call-helper-async
          (ytm-radio--helper-rate-arguments video-id rating-argument)
          (lambda (_data)
            (ytm-radio--set-track-like-status track local-status)
            (message "Track %s" (ytm-radio--rating-label local-status)))
          (lambda (diagnostic)
            (ytm-radio--handle-account-helper-error diagnostic action))))))
    (ytm-radio--with-account-auth action "YouTube Music login required")))

;;;###autoload
(defun ytm-radio-like-current-track ()
  "Like or unlike the current track."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let* ((track (or (ytm-radio--current-track)
                    (user-error "Nothing is playing")))
         (rating (if (eq (ytm-radio--track-like-status track) 'like)
                     'indifferent
                   'like)))
    (ytm-radio--rate-current-track rating)))

;;;###autoload
(defun ytm-radio-dislike-current-track ()
  "Dislike the current track, or clear an existing dislike."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let* ((track (or (ytm-radio--current-track)
                    (user-error "Nothing is playing")))
         (rating (if (eq (ytm-radio--track-like-status track) 'dislike)
                     'indifferent
                   'dislike)))
    (ytm-radio--rate-current-track rating)))

(defun ytm-radio--current-track-like-status ()
  "Return the current track like status, or nil."
  (ytm-radio--track-like-status (ytm-radio--current-track)))

(defun ytm-radio--transient-state-token (label active)
  "Return propertized transient state LABEL.
When ACTIVE is non-nil, use the transient value face."
  (propertize label 'face (if active 'transient-value 'shadow)))

(defun ytm-radio--transient-state-choice (label choices active)
  "Return transient LABEL followed by CHOICES with ACTIVE highlighted."
  (concat label
          " ("
          (string-join
           (mapcar (lambda (choice)
                     (ytm-radio--transient-state-token
                      choice
                      (equal choice active)))
                   choices)
           "|")
          ")"))

(defun ytm-radio--current-like-action-label ()
  "Return the current-track like action label."
  (ytm-radio--transient-state-choice
   "Like" '("No" "Yes")
   (if (eq (ytm-radio--current-track-like-status) 'like) "Yes" "No")))

(defun ytm-radio--current-dislike-action-label ()
  "Return the current-track dislike action label."
  (ytm-radio--transient-state-choice
   "Dislike" '("No" "Yes")
   (if (eq (ytm-radio--current-track-like-status) 'dislike) "Yes" "No")))

(defun ytm-radio--current-track-library-action-label ()
  "Return the current-track library action label."
  (ytm-radio--transient-state-choice
   "Library" '("No" "Yes")
   (if (ytm-radio--track-library-status-p (ytm-radio--current-track))
       "Yes"
     "No")))

(defun ytm-radio--repeat-action-label ()
  "Return the repeat action label with current state."
  (ytm-radio--transient-state-choice
   "Repeat" '("Off" "All" "One")
   (pcase (ytm-radio--repeat-mode)
     ('all "All")
     ('one "One")
     (_ "Off"))))

(defun ytm-radio--shuffle-action-label ()
  "Return the shuffle action label with current state."
  (ytm-radio--transient-state-choice
   "Shuffle" '("Off" "On")
   (if (map-elt ytm-radio--player :shuffle) "On" "Off")))

(defun ytm-radio--merge-missing-track-metadata (target source)
  "Fill missing metadata in TARGET from SOURCE and return TARGET."
  (dolist (field '(:title :url :duration :artist :album :thumbnail-url
                   :account-auth :explicit))
    (when (and (null (map-elt target field))
               (map-elt source field))
      (setf (map-elt target field) (map-elt source field))))
  target)

;;;###autoload
(defun ytm-radio-toggle-current-track-library ()
  "Save or remove the current track from the YouTube Music library."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((action nil))
    (setq
     action
     (lambda ()
       (let* ((target (ytm-radio--current-track-video-id))
              (track (car target))
              (video-id (cdr target)))
         (ytm-radio--call-helper-async
          (ytm-radio--helper-library-arguments video-id "toggle")
          (lambda (data)
            (let ((in-library (map-elt data 'in-library)))
              (ytm-radio--apply-track-status track data)
              (message "Track %s library"
                       (if in-library "saved to" "removed from"))))
          (lambda (diagnostic)
            (ytm-radio--handle-account-helper-error diagnostic action))))))
	  (ytm-radio--with-account-auth action "YouTube Music login required")))

(defun ytm-radio--detail-primary-source ()
  "Return the primary source for the current detail view."
  (unless (eq (ytm-radio--view-kind) 'detail)
    (user-error "This command only works in a detail view"))
  (let ((sources (seq-keep #'ytm-radio--source
                           (ytm-radio--view-value :source-ids))))
    (or (seq-find
         (lambda (source)
           (or (ytm-radio--detail-library-source-p source)
               (ytm-radio--detail-subscription-source-p source)))
        sources)
        (car sources)
        (user-error "No detail source"))))

(defun ytm-radio--detail-account-target (predicate description)
  "Return detail account target when PREDICATE accepts its source.
DESCRIPTION is used in the user error."
  (let ((source (ytm-radio--detail-primary-source))
        (browse-id (ytm-radio--detail-browse-id)))
    (unless (and browse-id (not (string-empty-p browse-id)))
      (user-error "Detail view has no browse id"))
    (unless (funcall predicate source)
      (user-error "Current detail is not a %s" description))
    (list source browse-id (ytm-radio--view-value :browse-params))))

(defun ytm-radio--detail-library-action (source)
  "Return library helper action for detail SOURCE."
  (if (ytm-radio--truthy-field-p source :in-library)
      "remove"
    "save"))

(defun ytm-radio--detail-subscription-action (source)
  "Return subscription helper action for detail SOURCE."
  (if (ytm-radio--truthy-field-p source :subscribed)
      "unsubscribe"
    "subscribe"))

;;;###autoload
(defun ytm-radio-toggle-detail-library ()
  "Save or remove the current album or playlist from the YouTube Music library."
  (interactive)
  (ytm-radio--ensure-loaded)
  (pcase-let ((`(,source ,browse-id ,params)
               (ytm-radio--detail-account-target
                #'ytm-radio--detail-library-source-p
                "library item")))
    (let ((action nil)
          (library-action (ytm-radio--detail-library-action source)))
      (setq
       action
       (lambda ()
         (message "Updating library...")
         (ytm-radio--call-helper-async
          (ytm-radio--helper-item-library-arguments browse-id library-action params)
          (lambda (data)
            (let ((in-library (map-elt data 'in-library)))
              (ytm-radio--apply-detail-helper-data
               data browse-id params (ytm-radio--view-value :context))
              (message "%s library"
                       (if in-library "Saved to" "Removed from"))))
          (lambda (diagnostic)
            (ytm-radio--handle-account-helper-error diagnostic action)))))
      (ytm-radio--with-account-auth action "YouTube Music login required"))))

;;;###autoload
(defun ytm-radio-toggle-detail-subscription ()
  "Subscribe or unsubscribe the current artist/channel detail."
  (interactive)
  (ytm-radio--ensure-loaded)
  (pcase-let ((`(,source ,browse-id ,params)
               (ytm-radio--detail-account-target
                #'ytm-radio--detail-subscription-source-p
                "subscription item")))
    (let ((action nil)
          (subscription-action (ytm-radio--detail-subscription-action source)))
      (setq
       action
       (lambda ()
         (message "Updating subscription...")
         (ytm-radio--call-helper-async
          (ytm-radio--helper-subscription-arguments
           browse-id subscription-action params)
          (lambda (data)
            (let ((subscribed (map-elt data 'subscribed)))
              (ytm-radio--apply-detail-helper-data
               data browse-id params (ytm-radio--view-value :context))
              (message "%s" (if subscribed "Subscribed" "Unsubscribed"))))
          (lambda (diagnostic)
            (ytm-radio--handle-account-helper-error diagnostic action)))))
      (ytm-radio--with-account-auth action "YouTube Music login required"))))

(defun ytm-radio--mix-queue-tracks (seed tracks)
  "Return a mix queue from SEED followed by unique TRACKS."
  (let* ((seed-video-id (ytm-radio--track-video-id seed))
         (seed-match
          (seq-find
           (lambda (track)
             (equal (ytm-radio--track-video-id track) seed-video-id))
           tracks)))
    (when seed-match
      (ytm-radio--merge-missing-track-metadata seed seed-match))
    (cons seed
          (seq-remove
           (lambda (track)
             (equal (ytm-radio--track-video-id track) seed-video-id))
           tracks))))

;;;###autoload
(defun ytm-radio-start-current-track-mix ()
  "Start a YouTube Music mix queue from the current track."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((action nil))
    (setq
     action
     (lambda ()
       (let* ((target (ytm-radio--current-track-video-id))
              (track (car target))
              (video-id (cdr target)))
         (message "Loading mix...")
         (ytm-radio--call-helper-async
          (ytm-radio--helper-radio-arguments video-id)
          (lambda (data)
            (let* ((sources (ytm-radio--helper-sources data))
                   (radio-tracks (apply #'append
                                        (mapcar (lambda (source)
                                                  (ytm-radio--source-tracks source))
                                                sources)))
                   (queue (ytm-radio--mix-queue-tracks track radio-tracks)))
              (ytm-radio--set-playback-queue queue track)
              (ytm-radio--play-track track)
              (message "Started mix for %s (%d tracks; Q shows queue)"
                       (ytm-radio--track-label track)
                       (length queue))))
          (lambda (diagnostic)
            (ytm-radio--handle-account-helper-error diagnostic action))))))
    (ytm-radio--with-account-auth action "YouTube Music login required")))

;;;###autoload
(defun ytm-radio-start-current-track-radio ()
  "Compatibility alias for `ytm-radio-start-current-track-mix'."
  (interactive)
  (ytm-radio-start-current-track-mix))

(defun ytm-radio--playlist-option-label (option)
  "Return a completion label for playlist OPTION."
  (let ((title (or (map-elt option 'title) "Untitled playlist"))
        (subtitle (map-elt option 'subtitle)))
    (if (and (stringp subtitle)
             (not (string-empty-p subtitle)))
        (format "%s - %s" title subtitle)
      title)))

(defun ytm-radio--read-playlist-option (options)
  "Read and return one playlist option from OPTIONS."
  (let ((choices (mapcar (lambda (option)
                           (cons (ytm-radio--playlist-option-label option)
                                 option))
                         options)))
    (unless choices
      (user-error "No writable playlists returned by YouTube Music"))
    (cdr (assoc (completing-read "Add to playlist: " choices nil t)
                choices))))

;;;###autoload
(defun ytm-radio-add-current-track-to-playlist ()
  "Add the current track to a selected YouTube Music playlist."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let ((action nil))
    (setq
     action
     (lambda ()
       (let* ((target (ytm-radio--current-track-video-id))
              (track (car target))
              (video-id (cdr target)))
         (message "Loading playlists...")
         (ytm-radio--call-helper-async
          (ytm-radio--helper-playlist-options-arguments video-id)
          (lambda (data)
            (condition-case error
                (let* ((option (ytm-radio--read-playlist-option
                                (or (map-elt data 'options) nil)))
                       (playlist-id (map-elt option 'playlist-id)))
                  (unless (and (stringp playlist-id)
                               (not (string-empty-p playlist-id)))
                    (user-error "Playlist option has no playlist id"))
                  (ytm-radio--call-helper-async
                   (ytm-radio--helper-add-to-playlist-arguments
                    video-id playlist-id)
                   (lambda (_data)
                     (message "Added %s to %s"
                              (ytm-radio--track-label track)
                              (or (map-elt option 'title) playlist-id)))
                   (lambda (diagnostic)
                     (ytm-radio--handle-account-helper-error
                      diagnostic action))))
              (user-error
               (message "%s" (error-message-string error)))))
          (lambda (diagnostic)
            (ytm-radio--handle-account-helper-error diagnostic action))))))
    (ytm-radio--with-account-auth action "YouTube Music login required")))

;;;###autoload
(defun ytm-radio-play-current-track-next ()
  "Insert the current track immediately after the runtime queue position."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let* ((track (or (ytm-radio--current-track)
                    (user-error "Nothing is playing")))
         (queue (copy-sequence (ytm-radio--ensure-current-queue)))
         (index (or (ytm-radio--queue-current-index track) 0))
         (insert-index (min (1+ index) (length queue))))
    (setq queue (append (seq-take queue insert-index)
                        (list (copy-tree track))
                        (nthcdr insert-index queue)))
    (setf (map-elt ytm-radio--player :queue) queue
          (map-elt ytm-radio--player :queue-index) index)
    (message "Will play %s next" (ytm-radio--track-label track))))

;;;###autoload
(defun ytm-radio-add-current-track-to-queue ()
  "Append the current track to the runtime queue."
  (interactive)
  (ytm-radio--ensure-loaded)
  (let* ((track (or (ytm-radio--current-track)
                    (user-error "Nothing is playing")))
         (queue (copy-sequence (ytm-radio--ensure-current-queue))))
    (setf (map-elt ytm-radio--player :queue)
          (append queue (list (copy-tree track))))
    (message "Added %s to queue" (ytm-radio--track-label track))))

(defun ytm-radio--valid-seek-seconds-p (seconds)
  "Return non-nil when SECONDS is a valid seek step."
  (and (numberp seconds) (> seconds 0)))

(defun ytm-radio--parse-seek-seconds (string)
  "Return positive seek seconds parsed from STRING, or nil."
  (when (and (stringp string)
             (string-match-p
              "\\`[[:space:]]*[+]?[0-9]+\\(?:\\.[0-9]+\\)?[[:space:]]*\\'"
              string))
    (let ((seconds (string-to-number string)))
      (and (ytm-radio--valid-seek-seconds-p seconds) seconds))))

(defun ytm-radio--seek-step ()
  "Return the configured default seek step."
  (unless (ytm-radio--valid-seek-seconds-p ytm-radio-seek-step)
    (user-error "Invalid `ytm-radio-seek-step': %S" ytm-radio-seek-step))
  ytm-radio-seek-step)

(defun ytm-radio--seek-amount (seconds)
  "Return validated seek amount from SECONDS or `ytm-radio-seek-step'."
  (let ((amount (or seconds (ytm-radio--seek-step))))
    (unless (numberp amount)
      (user-error "Seek seconds must be numeric"))
    amount))

(defun ytm-radio--read-seek-seconds (prompt initial-input _history)
  "Read seek seconds with PROMPT and INITIAL-INPUT."
  (let* ((initial (cond
                   ((numberp initial-input) initial-input)
                   ((and (stringp initial-input)
                         (not (string-empty-p initial-input)))
                    (or (ytm-radio--parse-seek-seconds initial-input)
                        (user-error "Seek seconds must be positive")))
                   (t
                    (ytm-radio--seek-step))))
         (seconds (read-number prompt initial)))
    (unless (ytm-radio--valid-seek-seconds-p seconds)
      (user-error "Seek seconds must be positive"))
    (number-to-string seconds)))

(defun ytm-radio--init-current-actions-seek-step (object)
  "Initialize transient seek step OBJECT from `ytm-radio-seek-step'."
  (oset object value (number-to-string (ytm-radio--seek-step))))

(transient-define-infix ytm-radio--current-actions-seek-step ()
  "Set seek seconds for the current transient menu."
  :description "Seek seconds"
  :class 'transient-option
  :argument "--seek="
  :format " %k %d %v"
  :reader #'ytm-radio--read-seek-seconds
  :init-value #'ytm-radio--init-current-actions-seek-step
  :always-read t)

(defun ytm-radio--current-actions-args ()
  "Return active current-actions transient arguments."
  (unless (eq transient-current-command 'ytm-radio-current-actions)
    (user-error "Current actions transient is not active"))
  (transient-args transient-current-command))

(defun ytm-radio--current-actions-seek-seconds (arguments)
  "Return seek seconds from transient ARGUMENTS."
  (let* ((raw (seq-some
               (lambda (argument)
                 (when (and (stringp argument)
                            (string-prefix-p "--seek=" argument))
                   (substring argument (length "--seek="))))
               arguments))
         (seconds (and raw (ytm-radio--parse-seek-seconds raw))))
    (unless (ytm-radio--valid-seek-seconds-p seconds)
      (user-error "Current actions has no valid seek seconds"))
    seconds))

(transient-define-suffix ytm-radio--current-actions-seek-forward (arguments)
  "Seek forward using the current transient seek step."
  (interactive (list (ytm-radio--current-actions-args)))
  (ytm-radio-seek-forward
   (ytm-radio--current-actions-seek-seconds arguments)))

(transient-define-suffix ytm-radio--current-actions-seek-backward (arguments)
  "Seek backward using the current transient seek step."
  (interactive (list (ytm-radio--current-actions-args)))
  (ytm-radio-seek-backward
   (ytm-radio--current-actions-seek-seconds arguments)))

;;;###autoload(autoload 'ytm-radio-current-actions "ytm-radio" nil t)
(transient-define-prefix ytm-radio-current-actions ()
  "Show actions for the current track."
  [:class transient-row
   "Options"
   ("-s" "Seek seconds" ytm-radio--current-actions-seek-step)]
  [["Playback"
    ("SPC" "Pause/resume" ytm-radio-toggle-pause)
    ("b" "Back" ytm-radio--current-actions-seek-backward)
    ("f" "Forward" ytm-radio--current-actions-seek-forward)
    ("n" "Next" ytm-radio-next)
    ("p" "Previous" ytm-radio-previous)
    ("r" ytm-radio-cycle-repeat
     :description ytm-radio--repeat-action-label)
    ("s" ytm-radio-toggle-shuffle
     :description ytm-radio--shuffle-action-label)]
   ["Track"
    ("l" ytm-radio-like-current-track
     :description ytm-radio--current-like-action-label)
    ("d" ytm-radio-dislike-current-track
     :description ytm-radio--current-dislike-action-label)
    ("L" ytm-radio-toggle-current-track-library
     :description ytm-radio--current-track-library-action-label)
    ("P" "Add to playlist" ytm-radio-add-current-track-to-playlist)
    ("R" "Start mix" ytm-radio-start-current-track-mix)
    ("S" "Share" ytm-radio-share)]
   ["View/Queue"
    ("c" "Now playing" ytm-radio-now-playing)
    ("Q" "View queue" ytm-radio-queue)
    ("a" "Add to queue" ytm-radio-add-current-track-to-queue)]])

;;;###autoload
(defun ytm-radio-toggle-pause ()
  "Toggle playback pause, or resume the last known track."
  (interactive)
  (ytm-radio--ensure-loaded)
  (cond ((process-live-p (map-elt ytm-radio--player :process))
         (ytm-radio--mpv-send (list "cycle" "pause")))
        ((ytm-radio--current-track)
         (ytm-radio--play-track (ytm-radio--current-track)))
        (t
         (user-error "Nothing to play"))))

;;;###autoload
(defun ytm-radio-cycle-repeat ()
  "Cycle repeat mode between off, all, and one."
  (interactive)
  (let* ((next (pcase (ytm-radio--repeat-mode)
                 ('all 'one)
                 ('one nil)
                 (_ 'all)))
         (label (pcase next
                  ('all "all")
                  ('one "one")
                  (_ "off"))))
    (setf (map-elt ytm-radio--player :repeat) next)
    (ytm-radio--render-now-playing)
    (message "Repeat: %s" label)))

;;;###autoload
(defun ytm-radio-toggle-shuffle ()
  "Toggle shuffle playback."
  (interactive)
  (let ((enabled (not (map-elt ytm-radio--player :shuffle))))
    (setf (map-elt ytm-radio--player :shuffle) enabled)
    (ytm-radio--render-now-playing)
    (message "Shuffle: %s" (if enabled "on" "off"))))

;;;###autoload
(defun ytm-radio-stop ()
  "Stop playback."
  (interactive)
  (ytm-radio--stop-process)
  (ytm-radio--render)
  (message "Stopped"))

;;;###autoload
(defun ytm-radio-next ()
  "Play the next track in the runtime queue or catalog order."
  (interactive)
  (if-let* ((track (ytm-radio--current-track))
            (next (ytm-radio--next-track track)))
      (ytm-radio--play-track next)
    (user-error "No next track")))

;;;###autoload
(defun ytm-radio-previous ()
  "Play the previous track in the runtime queue or catalog order."
  (interactive)
  (if-let* ((track (ytm-radio--current-track))
            (previous (ytm-radio--previous-track track)))
      (ytm-radio--play-track previous)
    (user-error "No previous track")))

;;;###autoload
(defun ytm-radio-share ()
  "Copy the current track URL for sharing."
  (interactive)
  (if-let* ((track (ytm-radio--current-track))
            (url (map-elt track :url)))
      (progn
        (kill-new url)
        (message "Copied track URL"))
    (user-error "No track URL to share")))

;;;###autoload
(defun ytm-radio-seek-forward (&optional seconds)
  "Seek forward SECONDS seconds, defaulting to `ytm-radio-seek-step'."
  (interactive)
  (unless (process-live-p (map-elt ytm-radio--player :ipc-process))
    (user-error "Not playing"))
  (ytm-radio--mpv-send (list "seek" (ytm-radio--seek-amount seconds))))

;;;###autoload
(defun ytm-radio-seek-backward (&optional seconds)
  "Seek backward SECONDS seconds, defaulting to `ytm-radio-seek-step'."
  (interactive)
  (ytm-radio-seek-forward (- (ytm-radio--seek-amount seconds))))

(defun ytm-radio--quit-buffer-window (buffer-name)
  "Quit the visible window showing BUFFER-NAME."
  (when-let* ((buffer (get-buffer buffer-name))
              (window (get-buffer-window buffer t)))
    (quit-window nil window)))

;;;###autoload
(defun ytm-radio-hide-browser ()
  "Hide the ytm-radio browser buffer without hiding now-playing."
  (interactive)
  (ytm-radio--quit-buffer-window ytm-radio--library-buffer-name))

;;;###autoload
(defun ytm-radio-hide-now-playing ()
  "Hide the ytm-radio now-playing view without stopping playback."
  (interactive)
  (ytm-radio--hide-side-window)
  (ytm-radio--delete-frame)
  (ytm-radio--quit-buffer-window ytm-radio--now-playing-buffer-name))

;;;###autoload
(defun ytm-radio-hide ()
  "Hide all ytm-radio UI without stopping playback."
  (interactive)
  (ytm-radio-hide-now-playing)
  (ytm-radio-hide-browser))

(provide 'ytm-radio)

;;; ytm-radio.el ends here
