;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.61.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a60c44edd1f9e69fde115abeb7ee6c5795e46913"
  :revdesc "a60c44edd1f9"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
