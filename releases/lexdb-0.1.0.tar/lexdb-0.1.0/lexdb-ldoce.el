;;; lexdb-ldoce.el --- LDOCE adapter for lexdb -*- lexical-binding: t -*-

;; Copyright (C) 2025

;; Author: Your Name
;; Package-Requires: ((emacs "29.1") (lexdb "0.1.0"))

;;; Commentary:

;; Adapter for Longman Dictionary of Contemporary English (LDOCE).
;; Supports both legacy schema (v1) and new LexDB schema (v2).
;;
;; Usage:
;;   (require 'lexdb-ldoce)
;;   (setq lexdb-ldoce-db-file "~/path/to/ldoce.db")
;;   (setq lexdb-ldoce-audio-directory "~/path/to/audio/")
;;   (lexdb-ldoce-register)

;;; Code:

(require 'lexdb)
(require 'sqlite)

;;;; ============================================================
;;;; Utility Functions
;;;; ============================================================

(defsubst lexdb-ldoce--non-empty-string-p (s)
  "Return t if S is a non-empty string."
  (and s (stringp s) (not (string-empty-p s))))

;;;; ============================================================
;;;; Configuration
;;;; ============================================================

(defgroup lexdb-ldoce nil
  "LDOCE adapter settings."
  :prefix "lexdb-ldoce-"
  :group 'lexdb)

(defcustom lexdb-ldoce-db-file nil
  "Path to LDOCE SQLite database."
  :type '(choice (const nil) file)
  :group 'lexdb-ldoce)

(defcustom lexdb-ldoce-audio-directory nil
  "Path to LDOCE audio files directory."
  :type '(choice (const nil) directory)
  :group 'lexdb-ldoce)

;;;; ============================================================
;;;; Database Connection
;;;; ============================================================

(defvar lexdb-ldoce--db nil
  "Database connection for LDOCE.")

(defvar lexdb-ldoce--cache (make-hash-table :test 'eql)
  "Cache for prefetched data.")

(defun lexdb-ldoce--ensure-db ()
  "Ensure database connection is open."
  (unless lexdb-ldoce-db-file
    (error "Please set `lexdb-ldoce-db-file'"))
  (unless (file-exists-p lexdb-ldoce-db-file)
    (error "Database file not found: %s" lexdb-ldoce-db-file))
  (unless (and lexdb-ldoce--db (sqlitep lexdb-ldoce--db))
    (setq lexdb-ldoce--db (sqlite-open lexdb-ldoce-db-file)))
  lexdb-ldoce--db)

(defun lexdb-ldoce--close ()
  "Close database connection and clear cache."
  (when (and lexdb-ldoce--db (sqlitep lexdb-ldoce--db))
    (sqlite-close lexdb-ldoce--db)
    (setq lexdb-ldoce--db nil))
  (clrhash lexdb-ldoce--cache))

;;;; ============================================================
;;;; Schema V2 (New LexDB Schema)
;;;; ============================================================

(defun lexdb-ldoce--v2-row-to-sense (sense-row db)
  "Convert V2 SENSE-ROW to lexdb-sense."
  (pcase-let ((`(,id ,sense-num ,signpost ,definition ,_sort) sense-row))
    (let* ((ex-rows (sqlite-select db
                     "SELECT text, audio_path FROM examples WHERE sense_id = ? ORDER BY sort_order"
                     (list id)))
           (examples (mapcar (lambda (ex)
                               (lexdb-example-create
                                :text (nth 0 ex)
                                :audio (let ((p (nth 1 ex)))
                                         (when (lexdb-ldoce--non-empty-string-p p) p))))
                             ex-rows))
           (label-rows (sqlite-select db
                        "SELECT label_type, label_value FROM labels WHERE sense_id = ? ORDER BY sort_order"
                        (list id)))
           (labels (mapcar (lambda (l)
                             (lexdb-label-create :type (intern (nth 0 l)) :value (nth 1 l)))
                           label-rows))
           (gram-patterns (lexdb-ldoce--v2-fetch-grammar-patterns id db))
           (sense-relations (lexdb-ldoce--v2-fetch-sense-relations id db)))
      (lexdb-sense-create
       :id id
       :number (when (lexdb-ldoce--non-empty-string-p sense-num) sense-num)
       :signpost (when (lexdb-ldoce--non-empty-string-p signpost) signpost)
       :definition definition
       :examples examples
       :grammar-patterns gram-patterns
       :labels labels
       :relations sense-relations))))

(defun lexdb-ldoce--v2-fetch-grammar-patterns (sense-id db)
  "Fetch grammar patterns for SENSE-ID from V2 schema."
  (let ((rows (sqlite-select db
               "SELECT id, pattern FROM grammar_patterns WHERE sense_id = ? ORDER BY sort_order"
               (list sense-id))))
    (mapcar (lambda (row)
              (pcase-let ((`(,pat-id ,pattern) row))
                (let ((ex-rows (sqlite-select db
                                "SELECT text, audio_path FROM grammar_examples WHERE pattern_id = ? ORDER BY sort_order"
                                (list pat-id))))
                  (lexdb-grammar-pattern-create
                   :pattern pattern
                   :examples (mapcar (lambda (ex)
                                       (lexdb-example-create
                                        :text (nth 0 ex)
                                        :audio (let ((p (nth 1 ex)))
                                                 (when (lexdb-ldoce--non-empty-string-p p) p))))
                                     ex-rows)))))
            rows)))

(defun lexdb-ldoce--v2-build-pronunciations (entry-id db)
  "Build pronunciations for ENTRY-ID from V2 schema."
  (let ((rows (sqlite-select db
               "SELECT variant, ipa, audio_path FROM pronunciations WHERE entry_id = ? ORDER BY sort_order"
               (list entry-id))))
    (delq nil
          (mapcar (lambda (row)
                    (pcase-let ((`(,variant ,ipa ,audio) row))
                      (when (or (lexdb-ldoce--non-empty-string-p ipa)
                                (lexdb-ldoce--non-empty-string-p audio))
                        (lexdb-pronunciation-create
                         :ipa ipa
                         :variant (when variant (intern variant))
                         :audio (when (lexdb-ldoce--non-empty-string-p audio) audio)))))
                  rows))))

(defun lexdb-ldoce--v2-fetch-relations (entry-id db)
  "Fetch entry-level relations for ENTRY-ID from V2 schema.
Only returns relations where sense_id IS NULL."
  (let ((rows (sqlite-select db
               "SELECT relation_type, target_text, target_link FROM relations WHERE entry_id = ? AND sense_id IS NULL ORDER BY sort_order"
               (list entry-id))))
    (delq nil
          (mapcar (lambda (row)
                    (pcase-let ((`(,rel-type ,target ,link) row))
                      (when (lexdb-ldoce--non-empty-string-p target)
                        (lexdb-relation-create
                         :type (intern rel-type)
                         :target target
                         :target-link (when (lexdb-ldoce--non-empty-string-p link) link)))))
                  rows))))

(defun lexdb-ldoce--v2-fetch-sense-relations (sense-id db)
  "Fetch sense-level relations for SENSE-ID from V2 schema."
  (let ((rows (sqlite-select db
               "SELECT relation_type, target_text, target_link FROM relations WHERE sense_id = ? ORDER BY sort_order"
               (list sense-id))))
    (delq nil
          (mapcar (lambda (row)
                    (pcase-let ((`(,rel-type ,target ,link) row))
                      (when (lexdb-ldoce--non-empty-string-p target)
                        (lexdb-relation-create
                         :type (intern rel-type)
                         :target target
                         :target-link (when (lexdb-ldoce--non-empty-string-p link) link)))))
                  rows))))

(defun lexdb-ldoce--v2-fetch-attributes (entry-id db)
  "Fetch EAV attributes for ENTRY-ID from V2 schema."
  (let ((rows (sqlite-select db
               "SELECT attr_key, attr_value, attr_type FROM entry_attributes WHERE entry_id = ?"
               (list entry-id))))
    (mapcar (lambda (row)
              (pcase-let ((`(,key ,value ,type) row))
                (cons (intern key)
                      (pcase type
                        ("json" (json-read-from-string value))
                        ("integer" (string-to-number value))
                        ("boolean" (not (equal value "0")))
                        (_ value)))))
            rows)))

(defun lexdb-ldoce--v2-row-to-entry (row)
  "Convert V2 database ROW to lexdb-entry."
  (pcase-let ((`(,id ,_dict-id ,word ,_word-lower ,hyph) row))
    (let* ((db (lexdb-ldoce--ensure-db))
           (sense-rows (sqlite-select db
                        "SELECT id, sense_number, signpost, definition, sort_order FROM senses WHERE entry_id = ? ORDER BY sort_order"
                        (list id)))
           (senses (mapcar (lambda (r) (lexdb-ldoce--v2-row-to-sense r db)) sense-rows))
           (prons (lexdb-ldoce--v2-build-pronunciations id db))
           (relations (lexdb-ldoce--v2-fetch-relations id db))
           (metadata (lexdb-ldoce--v2-fetch-attributes id db))
           (label-rows (sqlite-select db
                        "SELECT label_type, label_value FROM labels WHERE entry_id = ? AND sense_id IS NULL"
                        (list id))))
      ;; Add pos from labels
      (dolist (label label-rows)
        (pcase-let ((`(,ltype ,lvalue) label))
          (when (and (equal ltype "pos") (not (assq 'ldoce/pos metadata)))
            (push (cons 'ldoce/pos lvalue) metadata))))
      ;; Add audio paths to metadata
      (dolist (pron prons)
        (when-let ((audio (lexdb-pronunciation-audio pron)))
          (pcase (lexdb-pronunciation-variant pron)
            ('uk (unless (assq 'ldoce/audio-uk metadata)
                   (push (cons 'ldoce/audio-uk audio) metadata)))
            ('us (unless (assq 'ldoce/audio-us metadata)
                   (push (cons 'ldoce/audio-us audio) metadata))))))
      (lexdb-entry-create
       :id id :headword word
       :headword-display (when (lexdb-ldoce--non-empty-string-p hyph) hyph)
       :senses senses :pronunciations prons :relations relations :metadata metadata))))

;;;; ============================================================
;;;; Adapter Functions
;;;; ============================================================

(defun lexdb-ldoce--lookup (word)
  "Look up WORD in LDOCE database.
First tries exact match, then tries fuzzy match (LIKE) as fallback."
  (let* ((db (lexdb-ldoce--ensure-db))
         (word-lower (downcase word))
         ;; First try exact match
         (rows (sqlite-select db
                "SELECT id, dict_id, headword, headword_lower, headword_display
                 FROM entries WHERE headword_lower = ? AND dict_id = 'ldoce'"
                (list word-lower))))
    ;; If no results, try fuzzy match (word at start, handles "Big Apple" -> "Big Apple, the")
    (unless rows
      (setq rows (sqlite-select db
                  "SELECT id, dict_id, headword, headword_lower, headword_display
                   FROM entries WHERE headword_lower LIKE ? AND dict_id = 'ldoce'"
                  (list (concat word-lower "%")))))
    ;; If still no results, try word anywhere
    (unless rows
      (setq rows (sqlite-select db
                  "SELECT id, dict_id, headword, headword_lower, headword_display
                   FROM entries WHERE headword_lower LIKE ? AND dict_id = 'ldoce'"
                  (list (concat "%" word-lower "%")))))
    (mapcar #'lexdb-ldoce--v2-row-to-entry rows)))

(defun lexdb-ldoce--get-collocations (entry-id)
  "Get collocations for ENTRY-ID."
  (or (gethash (cons entry-id 'collocations) lexdb-ldoce--cache)
      (let* ((db (lexdb-ldoce--ensure-db))
             (rows (sqlite-select db
                    "SELECT id, category, text, gloss FROM collocations WHERE entry_id = ? ORDER BY sort_order"
                    (list entry-id)))
             (colls (mapcar (lambda (row)
                              (pcase-let ((`(,coll-id ,cat ,coll ,gloss) row))
                                (let ((ex-rows (sqlite-select db
                                                "SELECT text FROM collocation_examples WHERE collocation_id = ? ORDER BY sort_order"
                                                (list coll-id))))
                                  (lexdb-collocation-create
                                   :category cat :text coll :gloss gloss
                                   :examples (mapcar #'car ex-rows)))))
                            rows)))
        (puthash (cons entry-id 'collocations) colls lexdb-ldoce--cache)
        colls)))

(defun lexdb-ldoce--get-relations (entry-id type)
  "Get relations of TYPE for ENTRY-ID."
  (let* ((db (lexdb-ldoce--ensure-db))
         (rows (sqlite-select db
                "SELECT target_text, target_link FROM relations WHERE entry_id = ? AND relation_type = ? ORDER BY sort_order"
                (list entry-id (symbol-name type)))))
    (mapcar (lambda (row)
              (pcase-let ((`(,target ,link) row))
                (lexdb-relation-create
                 :type type
                 :target target
                 :target-link (when (lexdb-ldoce--non-empty-string-p link) link))))
            rows)))

(defun lexdb-ldoce--prefetch (entry-ids)
  "Prefetch data for ENTRY-IDS."
  (when entry-ids
    (let* ((db (lexdb-ldoce--ensure-db))
           (ph (mapconcat (lambda (_) "?") entry-ids ","))
           (coll-rows (sqlite-select db
                       (format "SELECT id, entry_id, category, text, gloss FROM collocations WHERE entry_id IN (%s) ORDER BY entry_id, sort_order" ph)
                       entry-ids))
           (entry-colls (make-hash-table :test 'eql)))
      (dolist (row coll-rows) (push row (gethash (nth 1 row) entry-colls)))
      (maphash (lambda (entry-id rows)
                 (puthash (cons entry-id 'collocations)
                          (mapcar (lambda (row)
                                    (pcase-let ((`(,coll-id ,_ ,cat ,coll ,gloss) row))
                                      (lexdb-collocation-create
                                       :category cat :text coll :gloss gloss
                                       :examples (mapcar #'car (sqlite-select db
                                                                "SELECT text FROM collocation_examples WHERE collocation_id = ? ORDER BY sort_order"
                                                                (list coll-id))))))
                                  (nreverse rows))
                          lexdb-ldoce--cache))
               entry-colls))))

;;;; ============================================================
;;;; Lemmatization
;;;; ============================================================

(defun lexdb-ldoce--try-lemma (word suffix replacement)
  "Try removing SUFFIX from WORD and adding REPLACEMENT."
  (when (and (> (length word) (length suffix)) (string-suffix-p suffix word))
    (let ((candidate (concat (substring word 0 (- (length word) (length suffix))) replacement)))
      (when (and (> (length candidate) 1) (lexdb-ldoce--lookup candidate)) candidate))))

(defun lexdb-ldoce--find-lemma (word)
  "Find base form of WORD."
  (let ((w (downcase word)))
    (if (lexdb-ldoce--lookup w) w
      (or (lexdb-ldoce--try-lemma w "ing" "") (lexdb-ldoce--try-lemma w "ing" "e")
          (lexdb-ldoce--try-lemma w "ning" "n") (lexdb-ldoce--try-lemma w "ting" "t")
          (lexdb-ldoce--try-lemma w "ping" "p") (lexdb-ldoce--try-lemma w "bing" "b")
          (lexdb-ldoce--try-lemma w "ging" "g") (lexdb-ldoce--try-lemma w "ming" "m")
          (lexdb-ldoce--try-lemma w "ding" "d") (lexdb-ldoce--try-lemma w "ed" "")
          (lexdb-ldoce--try-lemma w "ed" "e") (lexdb-ldoce--try-lemma w "ied" "y")
          (lexdb-ldoce--try-lemma w "ned" "n") (lexdb-ldoce--try-lemma w "ted" "t")
          (lexdb-ldoce--try-lemma w "ped" "p") (lexdb-ldoce--try-lemma w "bed" "b")
          (lexdb-ldoce--try-lemma w "ged" "g") (lexdb-ldoce--try-lemma w "med" "m")
          (lexdb-ldoce--try-lemma w "ded" "d") (lexdb-ldoce--try-lemma w "s" "")
          (lexdb-ldoce--try-lemma w "es" "") (lexdb-ldoce--try-lemma w "ies" "y")
          (lexdb-ldoce--try-lemma w "er" "") (lexdb-ldoce--try-lemma w "er" "e")
          (lexdb-ldoce--try-lemma w "ier" "y") (lexdb-ldoce--try-lemma w "est" "")
          (lexdb-ldoce--try-lemma w "est" "e") (lexdb-ldoce--try-lemma w "iest" "y")
          (lexdb-ldoce--try-lemma w "ly" "") (lexdb-ldoce--try-lemma w "ily" "y")
          (lexdb-ldoce--try-lemma w "'s" "") w))))

;;;; ============================================================
;;;; Frequency Rendering
;;;; ============================================================

(defun lexdb-ldoce--render-frequency (freq)
  "Render LDOCE frequency with dots.
FREQ is the S1/W1 etc level text."
  (when (lexdb-ldoce--non-empty-string-p freq)
    (propertize freq 'face 'lexdb-frequency-face)))

;;;; ============================================================
;;;; Registration
;;;; ============================================================

;;;###autoload
(defun lexdb-ldoce-register ()
  "Register LDOCE adapter."
  (interactive)
  (lexdb-register-adapter
   (lexdb-adapter-create
    :id 'ldoce
    :name "Longman Dictionary of Contemporary English"
    :version "6th Edition"
    :capabilities '(lookup definition pronunciation audio-uk audio-us audio-example
                    pos grammar register hyphenation frequency-band
                    examples collocations phrases synonyms cross-refs origin lemmatization)
    :db-file lexdb-ldoce-db-file
    :audio-dir lexdb-ldoce-audio-directory
    :lookup-fn #'lexdb-ldoce--lookup
    :close-fn #'lexdb-ldoce--close
    :collocations-fn #'lexdb-ldoce--get-collocations
    :relations-fn #'lexdb-ldoce--get-relations
    :lemma-fn #'lexdb-ldoce--find-lemma
    :prefetch-fn #'lexdb-ldoce--prefetch
    :render-frequency-fn #'lexdb-ldoce--render-frequency)))

(provide 'lexdb-ldoce)
;;; lexdb-ldoce.el ends here
