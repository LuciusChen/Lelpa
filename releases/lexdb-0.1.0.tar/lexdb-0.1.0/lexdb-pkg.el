;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lexdb" "0.1.0"
  "Multi-dictionary interface for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/example/lexdb"
  :commit "e912d89732600627ce6a33e5cdd686523e6b361b"
  :revdesc "e912d8973260"
  :keywords '("dictionary" "multilingual" "reference"))
