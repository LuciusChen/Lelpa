;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-clutch" "0.1.0"
  "Org-Babel integration for clutch database client."
  '((emacs  "28.1")
    (clutch "0.1"))
  :url "https://github.com/LuciusChen/ob-clutch"
  :commit "31ce987264b4e4101f3e7f110c6fec9b2d8eabd5"
  :revdesc "31ce987264b4"
  :keywords '("languages" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
