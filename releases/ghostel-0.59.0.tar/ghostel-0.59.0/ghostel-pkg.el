;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.59.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b77eae6f58ed1fc9b36694807e84a4bb6dfbf9fd"
  :revdesc "b77eae6f58ed"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
