;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emt" "0.11.0"
  "Han word boundaries via jieba-rs."
  '((emacs "26.1"))
  :url "https://github.com/LuciusChen/emt"
  :commit "e66bc7719340eb82ee78af7301ad9131c8132d57"
  :revdesc "v0.11.0-0-ge66bc7719340"
  :keywords '("chinese" "cjk" "tokenizer" "natural language" "segmentation")
  :authors '(("Roife Wu" . "roifewu@gmail.com")))
