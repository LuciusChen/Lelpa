;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.66.0.0.20261120.6"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7fed0f52355c150d7ef2e14a643acb58da00e807"
  :revdesc "7fed0f52355c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
