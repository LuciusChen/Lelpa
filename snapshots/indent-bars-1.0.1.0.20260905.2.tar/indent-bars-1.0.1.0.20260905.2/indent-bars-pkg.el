;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-bars" "1.0.1.0.20260905.2"
  "Highlight indentation with bars."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/jdtsmith/indent-bars"
  :commit "afc98cb156ef03df4c28968d48790b79e3d1210d"
  :revdesc "afc98cb156ef"
  :keywords '("convenience")
  :authors '(("J.D. Smith" . "jdtsmith+elpa@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
