;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "closql" "2.4.2.0.20261021.1"
  "Store EIEIO objects using EmacSQL."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/closql"
  :commit "5422039720c55b69a762947d926ebdf4f0781c6c"
  :revdesc "v2.4.2-1-g5422039720c5"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")))
