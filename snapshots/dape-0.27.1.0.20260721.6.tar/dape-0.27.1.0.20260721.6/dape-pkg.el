;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260721.6"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "20a26b674b0b264463f2d31fd9e45a81d824c8bd"
  :revdesc "20a26b674b0b"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
