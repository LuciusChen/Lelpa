;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svg-lib" "0.3.0.20250823.14"
  "SVG tags, progress bars & icons."
  '((emacs "27.1"))
  :url "https://github.com/rougier/svg-lib"
  :commit "8bac472446265381f4e1f5e32b8ae2006e24f28a"
  :revdesc "8bac47244626"
  :keywords '("svg" "icons" "tags" "convenience")
  :maintainers '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr")))
