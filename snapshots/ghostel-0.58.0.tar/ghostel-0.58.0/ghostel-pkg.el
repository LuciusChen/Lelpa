;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.58.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d239a3c3b8cd9a7210169bb7dd50c94fccfb95c6"
  :revdesc "d239a3c3b8cd"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
