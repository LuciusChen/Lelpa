;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plz-media-type" "0.2.1.0.20260708.8"
  "Plz Media Types."
  '((emacs "26.3")
    (plz   "0.9.1"))
  :url "https://github.com/r0man/plz-media-type"
  :commit "6902b375de5937fdb23dca981db098ef6540f2f8"
  :revdesc "6902b375de59"
  :keywords '("comm" "network" "http")
  :authors '(("r0man" . "roman@burningswell.com"))
  :maintainers '(("r0man" . "roman@burningswell.com")))
