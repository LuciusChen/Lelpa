;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blame-reveal" "0.5.0.20260818.52"
  "Git blame visualization in fringe."
  '((emacs     "28.1")
    (transient "0.4.0"))
  :url "https://github.com/LuciusChen/blame-reveal"
  :commit "7645a1f49c9b716ab5e0edaabe2f76b328af4ea0"
  :revdesc "7645a1f49c9b"
  :keywords '("git" "vc" "convenience")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
