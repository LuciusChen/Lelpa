;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "queue" "0.2.0.20240716.8"
  "Queue data structure."
  '((cl-lib "0.5"))
  :url "http://www.dr-qubit.org/emacs.php"
  :commit "8df1334d54d4735d2f821790422a850dfaaa08ef"
  :revdesc "8df1334d54d4"
  :keywords '("extensions" "data structures" "queue")
  :authors '(("Inge Wallin" . "inge@lysator.liu.se")
             ("Toby Cubitt" . "toby-predictive@dr-qubit.org"))
  :maintainers '(("Toby Cubitt" . "toby-predictive@dr-qubit.org")))
