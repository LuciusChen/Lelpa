;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e" "1.14.4.0.20261114.23"
  "Mu-based mua for emacs."
  ()
  :url "https://www.djcbsoftware.nl/code/mu/"
  :commit "7ce49e7ce9afea58e57375bbfa1499c1c5f883dd"
  :revdesc "v1.14.4-23-g7ce49e7ce9af"
  :keywords '("email")
  :authors '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl"))
  :maintainers '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl")))
