;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "courier" "0.2.0.0.20260923.34"
  "Curl-backed HTTP client."
  '((emacs     "29.1")
    (transient "0.0.0"))
  :url "https://github.com/LuciusChen/courier"
  :commit "a7fcdb9f944c206c46583bd80108000e317eff1f"
  :revdesc "a7fcdb9f944c"
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
