;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redis" "0.1.1.0.20260925.10"
  "Native Redis RESP client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/redis.el"
  :commit "df5895528dc896e62a175497a05c9d378aefd63e"
  :revdesc "df5895528dc8"
  :keywords '("data" "redis" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
