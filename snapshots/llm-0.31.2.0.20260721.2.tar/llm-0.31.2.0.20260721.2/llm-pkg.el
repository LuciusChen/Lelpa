;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm" "0.31.2.0.20260721.2"
  "Interface to pluggable llm backends."
  '((emacs            "28.1")
    (plz              "0.8")
    (plz-event-source "0.1.1")
    (plz-media-type   "0.2.1")
    (compat           "29.1"))
  :url "https://github.com/ahyatt/llm"
  :commit "7de8fdd0e0c3faac6d8e033974edf9b7960eced1"
  :revdesc "7de8fdd0e0c3"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
