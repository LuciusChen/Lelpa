;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terminal-focus-reporting" "1.0.0.0.20180830.9"
  "Minor mode for terminal focus reporting."
  '((emacs "24.4"))
  :url "https://github.com/veelenga/terminal-focus-reporting.el"
  :commit "8b84bf18f4c5f1b59a11692eb706f13c3598d9a5"
  :revdesc "8b84bf18f4c5"
  :keywords '("convenience"))
