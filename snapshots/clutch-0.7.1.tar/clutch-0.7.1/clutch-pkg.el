;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.7.1"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c222c8f2321a76cc801b213f4810af96d95ac686"
  :revdesc "c222c8f2321a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
