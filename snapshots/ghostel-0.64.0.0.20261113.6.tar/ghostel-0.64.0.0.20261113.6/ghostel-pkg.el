;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.64.0.0.20261113.6"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "75e4bd25ab6f12db8db1e8560c4c1277bc629533"
  :revdesc "75e4bd25ab6f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
