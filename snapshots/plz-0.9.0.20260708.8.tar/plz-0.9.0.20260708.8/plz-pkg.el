;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plz" "0.9.0.20260708.8"
  "HTTP library."
  '((emacs "27.1"))
  :url "https://github.com/alphapapa/plz.el"
  :commit "8f5e5ffbde6da93920035be1489a1f1a9986b879"
  :revdesc "8f5e5ffbde6d"
  :keywords '("comm" "network" "http")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
