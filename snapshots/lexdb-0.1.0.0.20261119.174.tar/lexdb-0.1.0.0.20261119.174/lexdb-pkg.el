;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lexdb" "0.1.0.0.20261119.174"
  "Multi-dictionary lookup interface."
  '((emacs "29.1"))
  :url "https://github.com/example/lexdb"
  :commit "fd5726ea6f4d058ee1acd9b8bf1bf54ba10d5f3a"
  :revdesc "fd5726ea6f4d"
  :keywords '("tools" "convenience"))
