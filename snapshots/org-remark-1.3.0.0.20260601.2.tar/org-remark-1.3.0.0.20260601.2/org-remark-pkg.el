;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-remark" "1.3.0.0.20260601.2"
  "Highlight & annotate text, Info, EPUB, EWW."
  '((emacs "27.1")
    (org   "9.4"))
  :url "https://github.com/nobiot/org-remark"
  :commit "10a2bc3f60b020fb3bc8c0194ac1bf1145432e97"
  :revdesc "10a2bc3f60b0"
  :keywords '("org-mode" "annotation" "note-taking" "marginal-notes" "wp")
  :authors '(("Noboru Ota" . "me@nobiot.com"))
  :maintainers '(("Noboru Ota" . "me@nobiot.com")))
