;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-defuddle" "0.1.4.0.20260723.2"
  "Extract readable web pages into Org."
  '((emacs "27.1"))
  :url "https://github.com/LuciusChen/org-defuddle"
  :commit "7a79aa7ef4e5e4f71a0d160c7345474a14140db4"
  :revdesc "v0.1.4-2-g7a79aa7ef4e5"
  :keywords '("hypermedia" "outlines" "tools"))
