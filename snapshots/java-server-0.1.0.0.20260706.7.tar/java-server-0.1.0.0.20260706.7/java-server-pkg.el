;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "java-server" "0.1.0.0.20260706.7"
  "Java development utilities for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/java-server"
  :commit "69d54bf175d6c9a61470f1636c48700058926a43"
  :revdesc "69d54bf175d6"
  :keywords '("java" "tools" "languages"))
