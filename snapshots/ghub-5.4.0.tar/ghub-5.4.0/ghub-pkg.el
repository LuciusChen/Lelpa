;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "5.4.0"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "0ce466e35af5c1a6d743a6481a9d4e33cd7a40c3"
  :revdesc "v5.4.0-0-g0ce466e35af5"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
