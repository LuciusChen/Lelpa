;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redis" "0.1.1.0.20260716.2"
  "Native Redis RESP client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/redis.el"
  :commit "6c178e4c12e07a652cf387a9fe3f9ee289497177"
  :revdesc "6c178e4c12e0"
  :keywords '("data" "redis" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
