;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.16.0.20261101.3"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "15fed49c97bf6b2436641714ae15bbd2f3e37b77"
  :revdesc "2.16-3-g15fed49c97bf"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
