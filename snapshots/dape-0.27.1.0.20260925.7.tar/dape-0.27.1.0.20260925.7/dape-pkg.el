;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dape" "0.27.1.0.20260925.7"
  "Debug Adapter Protocol for Emacs."
  '((emacs   "29.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/svaante/dape"
  :commit "54b986708f9221621ec25b69ebe9b7604268255d"
  :revdesc "54b986708f92"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
