;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.1.0.0.20261021.23"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "e50ea7a3222020cef8e7f320f9870bb20c61e451"
  :revdesc "1.1.0-23-ge50ea7a32220"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
