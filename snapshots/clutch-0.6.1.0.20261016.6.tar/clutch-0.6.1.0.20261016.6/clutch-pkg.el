;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.6.1.0.20261016.6"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "52f93507083decde82535c3554174f6c88f70e6d"
  :revdesc "52f93507083d"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
