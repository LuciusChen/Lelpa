;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.7.0.0.20261021.37"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "f29ce7a025524046500643ed65c1527b45d5342b"
  :revdesc "f29ce7a02552"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
