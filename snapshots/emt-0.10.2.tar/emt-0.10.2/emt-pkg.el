;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emt" "0.10.2"
  "Han word boundaries via jieba-rs."
  '((emacs "26.1"))
  :url "https://github.com/LuciusChen/emt"
  :commit "f5b018a32cfb627c43b851bfb26a35863e46c8e6"
  :revdesc "v0.10.2-0-gf5b018a32cfb"
  :keywords '("chinese" "cjk" "tokenizer" "natural language" "segmentation")
  :authors '(("Roife Wu" . "roifewu@gmail.com")))
