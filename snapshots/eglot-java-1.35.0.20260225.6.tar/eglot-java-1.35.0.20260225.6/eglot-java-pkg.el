;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-java" "1.35.0.20260225.6"
  "Java extension for the eglot LSP client."
  '((emacs   "26.1")
    (eglot   "1.0")
    (jsonrpc "1.0.0"))
  :url "https://github.com/yveszoundi/eglot-java"
  :commit "918291c991bd3eaf5183ad0befa87e5ede82f3ce"
  :revdesc "918291c991bd"
  :keywords '("convenience" "languages")
  :authors '(("Yves Zoundi and contributors" . "yves_zoundi@hotmail.com"))
  :maintainers '(("Yves Zoundi" . "yves_zoundi@hotmail.com")))
