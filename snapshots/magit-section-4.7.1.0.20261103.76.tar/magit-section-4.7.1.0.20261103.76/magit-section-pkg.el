;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "4.7.1.0.20261103.76"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "f7100cf9fd8fae6ca0576297e3d224e7d1a173d2"
  :revdesc "v4.7.1-76-gf7100cf9fd8f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
