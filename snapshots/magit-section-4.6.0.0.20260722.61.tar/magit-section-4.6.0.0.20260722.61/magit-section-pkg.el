;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "4.6.0.0.20260722.61"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "cbd85091c932e77ef2fcd86e85c3cb1334083724"
  :revdesc "v4.6.0-61-gcbd85091c932"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
