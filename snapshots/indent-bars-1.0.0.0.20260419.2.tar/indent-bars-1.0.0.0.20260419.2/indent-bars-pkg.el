;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-bars" "1.0.0.0.20260419.2"
  "Highlight indentation with bars."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/jdtsmith/indent-bars"
  :commit "a8ff2fad8dde8f7712a6c869f6cd3358385b4548"
  :revdesc "a8ff2fad8dde"
  :keywords '("convenience")
  :authors '(("J.D. Smith" . "jdtsmith+elpa@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
