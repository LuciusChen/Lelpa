;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.1.0.0.20261002.2"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "0c6388bb3b7766a88b11e51a628895aa6253d684"
  :revdesc "1.1.0-2-g0c6388bb3b77"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
