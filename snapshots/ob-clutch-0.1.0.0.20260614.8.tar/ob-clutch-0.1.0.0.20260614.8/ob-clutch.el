;;; ob-clutch.el --- Org-Babel integration for clutch database client -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026 Lucius Chen
;; Author: Lucius Chen <chenyh572@gmail.com>
;; Maintainer: Lucius Chen <chenyh572@gmail.com>
;; Package-Version: 0.1.0.0.20260614.8
;; Package-Revision: 8a04649aa20b
;; Package-Requires: ((emacs "28.1") (clutch "0.1"))
;; Keywords: languages, data
;; URL: https://github.com/LuciusChen/ob-clutch
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This file is part of ob-clutch.

;; ob-clutch is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; ob-clutch is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with ob-clutch.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Org-Babel backend for clutch database connections.
;;
;; Supported block types:
;;   #+begin_src mysql
;;   #+begin_src postgresql
;;   #+begin_src sqlite
;;   #+begin_src mongodb
;;   #+begin_src redis
;;
;; Optional generic block (supports all clutch backends including JDBC):
;;   #+begin_src clutch :backend pg
;;   #+begin_src clutch :backend oracle
;;   #+begin_src clutch :backend sqlserver
;;   #+begin_src clutch :backend mongodb
;;   #+begin_src clutch :backend redis
;;
;; Header arguments:
;;   :connection                name from `clutch-connection-alist'
;;   :backend                   mysql|pg|postgresql|sqlite|mongodb|redis|...
;;   :host :port :user :password :database
;;   :ssh-host :tramp
;;
;; JDBC backends (oracle, sqlserver, db2, snowflake, redshift) require
;; clutch-db-jdbc.el to be loaded and clutch-jdbc-agent.jar to be available.
;; Use :connection to reference a pre-configured clutch-connection-alist entry,
;; or supply :host/:port/:user/:database inline.  Port defaults to the JDBC
;; driver default when omitted.

;;; Code:

(require 'ob)
(require 'cl-lib)
(require 'clutch)
(require 'clutch-backend)

(defvar clutch-connection-alist)

(defgroup ob-clutch nil
  "Org-Babel integration for clutch database backends."
  :group 'org-babel
  :prefix "ob-clutch-")

(defcustom ob-clutch-max-rows nil
  "Default maximum number of data rows returned by `ob-clutch'.
Nil means unlimited.  A source block can override this with the
`:max-rows' header argument."
  :type '(choice (const :tag "Unlimited" nil)
                 (natnum :tag "Rows"))
  :group 'ob-clutch)

(defvar org-babel-default-header-args:clutch '((:results . "table"))
  "Default header arguments for clutch source blocks.")

(defvar org-babel-default-header-args:mysql '((:results . "table"))
  "Default header arguments for mysql source blocks.")

(defvar org-babel-default-header-args:postgresql '((:results . "table"))
  "Default header arguments for postgresql source blocks.")

(defvar org-babel-default-header-args:sqlite '((:results . "table"))
  "Default header arguments for sqlite source blocks.")

(defvar org-babel-default-header-args:mongodb '((:results . "table"))
  "Default header arguments for mongodb source blocks.")

(defvar org-babel-default-header-args:redis '((:results . "table"))
  "Default header arguments for redis source blocks.")

(defconst org-babel-header-args:clutch
  '((connection . :any)
    (backend . :any)
    (host . :any)
    (port . :any)
    (user . :any)
    (password . :any)
    (database . :any)
    (pass-entry . :any)
    (ssh-host . :any)
    (tramp . :any)
    (tramp-default-directory . :any)
    (url . :any)
    (sid . :any)
    (schema . :any)
    (catalog . :any)
    (surface . :any)
    (auth-source . :any)
    (auth-database . :any)
    (auth-mechanism . :any)
    (props . :any)
    (tls . :any)
    (ssl . :any)
    (ssl-mode . :any)
    (sslmode . :any)
    (tls-verify . :any)
    (manual-commit . :any)
    (connect-timeout . :any)
    (read-idle-timeout . :any)
    (query-timeout . :any)
    (rpc-timeout . :any)
    (max-rows . :any))
  "Clutch-specific header arguments for source blocks.")

(defvar ob-clutch--connection-cache (make-hash-table :test 'equal)
  "Cache of live DB connections keyed by backend+connection parameters.")

(defconst ob-clutch--numeric-header-keys
  '(:port :connect-timeout :read-idle-timeout :query-timeout :rpc-timeout)
  "Header arguments that should be coerced to natural numbers.")

(defconst ob-clutch--boolean-header-keys
  '(:tls :manual-commit)
  "Header arguments that should be coerced to booleans.")

(defun ob-clutch--parse-natnum (value key)
  "Return VALUE parsed as a natural number for header KEY."
  (cond
   ((numberp value) value)
   ((and (stringp value)
         (string-match-p "\\`[0-9]+\\'" value))
    (string-to-number value))
   (t
    (user-error "Invalid %s value: %S" key value))))

(defun ob-clutch--parse-boolean (value key)
  "Return VALUE normalized to a boolean for header KEY."
  (cond
   ((memq value '(t yes)) t)
   ((null value) nil)
   ((stringp value)
    (pcase (downcase value)
      ((or "yes" "true" "t") t)
      ((or "no" "false" "nil") nil)
      (_ (user-error "Invalid %s value: %S" key value))))
   (t
    (user-error "Invalid %s value: %S" key value))))

(defun ob-clutch--coerce-header-value (key value)
  "Return Babel header VALUE normalized for connection KEY."
  (cond
   ((memq key ob-clutch--numeric-header-keys)
    (ob-clutch--parse-natnum value key))
   ((memq key ob-clutch--boolean-header-keys)
    (ob-clutch--parse-boolean value key))
   (t value)))

(defun ob-clutch--connection-header-keys ()
  "Return Org header keys that represent Clutch connection params."
  (cl-loop for (name . _type) in org-babel-header-args:clutch
           for key = (intern (concat ":" (symbol-name name)))
           unless (memq key '(:connection :max-rows))
           collect key))

(defun ob-clutch--params-alist-to-plist (params keys)
  "Return Babel PARAMS as a plist containing only KEYS."
  (let (out)
    (dolist (key keys out)
      (when-let* ((entry (assq key params)))
        (setq out
              (append out
                      (list key
                            (ob-clutch--coerce-header-value key (cdr entry)))))))))

(defun ob-clutch--max-rows (params)
  "Return the effective :max-rows limit for Babel PARAMS."
  (let ((value (cdr (assq :max-rows params))))
    (cond
     ((null value) ob-clutch-max-rows)
     ((and (stringp value) (string= (downcase value) "nil")) nil)
     (t (ob-clutch--parse-natnum value :max-rows)))))

(defun ob-clutch--truncate-rows (rows params)
  "Return ROWS truncated according to Babel PARAMS.
When truncation happens, emit a message describing the number of hidden rows."
  (if-let* ((max-rows (ob-clutch--max-rows params)))
      (if (> (length rows) max-rows)
          (progn
            (message "ob-clutch truncated result from %d to %d rows"
                     (length rows) max-rows)
            (cl-subseq rows 0 max-rows))
        rows)
    rows))

(defun ob-clutch--normalize-backend (backend)
  "Normalize BACKEND string or symbol for `clutch-open-connection'.
Alias ownership lives in Clutch's backend registry."
  (clutch-backend-normalize backend))

(defun ob-clutch--inline-params (params backend)
  "Build inline connection params from Babel PARAMS for BACKEND."
  (plist-put
   (ob-clutch--params-alist-to-plist
    params (ob-clutch--connection-header-keys))
   :backend backend))

(defun ob-clutch--resolve-connection (params default-backend)
  "Return a Clutch connection plist from Babel PARAMS.
DEFAULT-BACKEND is used by language-specific executors."
  (if-let* ((conn-name (cdr (assq :connection params))))
      (let* ((plist (or (clutch-saved-connection-params conn-name)
                        (user-error "Unknown connection: %s" conn-name)))
             (backend (ob-clutch--normalize-backend
                       (or (plist-get plist :backend) default-backend 'mysql))))
        (plist-put plist :backend backend))
    (let* ((backend-sym (or (cdr (assq :backend params)) default-backend))
           (backend (or (and backend-sym
                             (ob-clutch--normalize-backend backend-sym))
                        (user-error
                         "Missing :backend for clutch block (or use :connection to reference a saved connection)")))
           (conn-params (ob-clutch--inline-params params backend)))
      (when-let* ((pass-entry (cdr (assq :pass-entry params))))
        (setq conn-params (plist-put conn-params :pass-entry pass-entry)))
      (plist-put conn-params :backend backend))))

(defun ob-clutch--connect (params default-backend)
  "Get or create a cached `clutch-db' connection for PARAMS using DEFAULT-BACKEND."
  (let* ((conn-params (ob-clutch--resolve-connection params default-backend))
         (source-origin (file-remote-p default-directory))
         (key (format "%S:%S" conn-params source-origin))
         (cached (gethash key ob-clutch--connection-cache)))
    (if (and cached (clutch-db-live-p cached))
        cached
      (let* ((prepared-params
              (clutch-prepare-connection-params conn-params default-directory))
             (conn (clutch-open-connection prepared-params)))
        (puthash key conn ob-clutch--connection-cache)
        conn))))

(defun ob-clutch--format-value (val)
  "Format VAL for Org-Babel table output."
  (cond
   ((null val) "NULL")
   ((numberp val) val)           ; raw number for Org column alignment
   ((stringp val) val)
   ((listp val) (or (clutch-db-format-temporal val) (format "%S" val)))
   (t (format "%S" val))))

(defun ob-clutch--execute (body params default-backend)
  "Execute BODY with Babel PARAMS using DEFAULT-BACKEND."
  (let* ((conn (ob-clutch--connect params default-backend))
         (sql (org-babel-expand-body:generic body params))
         (result (clutch-db-query conn sql))
         (columns (clutch-db-result-columns result))
         (rows (ob-clutch--truncate-rows (clutch-db-result-rows result) params)))
    (if columns
        (let ((col-names (mapcar (lambda (c)
                                   (let ((name (plist-get c :name)))
                                     (if (stringp name) name (format "%s" name))))
                                 columns))
              (data (mapcar (lambda (row)
                              (mapcar #'ob-clutch--format-value row))
                            rows)))
          (cons col-names (cons 'hline data)))
      (format "Affected rows: %s"
              (or (clutch-db-result-affected-rows result) 0)))))

(defun org-babel-execute:clutch (body params)
  "Execute a generic clutch BODY with Babel PARAMS."
  (ob-clutch--execute body params
                      (cdr (assq :backend params))))

(defun org-babel-execute:mysql (body params)
  "Execute a MySQL BODY with Babel PARAMS."
  (ob-clutch--execute body params 'mysql))

(defun org-babel-execute:postgresql (body params)
  "Execute a PostgreSQL BODY with Babel PARAMS."
  (ob-clutch--execute body params 'pg))

(defun org-babel-execute:sqlite (body params)
  "Execute a SQLite BODY with Babel PARAMS."
  (ob-clutch--execute body params 'sqlite))

(defun org-babel-execute:mongodb (body params)
  "Execute a MongoDB BODY with Babel PARAMS."
  (ob-clutch--execute body params 'mongodb))

(defun org-babel-execute:redis (body params)
  "Execute a Redis BODY with Babel PARAMS."
  (ob-clutch--execute body params 'redis))

;;;; Cleanup on exit

(defun ob-clutch--disconnect-all ()
  "Disconnect all cached ob-clutch connections and clear the cache."
  (maphash (lambda (_key conn)
             (condition-case nil
                 (clutch-db-disconnect conn)
               (error nil)))
           ob-clutch--connection-cache)
  (clrhash ob-clutch--connection-cache))

(add-hook 'kill-emacs-hook #'ob-clutch--disconnect-all)

(provide 'ob-clutch)
;;; ob-clutch.el ends here
