;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-clutch" "0.1.0.0.20260614.8"
  "Org-Babel integration for clutch database client."
  '((emacs  "28.1")
    (clutch "0.1"))
  :url "https://github.com/LuciusChen/ob-clutch"
  :commit "8a04649aa20b0de517ad7db2aa27fe165c5bffec"
  :revdesc "8a04649aa20b"
  :keywords '("languages" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
