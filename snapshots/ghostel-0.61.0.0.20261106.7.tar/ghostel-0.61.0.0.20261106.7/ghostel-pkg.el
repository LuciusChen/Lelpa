;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.61.0.0.20261106.7"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3f3631e83f4a35243dfd25e1a8e6a542c4097691"
  :revdesc "3f3631e83f4a"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
