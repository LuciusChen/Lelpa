;;; meow-cjk.el --- Han word segmentation support for Meow  -*- lexical-binding: t; -*-

;; Copyright (C) 2024

;; Author: Lucius Chen <chenyh572@gmail.com>
;; URL: https://github.com/LuciusChen/meow-cjk
;; Package-Version: 0.1.0.0.20260429.8
;; Package-Revision: 10a31434232f
;; Package-Requires: ((emacs "27.1") (meow "1.5.0") (emt "0.1.2"))
;; Keywords: chinese, cjk, convenience, meow

;; This file is NOT a part of GNU Emacs.

;; This file is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; For a full copy of the GNU General Public License
;; see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; This package provides Han word segmentation support for Meow modal editing.
;; It uses the EMT backend, which is backed by jieba-rs.
;;
;; Usage:
;;
;;   (require 'meow-cjk)
;;   (meow-cjk-mode 1)
;;
;; Or with use-package:
;;
;;   (use-package meow-cjk
;;     :after meow
;;     :config
;;     (meow-cjk-mode 1))

;;; Code:

(require 'cl-lib)
(require 'subr-x)
(require 'meow)
(require 'emt)

;;; Customization

(defgroup meow-cjk nil
  "Han word segmentation support for Meow."
  :group 'meow
  :prefix "meow-cjk-")

(defcustom meow-cjk-backend 'emt
  "Backend for Han word segmentation.
Available backends:
  - `emt': EMT backend powered by jieba-rs.  Requires the EMT package."
  :type '(choice (const :tag "EMT (jieba-rs)" emt))
  :group 'meow-cjk)

;;; Helper functions

(defun meow-cjk--select-noncjk (thing type backward regexp-format)
  "Select non-Han text based on THING, TYPE, and BACKWARD direction.
REGEXP-FORMAT is used to format the search regexp."
  (when-let* ((bounds (bounds-of-thing-at-point thing))
              (beg (car bounds))
              (end (cdr bounds)))
    (thread-first
      (meow--make-selection (cons 'expand type) beg end)
      (meow--select t backward))
    (when (stringp regexp-format)
      (let ((search (format regexp-format (regexp-quote (buffer-substring-no-properties beg end)))))
        (meow--push-search search)
        (meow--highlight-regexp-in-buffer search)))))

(defun meow-cjk--select-cjk (direction backward)
  "Select Han text based on DIRECTION and BACKWARD direction."
  (when-let* ((bounds (if (eq direction 'backward)
                          (emt-bounds-at-point-or-backward)
                        (emt-bounds-at-point-or-forward)))
              (beg (car bounds))
              (end (cdr bounds))
              (regexp (regexp-quote (buffer-substring-no-properties beg end))))
    (meow--select
     (meow--make-selection (cons 'expand 'word) beg end)
     t backward)
    (meow--push-search regexp)
    (meow--highlight-regexp-in-buffer regexp)))

(defun meow-cjk--forward-thing-1 (thing)
  "Move forward one THING, with CJK support."
  (let ((pos (point)))
    (if (eq thing 'word)
        (emt-forward-word 1)
      (forward-thing thing 1))
    (unless (= pos (point))
      (meow--hack-cursor-pos (point)))))

(defun meow-cjk--backward-thing-1 (thing)
  "Move backward one THING, with CJK support."
  (let ((pos (point)))
    (if (eq thing 'word)
        (emt-backward-word 1)
      (forward-thing thing -1))
    (unless (= pos (point))
      (point))))

;;; Public API

;;;###autoload
(defun meow-cjk-mark-thing (thing type &optional backward regexp-format)
  "Make expandable selection of THING, with TYPE and forward/BACKWARD direction.

THING is a symbol usable by `forward-thing', which see.

TYPE is a symbol. Usual values are `word' or `line'.

The selection will be made in the \\='forward\\=' direction unless BACKWARD is
non-nil.

When REGEXP-FORMAT is non-nil and a string, the content of the selection will be
quoted to regexp, then pushed into `regexp-search-ring' which will be read by
`meow-search' and other commands. In this case, REGEXP-FORMAT is used as a
format-string to format the regexp-quoted selection content (which is passed as
a string to `format'). Further matches of this formatted search will be
highlighted in the buffer."
  (interactive "p")
  (let ((direction (if backward 'backward 'forward)))
    (if (or (eq type 'symbol) (not (looking-at-p "\\cc")))
        (meow-cjk--select-noncjk thing type backward regexp-format)
      (emt-ensure)
      (meow-cjk--select-cjk direction backward))))

;;;###autoload
(defun meow-cjk-next-thing (thing type n &optional include-syntax)
  "Create non-expandable selection of TYPE to the end of the next Nth THING.

If N is negative, select to the beginning of the previous Nth thing instead.
INCLUDE-SYNTAX specifies additional syntax to include in the selection."
  (unless (equal type (cdr (meow--selection-type)))
    (meow--cancel-selection))
  (unless include-syntax
    (setq include-syntax
          (let ((thing-include-syntax
                 (or (alist-get thing meow-next-thing-include-syntax)
                     '("" ""))))
            (if (> n 0)
                (car thing-include-syntax)
              (cadr thing-include-syntax)))))
  (let* ((expand (equal (cons 'expand type) (meow--selection-type)))
         (_ (when expand
              (if (< n 0) (meow--direction-backward)
                (meow--direction-forward))))
         (new-type (if expand (cons 'expand type) (cons 'select type)))
         (m (point))
         (p (save-mark-and-excursion
              (if (eq thing 'word)
                  (progn
                    (emt-ensure)
                    (if (> n 0)
                        (emt-forward-word n)
                      (emt-backward-word (- n))))
                (forward-thing thing n))
              (unless (= (point) m)
                (point)))))
    (when p
      (thread-first
        (meow--make-selection
         new-type
         (meow--fix-thing-selection-mark thing p m include-syntax)
         p
         expand)
        (meow--select t))
      (meow--maybe-highlight-num-positions
       (cons (apply-partially #'meow-cjk--backward-thing-1 thing)
             (apply-partially #'meow-cjk--forward-thing-1 thing))))))

;;; Minor mode

;;;###autoload
(define-minor-mode meow-cjk-mode
  "Minor mode for CJK word segmentation support in Meow."
  :global t
  :lighter " MeowCJK"
  (if meow-cjk-mode
      (progn
        (advice-add 'meow-mark-thing :override #'meow-cjk-mark-thing)
        (advice-add 'meow-next-thing :override #'meow-cjk-next-thing))
    (advice-remove 'meow-mark-thing #'meow-cjk-mark-thing)
    (advice-remove 'meow-next-thing #'meow-cjk-next-thing)))

(provide 'meow-cjk)

;;; meow-cjk.el ends here
