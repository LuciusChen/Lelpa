;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.59.0.0.20261022.3"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "706be5d877f7372adf725eb24b087ac5006b5428"
  :revdesc "706be5d877f7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
