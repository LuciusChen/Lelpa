;;; mu4e-view.el --- Mode for viewing e-mail messages -*- lexical-binding: t -*-

;; Copyright (C) 2021-2026 Dirk-Jan C. Binnema

;; Author: Dirk-Jan C. Binnema <djcb@djcbsoftware.nl>
;; Maintainer: Dirk-Jan C. Binnema <djcb@djcbsoftware.nl>

;; This file is not part of GNU Emacs.

;; mu4e is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; mu4e is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with mu4e.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; In this file we define mu4e-view-mode (+ helper functions), which is used for
;; viewing e-mail messages

;;; Code:

(require 'cl-lib)
(require 'calendar)
(require 'gnus-art)
(require 'comint)
(require 'browse-url)
(require 'button)
(require 'epa)
(require 'epg)
(require 'thingatpt)
(require 'shr)

(require 'mu4e-actions)
(require 'mu4e-compose)
(require 'mu4e-context)
(require 'mu4e-headers)
(require 'mu4e-mark)
(require 'mu4e-message)
(require 'mu4e-server)
(require 'mu4e-search)
(require 'mu4e-mime-parts)
(require 'mu4e-view-html)
(require 'mu4e-view-xwidget)

;; utility functions
(require 'mu4e-contacts)
(require 'mu4e-vars)

;;; Options

(defcustom mu4e-view-scroll-to-next t
  "Move to the next message with `mu4e-view-scroll-up-or-next'.
When at the end of a message, move to the next one, if any.
Otherwise, don't move to the next message."
  :type 'boolean
  :group 'mu4e-view)

(defcustom mu4e-view-fields
  '(:from :to :cc :subject :flags :date
          :maildir :mailing-list :tags :labels)
  "Mu4e header fields to display in the message view buffer.

For the complete list of available headers, see
`mu4e-header-info'.

In addition to the mu4e fields, Gnus _also_ can show fields; See
`gnus-visible-headers' and `gnus-ignored-headers'. A special case
is the Attachments: header: see
`gnus-mime-display-attachment-buttons-in-header', and
`gnus-mime-button-line-format' for tweaking the appearance."
  :type `(repeat (choice
                  ,@(mapcar (lambda (h)
                              (list 'const :tag
                                    (plist-get (cdr h) :help)
                                    (car h)))
                            mu4e-header-info)
                  (restricted-sexp
                   :tag "User-specified header"
                   :match-alternatives (mu4e--valid-header-p))))
  :group 'mu4e-view)

(defcustom mu4e-view-actions
  (delq nil `(;; capture a message for attaching later using
              ;;   `mu4e-compose-attach-captured-message'
              ("capture message"       . mu4e-action-capture-message)
              ;; view message in configure browser
              ("view in browser"       . mu4e-action-view-in-browser)
              ;; view mailing archive for current message
              ("browse online archive" . mu4e-action-browse-list-archive)
              ,(when (mu4e-xwidget-usable-p 'ignore-display)
                 ;; view in xwidget, if usable
                 '("xview in xwidget"  . mu4e-action-view-in-xwidget))
              ;; query for the thread this message is part of
              ("show this thread"      . mu4e-action-show-thread)))
  "List of actions to perform on messages in view mode.
The actions are cons-cells of the form:
  (NAME . FUNC)
where:
* NAME is the name of the action (e.g. \"Count lines\")
* FUNC is a function which receives a message plist as an argument.

The first letter of NAME is used as a shortcut character."
  :group 'mu4e-view
  :type '(alist :key-type string :value-type function))

(defcustom mu4e-view-max-specpdl-size 4096
  "The value of `max-specpdl-size' for displaying messages with Gnus."
  :type 'integer
  :group 'mu4e-view)

(defcustom mu4e-view-html-renderer 'shr
  "How to render HTML messages; a symbol, one of:
  - `shr': use the shr renderer.
  - `xwidget': use an embedded WebKit widget (requires Emacs with
    xwidget support). HTML messages are then shown this way when
    opening them; `mu4e-view-toggle-html' switches to the text view
    and back."
  :type '(choice (const :tag "shr" shr)
                 (const :tag "xwidget" xwidget))
  :group 'mu4e-view)

(defcustom mu4e-view-prefer-plain-text nil
  "Whether to prefer the plain-text version of a message.

If non-nil, show the plain-text part of messages that have both a
plain-text and an HTML alternative, for all renderers (see
`mu4e-view-html-renderer')."
  :type 'boolean
  :group 'mu4e-view)

(defconst mu4e--view-raw-buffer-name " *mu4e-raw-view*"
  "Name for the raw message view buffer.")

(defun mu4e-view-raw-message ()
  "Display the raw contents of message at point in a new buffer."
  (interactive)
  (let ((path (mu4e-message-readable-path))
        (buf (get-buffer-create mu4e--view-raw-buffer-name)))
    (with-current-buffer buf
      (let ((inhibit-read-only t))
        (erase-buffer)
        (mu4e-raw-view-mode)
        (insert-file-contents path)
        (goto-char (point-min))))
    (mu4e-display-buffer buf t)))

(defun mu4e-view-pipe (cmd)
  "Pipe the message at point through shell command CMD.
Then, display the results."
  (interactive "sShell command: ")
  (let ((path (mu4e-message-readable-path)))
    (mu4e-process-file-through-pipe path cmd)))

(defun mu4e--view-prev-or-next (func backwards)
  "Move point to the next or previous message and invoke FUNC.
Go to the previous message if BACKWARDS is non-nil. If this
succeeds, return the new docid. Otherwise, return nil."
  (funcall func backwards)
  (mu4e-select-other-view)
  (mu4e-headers-view-message))

(defun mu4e-view-headers-prev-unread ()
  "Move point to the previous unread message header.
If this succeeds, return the new docid. Otherwise, return nil."
  (interactive)
  (mu4e--view-prev-or-next #'mu4e~headers-prev-or-next-unread t))

(defun mu4e-view-headers-next-unread ()
  "Move point to the next unread message header.
If this succeeds, return the new docid. Otherwise, return nil."
  (interactive)
  (mu4e--view-prev-or-next #'mu4e~headers-prev-or-next-unread nil))

(defun mu4e-view-headers-prev-thread()
  "Move point to the previous thread.
If this succeeds, return the new docid. Otherwise, return nil."
  (interactive)
  (mu4e--view-prev-or-next #'mu4e~headers-prev-or-next-thread t))

(defun mu4e-view-headers-next-thread()
  "Move point to the previous thread.
If this succeeds, return the new docid. Otherwise, return nil."
  (interactive)
  (mu4e--view-prev-or-next #'mu4e~headers-prev-or-next-thread nil))

;;; Interactive functions
(defun mu4e-view-action (&optional msg)
  "Ask user for some action to apply on MSG, then do it.
If MSG is nil apply action to message returned by
`mu4e-message-at-point'.

 The actions are specified in `mu4e-view-actions'."
  (interactive)
  (let* ((msg (or msg (mu4e-message-at-point)))
         (actionfunc (mu4e-read-option "Action: " mu4e-view-actions)))
    (funcall actionfunc msg)))

(defun mu4e-mark-region-code ()
  "Highlight region marked with `message-mark-inserted-region'.
Add this function to `mu4e-view-mode-hook' to enable this feature."
  (require 'message)
  (let (beg end ov-beg ov-end ov-inv)
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward
              (concat "^" message-mark-insert-begin) nil t)
        (setq ov-beg (match-beginning 0)
              ov-end (match-end 0)
              ov-inv (make-overlay ov-beg ov-end)
              beg    ov-end)
        (overlay-put ov-inv 'invisible t)
        (overlay-put ov-inv 'mu4e-overlay t)
        (when (re-search-forward
               (concat "^" message-mark-insert-end) nil t)
          (setq ov-beg (match-beginning 0)
                ov-end (match-end 0)
                ov-inv (make-overlay ov-beg ov-end)
                end    ov-beg)
          (overlay-put ov-inv 'invisible t))
        (when (and beg end)
          (let ((ov (make-overlay beg end)))
            (overlay-put ov 'mu4e-overlay t)
            (overlay-put ov 'face 'mu4e-region-code))
          (setq beg nil end nil))))))

;;; View Utilities
(defun mu4e--view-split-view-p ()
  "Return t if we're in split-view, nil otherwise."
  (member mu4e-split-view '(horizontal vertical)))

(defun mu4e-view-detach ()
  "Detach the view buffer from its headers buffer."
  (interactive)
  (unless mu4e-linked-headers-buffer
    (mu4e-error "This view buffer is already detached"))
  (mu4e-message "Detached view buffer from %s"
                (progn mu4e-linked-headers-buffer
                  (with-current-buffer mu4e-linked-headers-buffer
                    (when (eq (selected-window) mu4e~headers-view-win)
                      (setq mu4e~headers-view-win nil)))
                  (setq mu4e-linked-headers-buffer nil)
                  ;; automatically rename mu4e-view-article buffer when
                  ;; detaching; will get renamed back when reattaching
                  (rename-buffer (make-temp-name (buffer-name)) t))))

(defun mu4e-view-attach (headers-buffer)
  "Attaches a view buffer to HEADERS-BUFFER."
  (interactive
   (list (get-buffer (read-buffer
                      "Select a headers buffer to attach to: " nil t
                      (lambda (buf) (with-current-buffer (car buf)
                                 (mu4e-current-buffer-type-p 'headers)))))))
  (mu4e-message "Attached view buffer to %s" headers-buffer)
  (setq mu4e-linked-headers-buffer headers-buffer)
  (with-current-buffer headers-buffer
    (setq mu4e~headers-view-win (selected-window))))

;;; Scroll commands

(defun mu4e-view-scroll-up-or-next ()
  "Scroll-up the current message.
If `mu4e-view-scroll-to-next' is non-nil, and we cannot scroll up
any further, go the next message."
  (interactive)
  (condition-case nil
      (scroll-up)
    (error
     (when mu4e-view-scroll-to-next
       (mu4e-headers-next)))))

(defun mu4e-scroll-up ()
  "Scroll text of selected window up one line."
  (interactive)
  (scroll-up 1))

(defun mu4e-scroll-down ()
  "Scroll text of selected window down one line."
  (interactive)
  (scroll-down 1))

(defun mu4e-view-message-with-message-id (msgid)
  "View message with message-id MSGID.
This (re)creates a
headers-buffer with a search for MSGID, then open a view for that
message."
  (mu4e-search (concat "msgid:" msgid) nil nil t msgid t))

;;; Variables

(defvar gnus-icalendar-additional-identities)
(defvar-local mu4e--view-rendering nil)

(defvar mu4e--view-show-mime-buttons nil
  "Whether to show MIME part buttons (e.g. \"[1. text/html]\").
Toggle with `mu4e-view-toggle-mime-buttons'.")

(defvar mu4e--view-show-all-mime-parts nil
  "Whether to display all MIME-parts.
Toggle with `mu4e-view-show-mime-parts'.")

(defun mu4e--original-article-field (field)
  "Get FIELD from the original article."
  (when (bufferp gnus-original-article-buffer)
    (with-current-buffer gnus-original-article-buffer
      (gnus-fetch-field field))))

(defun mu4e-view (msg)
  "Display the message MSG in a new buffer, and keep in sync with HDRSBUF.
\"In sync\" here means that moving to the next/previous message
in the message view affects HDRSBUF, as does marking etc.

As a side-effect, a message that is being viewed loses its
`unread' marking if it still had that."
  (cl-assert (member mu4e-view-html-renderer '(shr xwidget))) ;; sanity-check
  ;; update headers, if necessary.
  (mu4e~headers-update-handler msg nil nil)
  ;; Create a new view buffer (if needed) as it is not feasible to recycle an
  ;; existing buffer due to buffer-specific state (buttons, etc.) that can
  ;; interfere with message rendering in gnus.
  ;;
  ;; Unfortunately that does create its own issues: namely ensuring buffer-local
  ;; state that *must* survive is correctly copied across.
  (let ((linked-headers-buffer))
    (when-let* ((existing-buffer (mu4e-get-view-buffer nil nil)))
      ;; required; this state must migrate from the killed buffer to the new
      ;; one.
      (setq linked-headers-buffer mu4e-linked-headers-buffer)
      (when (memq mu4e-split-view '(horizontal vertical))
        (delete-windows-on existing-buffer t)
        ;; The window may actually be showing EXISTING-BUFFER's xwidget
        ;; "shadow" buffer rather than EXISTING-BUFFER itself,
        ;; attempt to delete that one as well.
        (when-let* ((xw (buffer-local-value 'mu4e--view-xwidget-buffer
                                            existing-buffer))
                    ((buffer-live-p xw)))
          (delete-windows-on xw t)))
      (kill-buffer existing-buffer))

    ;; HACK: we create a *Summary* buffer, since its mere existence
    ;; is enough for some gnus commands / functions to work in
    ;; in the mu4e view as well.
    (get-buffer-create (or gnus-summary-buffer "*Summary*"))

    (setq gnus-article-buffer (mu4e-get-view-buffer nil t))
    (with-current-buffer gnus-article-buffer
      (when linked-headers-buffer
        (setq mu4e-linked-headers-buffer linked-headers-buffer))
      (let ((inhibit-read-only t)
            (gnus-unbuttonized-mime-types '(".*/.*"))
            (gnus-buttonized-mime-types
             (append (list "multipart/signed" "multipart/encrypted"
                           "multipart/alternative")
                     gnus-buttonized-mime-types))
            (gnus-inhibit-mime-unbuttonizing mu4e--view-show-mime-buttons)
            (gnus-mime-display-multipart-as-mixed
             mu4e--view-show-all-mime-parts))
        (erase-buffer)
        (insert-file-contents-literally
         (mu4e-message-readable-path msg) nil nil nil t)
        (setq-local mu4e--view-message msg)
        (ignore-errors
          (if (mu4e--view-use-xwidget-p)
              (mu4e--view-render-buffer-xwidget msg)
            (mu4e--view-render-buffer msg))))
      (mu4e-loading-mode 0))
    (unless (mu4e--view-detached-p gnus-article-buffer)
      (with-current-buffer mu4e-linked-headers-buffer
        ;; We need this here as we want to avoid displaying the buffer until
        ;; the last possible moment --- after the message is rendered in the
        ;; view buffer.
        ;;
        ;; Otherwise, `mu4e-display-buffer' may adjust the view buffer's
        ;; window height based on a buffer that has no text in it yet!
        (setq-local mu4e~headers-view-win
                    (mu4e-display-buffer gnus-article-buffer nil))
        (unless (window-live-p mu4e~headers-view-win)
          (mu4e-error "Cannot get a message view"))
        (select-window mu4e~headers-view-win)))
    (with-current-buffer gnus-article-buffer
      (let ((inhibit-read-only t))
        (run-hooks 'mu4e-view-rendered-hook))
      ;; support bookmarks.
      (setq-local bookmark-make-record-function
                  #'mu4e--make-bookmark-record
                  gnus-original-article
                  (get-buffer gnus-original-article-buffer))
      ;; only needed on some setups; #2683
      (goto-char (point-min)))))

(defun mu4e--view-cleanup-message-text ()
  "Clean up the rendered message for use as cited text in replies.

In particular, strip Gnus MIME-part buttons (e.g. attachment
lines like \"[2. foo.pdf --- application/pdf; foo.pdf]\") so
they do not end up in cited replies.

This expects to be called while in that message buffer."
  (let ((pos (point-min)) start)
    (while (setq start (text-property-any
                        pos (point-max)
                        ;; filter out gnus-mm-display-part, not
                        ;; _all_ buttons (#2922)
                        'gnus-callback 'gnus-mm-display-part))
      (let* ((end (or (next-single-property-change
                       start 'gnus-callback nil (point-max))
                      (point-max)))
             (bol (save-excursion (goto-char start)
                                  (line-beginning-position)))
             (eol (save-excursion (goto-char end)
                                  (min (point-max)
                                       (1+ (line-end-position))))))
        (delete-region bol eol)
        (setq pos bol)))))

(defun mu4e-view-message-text (msg)
  "Return the rendered MSG as a string."
  (with-temp-buffer
    (insert-file-contents-literally
     (mu4e-message-readable-path msg) nil nil nil t)
    (let ((gnus-inhibit-mime-unbuttonizing nil)
          (gnus-unbuttonized-mime-types '(".*/.*"))
          (mu4e-view-fields '(:from :to :cc :subject :date)))
      (mu4e--view-render-buffer msg)
      (mu4e--view-cleanup-message-text)
      (buffer-substring-no-properties (point-min) (point-max)))))

(defun mu4e--view-browse-html-string (html)
  "Save HTML to a temporary file and open it with `browse-url'."
  (browse-url (concat "file://" (mu4e--view-html-temp-file html))))

(defun mu4e-action-view-in-browser (msg &optional skip-headers)
  "Show current MSG in a browser.
Use the message's HTML-part if it has one; otherwise, concoct an
HTML version from its text-part.

If SKIP-HEADERS is set, do not include the message headers;
otherwise, they are as per `mu4e-view-fields'.

The variables `browse-url-browser-function',
`browse-url-handlers', and `browse-url-default-handlers'
determine which browser function to use."
  (mu4e--view-browse-html-string
   (or (mu4e-view-html-text msg (unless skip-headers
                                  (mu4e--view-html-insert-headers msg)))
       (mu4e-warn "No html or text part in this message"))))

(defun mu4e-action-view-in-xwidget (_msg)
  "Show the current message in an embedded xwidget, if available.
This works regardless of `mu4e-view-html-renderer', and is the same
as when that is `xwidget' (including that JavaScript is disabled).
Press h in the xwidget to go back to the text view.

This must be invoked from the message view, and shows its message;
the argument is ignored."
  (unless (mu4e-xwidget-usable-p)
    (mu4e-warn "Cannot show message in xwidget"))
  (unless (mu4e--view-xwidget-shown-p)
    (mu4e--view-xwidget-toggle)))

(defun mu4e--view-html-displayed-p ()
  "Is any text/html MIME part currently displayed?
Uses the MIME handle alist populated by Gnus after rendering."
  (seq-find (lambda (handle)
              (and (equal (mm-handle-media-type (cdr handle)) "text/html")
                   (mm-handle-displayed-p (cdr handle))))
            gnus-article-mime-handle-alist))

(defun mu4e--view-render-buffer (msg)
  "Render current buffer with MSG using Gnus' article mode.
The buffer must already contain the raw message. This function
decodes and displays it, sets up the original-article-buffer, and
activates URLs (in plain-text mode only)."
  (let* ((inhibit-read-only t)
         ;; Let gnus-summary-buffer be nil; all gnus-art.el code
         ;; guards its usage with `gnus-buffer-live-p' or
         ;; `condition-case', so nil is safe and avoids the need
         ;; for a fake summary buffer.
         (gnus-summary-buffer nil)
         (gnus-article-buffer (current-buffer))
         (max-specpdl-size mu4e-view-max-specpdl-size)
         (mm-decrypt-option 'known)
         (ct (mail-fetch-field "Content-Type"))
         (ct (and ct (mail-header-parse-content-type ct)))
         (charset (mail-content-type-get ct 'charset))
         (charset (and charset (intern charset)))
         (mu4e--view-rendering t) ;; needed if e.g. an ics file is buttonized
         (gnus-article-emulate-mime nil) ;; avoid perf problems
         (mm-discouraged-alternatives (mu4e--view-discouraged-alternatives))
         (gnus-newsgroup-charset
          (if (and charset (coding-system-p charset)) charset
            (detect-coding-region (point-min) (point-max) t)))
         ;; Possibly add headers (before "Attachments")
         (gnus-display-mime-function (mu4e--view-gnus-display-mime msg)))
    ;; Populate gnus-original-article-buffer with the headers so
    ;; Gnus helpers (e.g. mailing-list detection) can find them.
    (message-narrow-to-headers-or-head)
    (let ((headers (buffer-string)))
      (widen)
      (with-current-buffer
          (get-buffer-create gnus-original-article-buffer 'no-hooks)
        (erase-buffer)
        (insert headers)))
    ;; Strip ^M that can cause rendering problems (#2260, #2508).
    (article-remove-cr)
    (condition-case err
        (progn
          (mm-enable-multibyte)
          ;; just continue if some of the decoding fails.
          (ignore-errors (run-hooks 'gnus-article-decode-hook))
          (gnus-article-prepare-display)
          (mu4e--view-add-mime-icons)
          ;; Only activate URLs in plain-text mode; in HTML mode
          ;; the renderer already provides its own clickable links
          ;; (#2094), so only collect them.
          (mu4e--view-linkify-buffer-text (mu4e--view-html-displayed-p))
          (kill-local-variable 'bookmark-make-record-function)
          (setq mu4e--view-gnus-article-mime-handles gnus-article-mime-handles
                gnus-article-decoded-p gnus-article-decode-hook)
          (set-buffer-modified-p nil)
          (add-hook 'kill-buffer-hook #'mu4e--view-buffer-cleanup nil t))
      (epg-error
       (mu4e-message "EPG error: %s; fall back to raw view"
                     (error-message-string err))))))

(defun mu4e-view-refresh ()
  "Refresh the message view."
  ;;; XXX: sometimes, side-effect: increase the header-buffers size
  (interactive)
  (when-let* ((msg (and (derived-mode-p 'mu4e-view-mode)
                       mu4e--view-message)))
    (mu4e-view-quit)
    (mu4e-view msg)))

(defun mu4e-view-show-mime-parts()
  "Toggle display of all MIME-parts.

Showing all parts can be useful for messages with embedded images
etc. that you want to save, and that are not accessible otherwise.
However, note that Emacs can get slow with big attached images."
  (interactive)
  (setq mu4e--view-show-all-mime-parts
        (not mu4e--view-show-all-mime-parts))
  (mu4e-view-refresh)
  (mu4e-message "All MIME parts %s"
                (if mu4e--view-show-all-mime-parts "shown" "hidden")))

(defun mu4e-view-toggle-mime-buttons ()
  "Toggle display of MIME part buttons and re-render."
  (interactive)
  (setq mu4e--view-show-mime-buttons
        (not mu4e--view-show-mime-buttons))
  (mu4e-view-refresh)
  (mu4e-message "MIME part buttons %s"
                (if mu4e--view-show-mime-buttons "shown" "hidden")))

(defun mu4e-view-toggle-fill-flowed()
  "Toggle flowed-message text filling."
  (interactive)
  (setq mm-fill-flowed (not mm-fill-flowed))
  (mu4e-view-refresh))

(defun mu4e-view-toggle-hide-citation ()
  "Toggle hiding of cited text in the message body.
Like `gnus-article-hide-citation', but keep point in place; if
point is inside cited text that gets hidden, move it just before
the hidden text."
  (interactive)
  (save-excursion (gnus-article-hide-citation))
  (when (get-char-property (point) 'invisible)
    (goto-char (or (previous-single-char-property-change
                    (point) 'invisible)
                   (point-min)))))

(defun mu4e-view-toggle-emulate-mime()
  "Toggle GNUs MIME-emulation.
Note that for some messages, this can trigger high CPU load."
  (interactive)
  (setq gnus-article-emulate-mime (not gnus-article-emulate-mime))
  (mu4e-view-refresh))

(defconst mu4e--view-standard-fields
  '(:bcc :cc :date :from :from-or-to :subject :to :user-agent)
  "Fields that are also normal RFC-822 message headers.
When rendering a message with Gnus, these are rendered by Gnus
itself rather than by mu4e.")

(defun mu4e--view-header-info (field)
  "Return the information about header FIELD.
Look in both `mu4e-header-info' and `mu4e-header-info-custom'."
  (or (alist-get field mu4e-header-info)
      (alist-get field mu4e-header-info-custom)))

(defun mu4e--view-header-name (field)
  "Return the display name for header FIELD."
  (or (plist-get (mu4e--view-header-info field) :name)
      ;; Fallback for fields not in `mu4e-header-info' (e.g.
      ;; :user-agent): derive from the keyword name.
      (capitalize (substring (symbol-name field) 1))))

(defun mu4e--view-header-value-custom (msg field)
  "Return MSG's value for the custom header FIELD."
  (let* ((info (or (alist-get field mu4e-header-info-custom)
                   (mu4e-error "Custom field %S not found" field)))
         (func (or (plist-get info :function)
                   (mu4e-error "No :function defined for custom field %S %S"
                               field info))))
    (funcall func msg)))

(defun mu4e--view-header-value (msg field)
  "Return MSG's value for header FIELD as a string, or nil."
  (let ((fieldval (mu4e-message-field msg field)))
    (pcase field
      ((or ':path ':maildir ':list ':subject) fieldval)
      (':message-id
       (when-let* ((msgid (mu4e-message-field-raw msg :message-id)))
         (format "<%s>" msgid)))
      (':mailing-list
       (when-let* ((list (mu4e-message-field-raw msg :list)))
         (mu4e-get-mailing-list-shortname list)))
      ((or ':flags ':labels ':tags)
       (mapconcat (lambda (item)
                    (if (symbolp item) (symbol-name item) item))
                  fieldval ", "))
      (':size (mu4e-display-size fieldval))
      (':date (when fieldval (message-make-date fieldval)))
      ((or ':from ':to ':cc ':bcc ':from-or-to)
       (mapconcat #'mu4e-contact-full fieldval ", "))
      (':user-agent fieldval)
      (_ (mu4e--view-header-value-custom msg field)))))

(defun mu4e--view-insert-headers (msg func &optional standard)
  "Render MSG's `mu4e-view-fields' headers using FUNC.
FUNC is invoked for each field that has a value, with the field's
display name, its value and its help-string (which can be nil).

Unless STANDARD is non-nil, skip the fields in
`mu4e--view-standard-fields'; when rendering with Gnus, those are
rendered by Gnus itself."
  (dolist (field mu4e-view-fields)
    (unless (and (not standard) (memq field mu4e--view-standard-fields))
      (let ((val (mu4e--view-header-value msg field)))
        (unless (or (null val) (string-empty-p val))
          (funcall func (mu4e--view-header-name field) val
                   (plist-get (mu4e--view-header-info field) :help)))))))

(defun mu4e--view-text-insert-headers (msg)
  "Insert mu4e headers for MSG into the current buffer at point.
The standard RFC headers (From, To, Cc, etc.) are left for Gnus to
render. After inserting, highlight the headers."
  (mu4e--view-insert-headers
   msg (lambda (name val help)
         (insert (propertize (concat name ":") 'help-echo help)
                 " " val "\n")))
  ;; Highlight the header block we just inserted
  (let ((gnus-treatment-function-alist
         '((gnus-treat-highlight-headers
            gnus-article-highlight-headers))))
    (gnus-treat-article 'head)))

(defun mu4e--view-html-insert-headers (msg)
  "Return MSG's headers as an alist of (NAME . VALUE) string pairs.
Unlike `mu4e--view-text-insert-headers', include the standard RFC
headers; there is no Gnus to render those."
  (let (headers)
    (mu4e--view-insert-headers
     msg (lambda (name val _help) (push (cons name val) headers)) 'standard)
    (nreverse headers)))

(defun mu4e--view-add-mime-icons ()
  "Add file icons before MIME attachment buttons.
Scan the buffer for Gnus MIME buttons (via the `gnus-data' text
property) and insert an icon before each one, based on the
filename."
  (save-excursion
    (let ((pos (point-min))
          (positions nil)
          (inhibit-read-only t))
      ;; Collect button start positions (forward scan).
      (while (setq pos (next-single-property-change pos 'gnus-data))
        (when (get-text-property pos 'gnus-data)
          (push pos positions)) ;; naturally in reverse order
        (setq pos (or (next-single-property-change pos 'gnus-data)
                      (point-max))))
      ;; Insert icons in reverse order so positions stay valid.
      (dolist (p positions)
        (when-let* ((handle (get-text-property p 'gnus-data))
                    ((listp handle))
                    (name (ignore-errors (mm-handle-filename handle)))
                    (icon (mu4e-file-name-to-icon name)))
          (goto-char p)
          (insert icon " "))))))

(defun mu4e--view-gnus-display-mime (msg)
  "Like `gnus-display-mime', but include mu4e headers to MSG."
  (lambda (&optional ihandles)
    (gnus-display-mime ihandles)
    (unless ihandles
      (save-restriction
        (article-goto-body)
        (forward-line -1)
        (narrow-to-region (point) (point))
        (mu4e--view-text-insert-headers msg)))))

(define-advice gnus-icalendar-event-from-handle
    (:filter-args (handle-attendee) mu4e--view-fix-missing-charset)
  "Avoid error when displaying an ical attachment without a charset."
  (if (and (boundp 'mu4e--view-rendering) mu4e--view-rendering)
      (let* ((handle (car handle-attendee))
             (attendee (cadr handle-attendee))
             (buf (mm-handle-buffer handle))
             (ty (mm-handle-type handle))
             (rest (cddr handle)))
        ;; Put the fallback at the end:
        (setq ty (append ty '((charset . "utf-8"))))
        (setq handle (cons buf (cons ty rest)))
        (list handle attendee))
  handle-attendee))

(defun mu4e-view-jump-to-mime-part (number)
  "Jump to MIME-part with NUMBER."
  (interactive "P")
  (call-interactively #'gnus-article-jump-to-part number))

(defun mu4e--view-mode-p ()
  "Is the buffer in mu4e-view-mode or one of its descendants?"
  (or (eq major-mode 'mu4e-view-mode)
      (derived-mode-p '(mu4e-view-mode))))

(defun mu4e--view-nop (func &rest args)
  "Do not invoke FUNC with ARGS when in mu4e-view-mode.
This is useful for advising some Gnus-functionality that does not work in mu4e."
  (unless (mu4e--view-mode-p)
    (apply func args)))

(defun mu4e--view-button-reply (func &rest args)
  "Advise FUNC with ARGS to make `gnus-button-reply' links work in mu4e."
  (if (mu4e--view-mode-p)
      (mu4e-compose-reply)
    (apply func args)))

(defun mu4e--view-button-message-id (func &rest args)
  "Advise FUNC with ARGS to make `gnus-button-message-id' links work in mu4e."
  (if (and (mu4e--view-mode-p) (stringp (car-safe args)))
      (mu4e-view-message-with-message-id (car args))
    (apply func args)))

(defun mu4e--view-msg-mail (func &rest args)
  "Advise FUNC with ARGS  to make `gnus-msg-mail' links compose with mu4e."
  (if (mu4e--view-mode-p)
      (apply 'mu4e-compose-mail args)
    (apply func args)))

(defun mu4e-view-quit ()
  "Quit the mu4e-view buffer."
  (interactive)
  (if (memq mu4e-split-view '(horizontal vertical))
      (ignore-errors ;; try, don't error out.
        (kill-buffer-and-window))
    ;; single-window case
    (let ((docid (mu4e-field-at-point :docid)))
      (when mu4e-linked-headers-buffer ;; re-use mu4e-view-detach?
        (with-current-buffer mu4e-linked-headers-buffer
          (when (eq (selected-window) mu4e~headers-view-win)
            (setq mu4e~headers-view-win nil)))
        (setq mu4e-linked-headers-buffer nil)
        (kill-buffer)
        ;; attempt to move point to just-viewed message.
        (when docid
          (ignore-errors
            (mu4e~headers-goto-docid docid)))))))

(defvar mu4e-view-mode-map
  (let ((map (make-keymap)))
    (define-key map  (kbd "C-S-u") #'mu4e-update-mail-and-index)
    (define-key map  (kbd "C-c C-u") #'mu4e-update-mail-and-index)

    (define-key map "q" #'mu4e-view-quit)

    (define-key map "z" #'mu4e-view-detach)
    (define-key map "Z" #'mu4e-view-attach)

    (define-key map "%" #'mu4e-headers-mark-pattern)
    (define-key map "t" #'mu4e-headers-mark-subthread)
    (define-key map "T" #'mu4e-headers-mark-thread)

    (define-key map "g" #'mu4e-view-go-to-url)
    (define-key map "k" #'mu4e-view-save-url)
    (define-key map "f" #'mu4e-view-fetch-url)

    (define-key map "." #'mu4e-view-raw-message)
    (define-key map "," #'mu4e-sexp-at-point)
    (define-key map "|" #'mu4e-view-pipe)
    (define-key map "a" #'mu4e-view-action)
    (define-key map "A" #'mu4e-view-mime-part-action)
    (define-key map "e" #'mu4e-view-save-attachments)
    (define-key map "J" #'mu4e-view-jump-to-mime-part)

    ;; change the number of headers
    (define-key map (kbd "C-+") #'mu4e-headers-split-view-grow)
    (define-key map (kbd "C--") #'mu4e-headers-split-view-shrink)
    (define-key map (kbd "<C-kp-add>") #'mu4e-headers-split-view-grow)
    (define-key map (kbd "<C-kp-subtract>") #'mu4e-headers-split-view-shrink)

    ;; intra-message navigation
    (define-key map (kbd "S-SPC") #'scroll-down)
    (define-key map (kbd "SPC") #'mu4e-view-scroll-up-or-next)
    (define-key map (kbd "RET")  #'mu4e-scroll-up)
    (define-key map (kbd "<backspace>") #'mu4e-scroll-down)

    ;; navigation between messages
    (define-key map "p" #'mu4e-headers-prev)
    (define-key map "n" #'mu4e-headers-next)
    ;; the same
    (define-key map (kbd "<M-down>") #'mu4e-headers-next)
    (define-key map (kbd "<M-up>") #'mu4e-headers-prev)

    (define-key map (kbd "[") #'mu4e-view-headers-prev-unread)
    (define-key map (kbd "]") #'mu4e-view-headers-next-unread)
    (define-key map (kbd "{") #'mu4e-view-headers-prev-thread)
    (define-key map (kbd "}") #'mu4e-view-headers-next-thread)

    ;; switching from view <-> headers (when visible)
    (define-key map "y" #'mu4e-select-other-view)

    ;; marking/unmarking
    (define-key map "d" #'mu4e-headers-mark-for-trash)
    (define-key map (kbd "<delete>") #'mu4e-headers-mark-for-delete)
    (define-key map (kbd "<deletechar>") #'mu4e-headers-mark-for-delete)
    (define-key map (kbd "D") #'mu4e-headers-mark-for-delete)
    (define-key map (kbd "m") #'mu4e-headers-mark-for-move)
    (define-key map (kbd "r") #'mu4e-headers-mark-for-refile)

    (define-key map (kbd "?") #'mu4e-headers-mark-for-unread)
    (define-key map (kbd "!") #'mu4e-headers-mark-for-read)

    (define-key map (kbd "+") #'mu4e-headers-mark-for-flag)
    (define-key map (kbd "-") #'mu4e-headers-mark-for-unflag)
    (define-key map (kbd "=") #'mu4e-headers-mark-for-untrash)
    (define-key map (kbd "&") #'mu4e-headers-mark-custom)

    (define-key map (kbd "l") #'mu4e-headers-mark-for-label)
    (define-key map (kbd "L") #'mu4e-headers-mark-for-unlabel)

    (define-key map (kbd "*")             #'mu4e-headers-mark-for-something)
    (define-key map (kbd "<kp-multiply>") #'mu4e-headers-mark-for-something)
    (define-key map (kbd "<insert>")     #'mu4e-headers-mark-for-something)
    (define-key map (kbd "<insertchar>") #'mu4e-headers-mark-for-something)

    (define-key map ";" #'mu4e-context-switch)

    (define-key map (kbd "#") #'mu4e-mark-resolve-deferred-marks)
    ;; misc
    (define-key map "M" #'mu4e-view-massage)

    (define-key map "w" #'visual-line-mode)
    (define-key map "h" #'mu4e-view-toggle-html)
    (define-key map (kbd "M-q") #'article-fill-long-lines)

    (define-key map "c" #'mu4e-copy-thing-at-point)

    ;; next 3 only warn user when attempt in the message view
    (define-key map "u" #'mu4e-headers-mark-for-unmark)
    (define-key map "U" #'mu4e-mark-unmark-all)
    (define-key map "x" #'mu4e-mark-execute-all)

    (define-key map "$" #'mu4e-show-log)
    (define-key map "H" #'mu4e-display-manual)

    ;; Make 0..9 shortcuts for digit-argument. Actually, none of the bound
    ;; functions seem to use a prefix arg but those bindings existed because we
    ;; used to use `suppress-keymap'. And possibly users added their own
    ;; prefix arg consuming commands.
    (dotimes (i 10)
      (define-key map (kbd (format "%d" i)) #'digit-argument))

    (set-keymap-parent map special-mode-map)
    (set-keymap-parent map button-buffer-map)
    map)
  "Keymap for mu4e-view mode.")

(easy-menu-define mu4e-view-mode-menu
  mu4e-view-mode-map "Menu for mu4e's view mode."
  (append
   '("View"
     "--"
     ["Toggle wrap lines" visual-line-mode]
     ["View raw" mu4e-view-raw-message]
     ["Pipe through shell" mu4e-view-pipe]
     "--"
     ["Mark for deletion" mu4e-headers-mark-for-delete]
     ["Mark for untrash" mu4e-headers-mark-for-untrash]
     ["Mark for trash"   mu4e-headers-mark-for-trash]
     ["Mark for move"   mu4e-headers-mark-for-move]
     )
   mu4e--compose-menu-items
   mu4e--search-menu-items
   mu4e--context-menu-items
   '(
     "--"
     ["Quit" mu4e-view-quit
      :help "Quit the view"]
     )))

(defcustom mu4e-raw-view-mode-hook nil
  "Hook run when entering \\[mu4e-raw-view] mode."
  :options '()
  :type 'hook
  :group 'mu4e-view)

(defcustom mu4e-view-mode-hook nil
  "Hook run when entering \\[mu4e-view] mode."
  :options '(turn-on-visual-line-mode)
  :type 'hook
  :group 'mu4e-view)

(defcustom mu4e-view-rendered-hook '(mu4e-resize-linked-headers-window)
  "Hook run by `mu4e-view' after a message is rendered."
  :type 'hook
  :group 'mu4e-view)

(define-derived-mode mu4e-raw-view-mode fundamental-mode "mu4e:raw-view"
  (view-mode))

;;  "Define the major-mode for the mu4e-view."
(define-derived-mode mu4e-view-mode gnus-article-mode "mu4e:view"
  "Major mode for viewing an e-mail message in mu4e.
Based on Gnus' article-mode."
  ;; some external tools (bbdb) depend on this
  (setq gnus-article-buffer (current-buffer))

  ;; ;; turn off gnus modeline changes and menu items
  (advice-add 'gnus-set-mode-line :around #'mu4e--view-nop)
  (advice-add 'gnus-button-reply :around #'mu4e--view-button-reply)
  (advice-add 'gnus-button-message-id :around #'mu4e--view-button-message-id)
  (advice-add 'gnus-msg-mail :around #'mu4e--view-msg-mail)

  ;; advice gnus-block-private-groups to always return "."
  ;; so that by default we block images.
  (advice-add 'gnus-block-private-groups :around
              (lambda(func &rest args)
                (if (mu4e--view-mode-p)
                    "." (apply func args))))
  (use-local-map mu4e-view-mode-map)
  (mu4e-context-minor-mode)
  (mu4e-search-minor-mode)
  (mu4e-compose-minor-mode)
  (setq buffer-undo-list t) ;; don't record undo info

  ;; autopair mode gives error when pressing RET
  ;; turn it off
  (when (boundp 'autopair-dont-activate)
    (setq autopair-dont-activate t)))

;;; Massaging the message view

(defcustom mu4e-view-massage-options
  '( ("ctoggle citations"           . mu4e-view-toggle-hide-citation)
     ("ftoggle fill-flowed"         . mu4e-view-toggle-fill-flowed)
     ("mtoggle show all MIME parts" . mu4e-view-show-mime-parts))
"Various options for \"massaging\" the message view. See `(gnus)
Article Treatment' for more options, e.g.
`gnus-article-hide-pem'. This is on a best-effort basis - not all
gnus toggles are supported in mu4e."
  :group 'mu4e-view
  :type '(alist :key-type string :value-type function))

(defvar-local mu4e--view-html-fallback nil
  "Non-nil if the view shows the shr-rendered html fallback.
See `mu4e--view-render-html-fallback'.")

(defun mu4e--view-html-p ()
  "Is the current message view showing html?"
  (or mu4e--view-html-fallback (mu4e--view-html-displayed-p)
      ;; xwidget bypasses Gnus' own display machinery, so
      ;; `mu4e--view-html-displayed-p' does not see it.
      (mu4e--view-xwidget-shown-p)))

(defun mu4e-view-massage()
  "Massage current message view as per `mu4e-view-massage-options'."
  (interactive)
  (when (mu4e--view-html-p)
    (mu4e-warn "Massage options not available for html display"))
  (funcall (mu4e-read-option "Massage: " mu4e-view-massage-options)))

(defun mu4e--view-render-html-fallback ()
  "Re-render the current message as html, using `shr'.
This is used by `mu4e-view-toggle-html' for messages without a
multipart/alternative part to toggle; toggle again (or use
`mu4e-view-refresh') to go back to the normal rendering."
  (let* ((msg mu4e--view-message)
         (html (or (mu4e-view-html-text
                    msg (mu4e--view-html-insert-headers msg))
                   (mu4e-warn "No html or text part in this message")))
         (inhibit-read-only t)
         ;; do not render the document <title>; it would show up as a
         ;; heading before the message headers (in web-browsers, it is
         ;; the window/tab title).
         (shr-external-rendering-functions
          (cons '(title . ignore) shr-external-rendering-functions)))
    ;; remove the url overlays; otherwise their [n] after-strings
    ;; pile up at the beginning of the buffer after erasing.
    (mu4e--view-remove-url-activations)
    (erase-buffer)
    (insert html)
    (shr-render-region (point-min) (point-max))
    (mu4e--view-linkify-buffer-text 'non-visual)
    (goto-char (point-min))
    (setq mu4e--view-html-fallback t)
    (set-buffer-modified-p nil)))

(defun mu4e--view-mime-handle (media-type)
  "Return the first MIME handle in the article with MEDIA-TYPE, or nil.
This relies on `gnus-article-mime-handle-alist' being sorted by
pertinence, i.e. the first match is the most important one."
  (seq-find (lambda (handle)
              (equal (mm-handle-media-type (cdr handle)) media-type))
            gnus-article-mime-handle-alist))

(defun mu4e--view-toggle-html-alternative ()
  "Toggle between the HTML and plain-text alternatives, using Gnus.
This works for `multipart/alternative' messages, by pressing the
corresponding Gnus button in the buffer. Return non-nil if there
were alternatives to toggle."
  (when-let* ((html-part (mu4e--view-mime-handle "text/html"))
              ((mu4e--view-mime-handle "text/plain")))
    (save-excursion
      (let ((inhibit-read-only t))
        ;; Call gnus-mime-inline-part directly, bypassing
        ;; gnus-article-part-wrapper (avoid gnus-summary-buffer.)
        (gnus-mime-inline-part (cdr html-part))
        ;; Only activate URLs in plain-text mode; in HTML mode the
        ;; renderer already provides its own clickable links (#2094),
        ;; so only collect them.
        (let ((html (mu4e--view-html-displayed-p)))
          (when html
            (mu4e--view-remove-url-activations))
          (mu4e--view-linkify-buffer-text html))))
    t))

(defun mu4e--view-toggle-html-shr ()
  "Toggle the shr-rendered html version of the message.
For messages without a text and an html alternative."
  (if mu4e--view-html-fallback
      (mu4e-view-refresh)
    (mu4e--view-render-html-fallback)))

(defun mu4e-view-toggle-html ()
  "Toggle between the HTML and plain-text versions of the message.
What this does depends on `mu4e-view-html-renderer':
- `xwidget': toggle between the xwidget and the text rendering.
  If xwidget is not available, this is the same as `shr'.
- `shr': toggle between the HTML and plain-text alternatives (for
  `multipart/alternative' messages); for other messages, toggle
  between the normal rendering and an shr-rendered html version."
  (interactive)
  (cond
   ((and (eq mu4e-view-html-renderer 'xwidget)
         (mu4e-xwidget-usable-p))
    (mu4e--view-xwidget-toggle))
   ((mu4e--view-toggle-html-alternative))
   (t (mu4e--view-toggle-html-shr))))

;;; Bug Reference mode support

;; Due to mu4e's view buffer handling (mu4e-view-mode is called long before the
;; actual mail text is inserted into the buffer), one should activate
;; bug-reference-mode in mu4e-after-view-message-hook, not mu4e-view-mode-hook.

;; This is Emacs 28 stuff but there is no need to guard it with some (f)boundp
;; checks (which would return nil if bug-reference.el is not loaded before
;; mu4e) since the function definition doesn't hurt and `add-hook' works fine
;; for not yet defined variables (by creating them).
(declare-function bug-reference-maybe-setup-from-mail "ext:bug-reference")

(defvar mu4e--view-bug-reference-checked-headers
  '("list" "list-id" "to" "from" "cc" "subject" "reply-to")
  "List of mail headers whose values are passed to bug-reference's auto-setup.")

(defun mu4e--view-try-setup-bug-reference-mode ()
  "Try to guess bug-reference setup from the current mu4e mail.
Looks at the maildir and the mail headers in
`mu4e--view-bug-reference-checked-headers' and tries to guess suitable
values for `bug-reference-bug-regexp' and
`bug-reference-url-format' by matching the maildir name against
GROUP-REGEXP and each header value against HEADER-REGEXP in
`bug-reference-setup-from-mail-alist'."
  (when (derived-mode-p 'mu4e-view-mode)
    (let (header-values)
      (save-excursion
        (goto-char (point-min))
        (dolist (field mu4e--view-bug-reference-checked-headers)
          (let ((val (mail-fetch-field field)))
            (when val
              (push val header-values)))))
      (bug-reference-maybe-setup-from-mail
       (mail-fetch-field "maildir")
       header-values))))

(with-eval-after-load 'bug-reference
  (add-hook 'bug-reference-auto-setup-functions
            #'mu4e--view-try-setup-bug-reference-mode))

(provide 'mu4e-view)
;;; mu4e-view.el ends here
