;;; tramp-rpc-process.el --- Async and PTY process support for TRAMP-RPC -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Arthur Heymans <arthur@aheymans.xyz>

;; Author: Arthur Heymans <arthur@aheymans.xyz>
;; Keywords: comm, processes
;; Package-Requires: ((emacs "30.1") (msgpack "0.1.1"))

;; This file is part of tramp-rpc.

;; tramp-rpc is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;;; Commentary:

;; This file provides async (pipe) and PTY process support for tramp-rpc.
;; It handles:
;; - Starting remote processes (pipe and PTY modes)
;; - Async callback-based I/O for pipe processes (used by LSP, compilation)
;; - PTY process support via direct SSH or RPC
;; - Terminal resize handling for vterm/eat/shell-mode
;; - Process write queuing and serialization
;; - Adaptive poll-based I/O fallback

;;; Code:

(require 'cl-lib)
(require 'tramp)
(require 'tramp-rpc-protocol)

;; Functions from tramp.el
(declare-function tramp-add-external-operation "tramp")
(declare-function tramp-remove-external-operation "tramp")
(declare-function tramp-rpc--sudo-password-required-p "tramp-rpc")
(declare-function tramp-rpc--sudo-read-password "tramp-rpc")

;; Silence byte-compiler warnings for variables defined in vterm
(defvar vterm-copy-mode)
(defvar vterm-min-window-width)
(defvar vterm--term)

;; Functions from tramp-rpc.el (loaded before us)
(declare-function tramp-rpc--debug "tramp-rpc")
(declare-function tramp-rpc--ensure-connection "tramp-rpc")
(declare-function tramp-rpc--call "tramp-rpc")
(declare-function tramp-rpc--call-fast "tramp-rpc")
(declare-function tramp-rpc--call-async "tramp-rpc")
(declare-function tramp-rpc--get-direnv-environment "tramp-rpc")
(declare-function tramp-rpc--get-remote-login-shell "tramp-rpc")
(declare-function tramp-rpc--decode-output "tramp-rpc")
(declare-function tramp-rpc--controlmaster-socket-path "tramp-rpc")
(declare-function tramp-rpc--hops-to-proxyjump "tramp-rpc")
(declare-function tramp-rpc--port-to-string "tramp-rpc")
(declare-function tramp-rpc--ensure-inside-emacs-env "tramp-rpc")
(declare-function tramp-rpc--merge-environments "tramp-rpc")
(declare-function tramp-rpc--remote-path-environment "tramp-rpc")
(declare-function tramp-rpc--tramp-remote-process-environment "tramp-rpc")
(declare-function tramp-rpc--emacsclient-tramp-environment "tramp-rpc")
(declare-function tramp-rpc--caller-environment "tramp-rpc")
(declare-function tramp-rpc--ssh-detail-user "tramp-rpc")
(declare-function tramp-rpc--sudo-rpc-hop-vec "tramp-rpc")
(declare-function tramp-rpc-file-name-p "tramp-rpc")

;; Variables from tramp-rpc.el
(defvar tramp-rpc-use-direct-ssh-pty)
(defvar tramp-rpc-use-controlmaster)
(defvar tramp-rpc-controlmaster-persist)
(defvar tramp-rpc-ssh-options)
(defvar tramp-rpc-ssh-args)
(defvar tramp-rpc-async-read-timeout-ms)
(defvar tramp-rpc--delivering-output)
(defvar tramp-rpc--closing-local-relay)

;; ============================================================================
;; Process tracking state
;; ============================================================================

(defvar tramp-rpc--async-processes (make-hash-table :test 'eq)
  "Hash table mapping local relay processes to their remote process info.
Value is a plist with :vec, :pid, :timer, :stderr-buffer.")

(defvar tramp-rpc--pty-processes (make-hash-table :test 'eq)
  "Hash table mapping local relay processes to their remote PTY process info.
Value is a plist with :vec, :pid.")

(defvar tramp-rpc--process-write-queues (make-hash-table :test 'eql)
  "Hash table mapping remote PIDs to write queue state.
Value is a plist with :pending (list of pending write data) and :writing (bool).")

;; ============================================================================
;; Remote process primitives
;; ============================================================================

(defun tramp-rpc--start-remote-process (vec program args cwd &optional env)
  "Start PROGRAM with ARGS in CWD on remote host VEC.
ENV is an optional alist of environment variables.
Returns the remote process PID."
  (let ((result (tramp-rpc--call vec "process.start"
                                 `((cmd . ,program)
                                   (args . ,(vconcat args))
                                   (cwd . ,cwd)
                                   ,@(when env `((env . ,env)))))))
    (alist-get 'pid result)))

(defun tramp-rpc--read-remote-process (vec pid)
  "Read output from remote process PID on VEC.
Returns plist with :stdout, :stderr, :exited, :exit-code."
  (let ((result (tramp-rpc--call vec "process.read" `((pid . ,pid)))))
    (list :stdout (when-let* ((s (alist-get 'stdout result)))
                    (tramp-rpc--decode-output
                     s (alist-get 'stdout_encoding result)))
          :stderr (when-let* ((s (alist-get 'stderr result)))
                    (tramp-rpc--decode-output
                     s (alist-get 'stderr_encoding result)))
          :exited (alist-get 'exited result)
          :exit-code (alist-get 'exit_code result))))

(defun tramp-rpc--write-remote-process (vec pid data)
  "Write DATA to stdin of remote process PID on VEC.
Uses async RPC with queuing to preserve write order without making
`process-send-string' wait for a remote round-trip.  This is important
for LSP servers, where didChange notifications are sent while typing."
  (let* ((queue-key pid)
         (queue (gethash queue-key tramp-rpc--process-write-queues))
         (pending (plist-get queue :pending))
         (writing (plist-get queue :writing)))
    ;; Add to pending queue.
    (setq pending (append pending (list (list :vec vec :pid pid :data data))))
    (puthash queue-key (list :pending pending :writing writing)
             tramp-rpc--process-write-queues)
    ;; If not currently writing, start processing the queue.
    (unless writing
      (tramp-rpc--process-write-queue queue-key))))

(defun tramp-rpc--process-write-queue (queue-key)
  "Process the next pending write for QUEUE-KEY (remote PID)."
  (let* ((queue (gethash queue-key tramp-rpc--process-write-queues))
         (pending (plist-get queue :pending)))
    (when pending
      (let* ((item (car pending))
             (vec (plist-get item :vec))
             (pid (plist-get item :pid))
             (data (plist-get item :data)))
        ;; Mark as writing and remove from pending
        (puthash queue-key (list :pending (cdr pending) :writing t)
                 tramp-rpc--process-write-queues)
        ;; Send the write - data must be binary for MessagePack
        (let ((data-bytes (if (multibyte-string-p data)
                              (encode-coding-string data 'utf-8-unix)
                            data)))
          (tramp-rpc--call-async vec "process.write"
                                 `((pid . ,pid)
                                   (data . ,(msgpack-bin-make data-bytes)))
                               (lambda (response)
                                 (when (plist-get response :error)
                                   (tramp-rpc--debug "WRITE-ERROR pid=%s: %s"
                                                    pid (plist-get response :error)))
                                 ;; Mark as not writing and process next item
                                 (let ((q (gethash queue-key tramp-rpc--process-write-queues)))
                                   (puthash queue-key
                                            (list :pending (plist-get q :pending) :writing nil)
                                            tramp-rpc--process-write-queues))
                                 (tramp-rpc--process-write-queue queue-key))))))))

(defun tramp-rpc--drain-write-queue (pid)
  "Wait for all pending writes to PID to complete.
Spins the event loop so that async RPC write callbacks fire and the
queue drains.  Returns once no writes are pending or in-flight, or
after a safety timeout of 5 seconds."
  (let ((deadline (+ (float-time) 5.0)))
    (while (let ((queue (gethash pid tramp-rpc--process-write-queues)))
             (and queue
                  (or (plist-get queue :writing)
                      (plist-get queue :pending))
                  (< (float-time) deadline)))
      ;; Let the event loop process async RPC responses (write callbacks)
      (accept-process-output nil 0.01))))

(defun tramp-rpc--close-remote-stdin (vec pid)
  "Close stdin of remote process PID on VEC.
Drains the write queue first so that all pending data reaches the
remote process before the pipe is closed.  Without this, the
server may process close_stdin before process.write when they
arrive as concurrent RPC requests."
  ;; Ensure all queued writes have been acknowledged by the server
  ;; before we send close_stdin.  Both requests are dispatched as
  ;; separate concurrent tokio tasks on the server; without draining,
  ;; close_stdin can win the process-map lock race and drop the stdin
  ;; handle before the write task delivers the data.
  (tramp-rpc--drain-write-queue pid)
  (tramp-rpc--call vec "process.close_stdin" `((pid . ,pid))))

(defun tramp-rpc--kill-remote-process (vec pid &optional signal)
  "Send SIGNAL to remote process PID on VEC."
  (tramp-rpc--call vec "process.kill"
                   `((pid . ,pid)
                     (signal . ,(or signal 15))))) ; SIGTERM

;; ============================================================================
;; Async Callback-based Process Reading (for LSP and interactive processes)
;; ============================================================================

(defun tramp-rpc--start-async-read (local-process)
  "Start an async read loop for LOCAL-PROCESS.
Sends a blocking read request; when response arrives, delivers output
and chains another read. This provides fast async I/O for LSP servers."
  (when (and (processp local-process)
             (process-live-p local-process)
             (gethash local-process tramp-rpc--async-processes))
    (let* ((info (gethash local-process tramp-rpc--async-processes))
           (vec (plist-get info :vec))
           (pid (plist-get info :pid)))
      (when (and vec pid)
        (tramp-rpc--debug "ASYNC-READ starting for pid=%s process=%s" pid local-process)
        ;; Send async read request with blocking timeout on server
        (tramp-rpc--call-async
         vec "process.read"
         `((pid . ,pid) (timeout_ms . ,tramp-rpc-async-read-timeout-ms))
         (lambda (response)
           (tramp-rpc--debug "ASYNC-READ callback invoked for pid=%s" pid)
           (tramp-rpc--handle-async-read-response local-process response)))))))

(defun tramp-rpc--deliver-process-output (local-process stdout stderr stderr-buffer)
  "Deliver STDOUT and STDERR to LOCAL-PROCESS.
Writes to the local cat relay process, which triggers proper I/O events
that satisfy accept-process-output.
STDERR-BUFFER is the separate stderr buffer, or nil to mix with stdout."
  (when (and (processp local-process) (process-live-p local-process))
    ;; Set flag to bypass our handler - we're writing TO the local process,
    ;; not sending data to the remote process
    (let ((tramp-rpc--delivering-output t))
      ;; Deliver stdout by writing to the cat relay process
      ;; This triggers actual I/O events that accept-process-output detects
      (when (and stdout (> (length stdout) 0))
        (tramp-rpc--debug "DELIVER stdout %d bytes to %s" (length stdout) local-process)
        (process-send-string local-process stdout))

      ;; Deliver stderr
      (when (and stderr (> (length stderr) 0))
        (tramp-rpc--debug "DELIVER stderr %d bytes" (length stderr))
        (let ((stderr-process
               (when stderr-buffer
                 (plist-get (gethash local-process tramp-rpc--async-processes)
                            :stderr-process))))
          (cond
           ;; Write to stderr cat relay if available, triggering proper I/O events
           ((and stderr-process (process-live-p stderr-process))
            (process-send-string stderr-process stderr))
           ;; Mix with stdout if no separate stderr buffer - write to cat relay
           (t
            (process-send-string local-process stderr))))))))

(defun tramp-rpc--pipe-process-sentinel (proc event user-sentinel)
  "Sentinel for pipe relay processes.
PROC is the local cat process, EVENT is the event string.
USER-SENTINEL is the user's original sentinel function.

This sentinel fires in two scenarios:
1. Cat died unexpectedly (signal/crash) - kill the remote process.
2. Cat exited after EOF from `tramp-rpc--handle-process-exit' -
   the remote process already exited, cat flushed remaining data
   and exited naturally.

In both cases, use the remote exit code (if known) to construct the
event string for the user's sentinel, so that it sees the remote
process's exit status rather than cat's."
  (when (and (memq (process-status proc) '(exit signal))
             (gethash proc tramp-rpc--async-processes))
    (let* ((info (gethash proc tramp-rpc--async-processes))
           (vec (plist-get info :vec))
           (pid (plist-get info :pid)))
      ;; Kill remote process if still running (unexpected cat death)
      (unless (process-get proc :tramp-rpc-exited)
        (when (and vec pid)
          (ignore-errors
            (tramp-rpc--kill-remote-process vec pid 9))))
      ;; Clean up stderr relay process
      (when-let* ((stderr-process (plist-get info :stderr-process)))
        (when (process-live-p stderr-process)
          (ignore-errors (delete-process stderr-process))))
      ;; Remove from tracking
      (remhash proc tramp-rpc--async-processes)))
  ;; Use the remote exit code for the event string when available,
  ;; so the user's sentinel sees the remote process status.
  (when-let* ((remote-exit (process-get proc :tramp-rpc-exit-code)))
    (setq event (if (= remote-exit 0)
                    "finished\n"
                  (format "exited abnormally with code %d\n" remote-exit))))
  ;; Call user's sentinel if provided
  (when user-sentinel
    (funcall user-sentinel proc event)))

(defun tramp-rpc--handle-async-read-response (local-process response)
  "Handle async read response for LOCAL-PROCESS.
RESPONSE is the decoded RPC response plist."
  ;; Check process is still valid
  (when (and (processp local-process)
             (process-live-p local-process)
             (gethash local-process tramp-rpc--async-processes))
    (if-let* ((rpc-error (plist-get response :error)))
        (progn
          (tramp-rpc--debug "ASYNC-READ RPC error: %S" rpc-error)
          (tramp-rpc--handle-process-exit local-process -1))
      (condition-case err
          (let* ((info (gethash local-process tramp-rpc--async-processes))
                 (stderr-buffer (plist-get info :stderr-buffer))
                 (result (plist-get response :result))
                 (stdout (when-let* ((s (alist-get 'stdout result)))
                           (tramp-rpc--decode-output
                            s (alist-get 'stdout_encoding result))))
                 (stderr (when-let* ((s (alist-get 'stderr result)))
                           (tramp-rpc--decode-output
                            s (alist-get 'stderr_encoding result))))
                 (exited (alist-get 'exited result))
                 (exit-code (alist-get 'exit_code result)))

            (tramp-rpc--debug "ASYNC-READ response: stdout=%s stderr=%s exited=%s"
                             (if stdout (length stdout) "nil")
                             (if stderr (length stderr) "nil")
                             exited)

            ;; Deliver output.  When the remote process reports EXITED, flush
            ;; data immediately before sending EOF to the local relay; otherwise
            ;; the deferred delivery can race with relay shutdown and lose output.
            (if exited
                (when (or stdout stderr)
                  (tramp-rpc--deliver-process-output
                   local-process stdout stderr stderr-buffer))
              ;; Keep deferred delivery for the non-exit hot path so
              ;; accept-process-output observes normal I/O activity.
              (when (or stdout stderr)
                (run-at-time 0 nil #'tramp-rpc--deliver-process-output
                             local-process stdout stderr stderr-buffer)))

            ;; Handle process exit or chain next read
            (if exited
                ;; Handle exit immediately so `process-live-p' flips to nil
                ;; before callers can issue another round of remote operations.
                ;; Deferring this via `run-at-time 0' leaves a small window where
                ;; loops that poll `process-live-p' can observe a stale live
                ;; process and run one extra iteration.
                (tramp-rpc--handle-process-exit local-process exit-code)
              ;; Chain another read - use run-at-time to avoid stack overflow
              (run-at-time 0 nil #'tramp-rpc--start-async-read local-process)))
        (error
         (tramp-rpc--debug "ASYNC-READ-ERROR: %S" err)
         ;; On error, clean up
         (run-at-time 0 nil #'tramp-rpc--handle-process-exit local-process -1))))))

(defun tramp-rpc--handle-process-exit (local-process exit-code)
  "Handle exit of remote process associated with LOCAL-PROCESS.
Stores the remote exit code and sends EOF to the local cat relay so
it flushes remaining output and exits naturally.  The process sentinel
\(`tramp-rpc--pipe-process-sentinel') fires when cat exits, handles
cleanup, and calls the user's sentinel with the correct event string.

This design follows TRAMP's approach: let Emacs's process machinery
handle sentinel dispatch rather than fighting it with `delete-process'
+ deferred `run-at-time' sentinel calls.  Doing `delete-process'
before the cat relay drains its pipe causes a stale FD that makes
`input-pending-p' return t permanently, starving keyboard input."
  (let ((info (gethash local-process tramp-rpc--async-processes)))
    (when info
      ;; Clean up write queue for this process's PID
      (when-let* ((pid (plist-get info :pid)))
        (remhash pid tramp-rpc--process-write-queues))
      ;; Store exit code (the sentinel reads this to construct the event
      ;; string).  Do NOT set :tramp-rpc-exited yet — the process-status
      ;; handler returns 'exit when that flag is set, which makes
      ;; `process-live-p' return nil and would prevent the EOF below
      ;; from being sent.
      (process-put local-process :tramp-rpc-exit-code (or exit-code 0))
      ;; Send EOF to the stderr cat relay so it exits cleanly.
      (when-let* ((stderr-process (plist-get info :stderr-process)))
        (when (process-live-p stderr-process)
          (ignore-errors (process-send-eof stderr-process))))
      ;; Send EOF to the LOCAL cat relay (not the remote process).
      ;; Bind `tramp-rpc--closing-local-relay' so the `process-send-eof'
      ;; handler calls the original function instead of routing to the
      ;; remote stdin (which has already exited).  Cat will flush any
      ;; remaining data to stdout, then exit naturally on EOF.  Emacs
      ;; fires the sentinel chain; the cleanup installed by
      ;; `tramp-rpc--install-process-cleanup' then deletes the process.
      (when (process-live-p local-process)
        (let ((tramp-rpc--closing-local-relay t))
          (ignore-errors (process-send-eof local-process))))
      ;; Now mark as exited so process-status handler returns 'exit.
      (process-put local-process :tramp-rpc-exited t))))

;; ============================================================================
;; Process cleanup after exit
;; ============================================================================

(defun tramp-rpc--install-process-cleanup (process)
  "Add sentinel cleanup to PROCESS so it is deleted after exit.
Wrap the caller's current sentinel and invoke it at event time before
scheduling cleanup.  Keep symbol sentinels as symbols when calling them
so dynamic rebinding, such as TRAMP's `shell-command-sentinel' test
rebinding, is still honored.  Without cleanup, `get-buffer-process'
keeps returning the dead cat relay, which makes `vc-dir-busy' think an
update is still running."
  (cl-labels ((cleanup
               (proc)
               (run-at-time
                0 nil
                (lambda ()
                  (when (processp proc)
                    (remhash proc tramp-rpc--async-processes)
                    (unless (process-live-p proc)
                      (ignore-errors
                        (delete-process proc))))))))
    (cond
     ((process-live-p process)
      (let ((sentinel (process-sentinel process)))
        (unless (process-get process :tramp-rpc-cleanup-sentinel-installed)
          (process-put process :tramp-rpc-cleanup-sentinel-installed t)
          (set-process-sentinel
           process
           (lambda (proc event)
             (when sentinel
               (funcall sentinel proc event))
             (when (memq (process-status proc) '(exit signal))
               ;; Defer deletion so the full sentinel chain completes first.
               (cleanup proc)))))))
     ((processp process)
      ;; The relay can finish before the deferred installer runs.  Its original
      ;; sentinel has already fired in that case, so just remove stale tracking.
      (cleanup process)))))

;; ============================================================================
;; Coding helper
;; ============================================================================

(defun tramp-rpc--coding-args (coding)
  "Return list of arguments for `set-process-coding-system' from CODING.
CODING is a non-nil `make-process' :coding value: either a symbol
(used for both decoding and encoding) or a cons cell (DECODING .
ENCODING).  When DECODING or ENCODING is nil inside a cons, it is
replaced with the corresponding default from
`default-process-coding-system', matching how native `make-process'
handles nil :coding elements."
  (let ((coding (tramp-rpc--normalize-coding coding)))
    (if (consp coding)
        (list (car coding) (cdr coding))
      (list coding coding))))

(defun tramp-rpc--normalize-coding (coding)
  "Normalize a `make-process' :coding value for internal use.

CODING may be nil, a coding-system symbol, or a cons cell
(DECODING . ENCODING).  Nil sides in a cons are replaced with the
corresponding side of `default-process-coding-system', like native
`make-process'.  When the resolved decoding and encoding coding systems
are identical, return the single symbol form.  This preserves native
semantics while avoiding fragile paths which assume a same-sided coding
pair is a symbol."
  (cond
   ((null coding) nil)
   ((consp coding)
    (let ((decoding (or (car coding) (car default-process-coding-system)))
          (encoding (or (cdr coding) (cdr default-process-coding-system))))
      (if (eq decoding encoding)
          decoding
        (cons decoding encoding))))
   (t coding)))

(defun tramp-rpc--maybe-login-shell-command (vec command)
  "Add login-shell args to interactive PTY login-shell COMMAND.
Non-shell commands, `shell -c ...', and script launches are left untouched.
Login args are appended after the existing args: `M-x shell' passes bash
`--noediting -i', and bash rejects the long `--noediting' option once a short
option like `-l' precedes it (an invalid-option error)."
  (let* ((program (car command))
         (args (cdr command))
         (base (and (stringp program) (file-name-nondirectory program)))
         (login-args (tramp-get-method-parameter
                      vec 'tramp-remote-shell-login)))
    (if (and base
             (or (null args)
                 (member "-i" args)
                 (member "--interactive" args))
             (not (member "-c" args))
             (not (member "--command" args))
             (not (member "--login" args))
             (not (cl-intersection login-args args :test #'string=))
             (equal base (ignore-errors
                           (file-name-nondirectory
                            (tramp-rpc--get-remote-login-shell vec)))))
        ;; bash refuses `bash -l --noediting -i' but accepts `bash --noediting -i -l'.
        (append command login-args)
      command)))

;; ============================================================================
;; make-process handler
;; ============================================================================

(defun tramp-rpc--make-process-skeleton-args (args)
  "Return ARGS adjusted for `tramp-skeleton-make-process'.
TRAMP's skeleton uses `or' when resolving `:connection-type', which would
turn an explicit nil into the dynamic `process-connection-type'.  Native
`make-process' treats explicit nil as a pipe, so pass `pipe' to the skeleton
for that one case.

The skeleton also treats string `:stderr' as a remote stderr file.  Preserve
tramp-rpc's existing compatibility behavior where non-remote strings name
stderr buffers."
  (let ((args (copy-sequence args)))
    (when (and (plist-member args :connection-type)
               (null (plist-get args :connection-type)))
      (setq args (plist-put args :connection-type 'pipe)))
    (when-let* ((stderr (plist-get args :stderr)))
      (when (and (stringp stderr)
                 (not (tramp-tramp-file-p stderr)))
        (setq args (plist-put args :stderr (get-buffer-create stderr)))))
    args))

(defun tramp-rpc-handle-make-process (&rest args)
  "Create an async process on the remote host.
ARGS are keyword arguments as per `make-process'.
Supports PTY allocation when :connection-type is \='pty or t,
or when `process-connection-type' is t.
For pipe mode, uses async polling for long-running processes.
Resolves program path and loads direnv environment from working directory."
  (let ((args (tramp-rpc--make-process-skeleton-args args)))
    ;; Reuse TRAMP's make-process skeleton for type checks, unique process names,
    ;; buffer setup, stderr validation, and TRAMP file-name parsing.  The body
    ;; below is only the RPC-specific process creation path.
    (tramp-skeleton-make-process args nil t
      ;; Unquote localname in case of file-name-quoted paths (e.g. /: prefix).
      (setq localname (file-name-unquote localname))
      (let* ((sudo-command (and (car command)
                                (string= (file-name-nondirectory (car command))
                                         "sudo")))
             ;; The skeleton normalizes t to `pty'.  `pipe' and nil are both
             ;; non-PTY from the RPC process launcher's perspective.
             (use-pty (eq connection-type 'pty))
             (pipe-sudo (and sudo-command (not use-pty)))
             (sudo-password nil)
             (coding (tramp-rpc--normalize-coding coding)))
        ;; For non-PTY literal sudo commands, validate sudo in the same RPC pipe
        ;; execution context that will run the command.  If a password is needed,
        ;; use sudo's stdin wrapper; a separate PTY preauth can miss tty-scoped
        ;; sudo timestamps and leave the pipe-mode command unauthenticated.
        (when pipe-sudo
          (let ((ssh-user (or (tramp-rpc--ssh-detail-user v) (user-login-name))))
            (if (tramp-rpc--sudo-password-required-p v)
                (setq sudo-password (tramp-rpc--sudo-read-password v ssh-user)
                      ;; This RPC path invokes sudo directly, so unlike the SSH
                      ;; server-start path the empty prompt argument is preserved.
                      ;; Suppress prompt text so it does not pollute the async
                      ;; process' stdout/stderr.
                      command (append (list (car command) "-k" "-S" "-p" "")
                                      (cdr command)))
              (setq command (append (list (car command) "-n")
                                    (cdr command))))))
        (when use-pty
          (setq command (tramp-rpc--maybe-login-shell-command v command)))
        ;; Get the remote process environment: PATH from `tramp-remote-path'
        ;; (or deprecated `tramp-rpc-remote-path'), direnv for this directory,
        ;; INSIDE_EMACS, and caller-set env vars (e.g. GIT_INDEX_FILE from magit).
        (let ((process-env (tramp-rpc--ensure-inside-emacs-env
                            (tramp-rpc--merge-environments
                             (tramp-rpc--remote-path-environment v)
                             (tramp-rpc--tramp-remote-process-environment)
                             (tramp-rpc--emacsclient-tramp-environment v)
                             (tramp-rpc--get-direnv-environment v localname)
                             (tramp-rpc--caller-environment)))))
          (if use-pty
              ;; PTY mode - start async process with PTY.  Do not add -n or
              ;; pre-authenticate here; sudo owns the terminal prompt.
              (tramp-rpc--make-pty-process
               v name buffer command coding noquery
               filter sentinel localname process-env)
            ;; Pipe mode - use a local cat process as relay for proper I/O events.
            ;; This is needed because accept-process-output waits for actual I/O,
            ;; not just filter calls.  Leave relative PROGRAM names unresolved so
            ;; the server's process launcher searches the PATH we pass in
            ;; PROCESS-ENV.
            (let* ((program (car command))
                   (program-args (cdr command))
                   (remote-pid (tramp-rpc--start-remote-process
                                v program program-args localname process-env))
                   ;; Use a local cat process as relay: we write output to its
                   ;; stdin and it echoes to stdout, triggering proper I/O events.
                   (local-process (let ((process-connection-type nil))
                                    (start-process (or name "tramp-rpc-async")
                                                   buffer
                                                   "cat")))
                   (stderr-buffer (cond
                                   ((bufferp stderr) stderr)
                                   ((stringp stderr) (get-buffer-create stderr))
                                   (t nil)))
                   ;; Create a stderr cat relay so that
                   ;; (get-buffer-process stderr-buffer) returns a process,
                   ;; matching the contract of native `make-process' with :stderr.
                   (stderr-process
                    (when stderr-buffer
                      (let* ((process-connection-type nil)
                             (proc (start-process
                                    (format "%s-stderr" (or name "tramp-rpc-async"))
                                    stderr-buffer
                                    "cat")))
                        (set-process-query-on-exit-flag proc nil)
                        proc))))

              ;; Feed sudo's stdin password before exposing the relay to callers;
              ;; subsequent writes use the same queue and stay ordered after it.
              (when sudo-password
                (tramp-rpc--write-remote-process
                 v remote-pid (concat sudo-password "\n")))

              ;; Configure the local relay process.
              (when coding
                (apply #'set-process-coding-system local-process
                       (tramp-rpc--coding-args coding)))
              (set-process-query-on-exit-flag local-process (not noquery))

              (process-put local-process :tramp-rpc-vec v)
              (process-put local-process :tramp-rpc-pid remote-pid)
              (process-put local-process 'tramp-vector v)
              (process-put local-process 'remote-command orig-command)

              (when filter
                (set-process-filter local-process filter))
              (when sentinel
                ;; Wrap sentinel to handle our cleanup.
                (set-process-sentinel
                 local-process
                 (lambda (proc event)
                   (tramp-rpc--pipe-process-sentinel proc event sentinel))))

              ;; Store process info.
              (puthash local-process
                       (list :vec v
                             :pid remote-pid
                             :stderr-buffer stderr-buffer
                             :stderr-process stderr-process)
                       tramp-rpc--async-processes)

              (tramp-rpc--debug
               "MAKE-PROCESS created local=%s remote-pid=%s program=%s"
               local-process remote-pid program)

              ;; Start async read loop.
              (tramp-rpc--start-async-read local-process)

              ;; Schedule deferred sentinel cleanup.  Callers like `vc-do-command'
              ;; replace the sentinel with `set-process-sentinel' AFTER
              ;; `start-file-process' returns, so we must add our cleanup wrapper
              ;; after that.  `run-at-time 0' ensures it runs once the current
              ;; code path (including the caller's sentinel setup) completes.
              ;; The wrapper calls `delete-process' after the sentinel chain
              ;; finishes, which removes the process from `Vprocess_alist'.
              ;; Without this, `get-buffer-process' returns stale exited cat
              ;; relays, causing e.g. `vc-dir-busy' to report a false positive.
              (let ((proc local-process))
                (run-at-time 0 nil
                             (lambda ()
                               (when (processp proc)
                                 (tramp-rpc--install-process-cleanup proc)))))

              local-process)))))))

(defun tramp-rpc-handle-start-file-process (name buffer program &rest args)
  "Start async process on remote host.
NAME is the process name, BUFFER is the output buffer,
PROGRAM is the command to run, ARGS are its arguments."
  (tramp-rpc-handle-make-process
   :name name
   :buffer buffer
   :command (cons program args)))

;; ============================================================================
;; PTY Process Support
;; ============================================================================

(defun tramp-rpc--make-pty-process (vec name buffer command coding noquery
                                         filter sentinel localname &optional direnv-env)
  "Create a PTY-based process for terminal emulators.
VEC is the tramp connection vector.
NAME, BUFFER, COMMAND, CODING, NOQUERY, FILTER, SENTINEL are process params.
LOCALNAME is the remote working directory.
DIRENV-ENV is an optional alist of environment variables from direnv.

When `tramp-rpc-use-direct-ssh-pty' is non-nil (the default), this uses
a direct SSH connection for the PTY, providing much lower latency for
interactive terminal use.  Otherwise, uses the RPC-based PTY implementation."
  (if (and tramp-rpc-use-direct-ssh-pty
           ;; Sudo-via-RPC paths must not use the final sudo vec for direct SSH,
           ;; because that would attempt to SSH as root instead of using the rpc
           ;; hop's identity and elevated RPC server.
           (not (tramp-rpc--sudo-rpc-hop-vec vec)))
      ;; Use direct SSH for low-latency PTY
      (tramp-rpc--make-direct-ssh-pty-process
       vec name buffer command coding noquery filter sentinel localname direnv-env)
    ;; Use RPC-based PTY
    (tramp-rpc--make-rpc-pty-process
     vec name buffer command coding noquery filter sentinel localname direnv-env)))

(defun tramp-rpc--make-direct-ssh-pty-process (vec name buffer command coding noquery
                                                    filter sentinel localname &optional direnv-env)
  "Create a PTY process using direct SSH connection.
This provides much lower latency than the RPC-based PTY by using a direct
SSH connection with `-t` for the terminal.  The SSH connection reuses the
existing ControlMaster socket, so authentication is already handled.

VEC is the tramp connection vector.
NAME, BUFFER, COMMAND, CODING, NOQUERY, FILTER, SENTINEL are process params.
LOCALNAME is the remote working directory.
DIRENV-ENV is an optional alist of environment variables from direnv."
  (let* ((host (tramp-file-name-host vec))
         (user (tramp-file-name-user vec))
         (port (tramp-rpc--port-to-string (tramp-file-name-port vec)))
         (program (car command))
         (program-args (cdr command))
         ;; Build environment exports for the remote command
         (env-exports (mapconcat
                       (lambda (pair)
                          (format "export %s=%s;"
                                  (car pair)
                                  (tramp-shell-quote-argument (cdr pair))))
                       (append direnv-env
                               `(("TERM" . ,(or (getenv "TERM") "xterm-256color"))))
                       " "))
         ;; Build the remote command - cd to dir, export env, exec program
         (remote-cmd (format "cd %s && %s exec %s %s"
                             (tramp-shell-quote-argument localname)
                             env-exports
                              (tramp-shell-quote-argument program)
                              (mapconcat #'tramp-shell-quote-argument program-args " ")))
         (proxyjump (tramp-rpc--hops-to-proxyjump vec))
         ;; Build SSH arguments for direct PTY connection
         (ssh-args (append
                    (list "ssh")
                    ;; Request PTY allocation
                    (list "-t" "-t")  ; Force PTY even without controlling terminal
                    ;; Multi-hop via ProxyJump
                    (when proxyjump (list "-J" proxyjump))
                    ;; Reuse ControlMaster if enabled
                    (when tramp-rpc-use-controlmaster
                      (list "-o" "ControlMaster=auto"
                            "-o" (format "ControlPath=%s"
                                         (tramp-rpc--controlmaster-socket-path vec))
                            "-o" (format "ControlPersist=%s"
                                         tramp-rpc-controlmaster-persist)))
                    ;; Only use BatchMode=yes when ControlMaster handles auth;
                    ;; without it, BatchMode=yes prevents password prompts.
                    (when tramp-rpc-use-controlmaster
                      (list "-o" "BatchMode=yes"))
                    (list "-o" "StrictHostKeyChecking=accept-new")
                    ;; Suppress "Shared connection to ... closed." messages
                    (list "-o" "LogLevel=error")
                    ;; User-specified SSH options
                    (mapcan (lambda (opt) (list "-o" opt))
                            tramp-rpc-ssh-options)
                    ;; Raw SSH arguments
                    tramp-rpc-ssh-args
                    ;; Connection parameters
                    (when user (list "-l" user))
                    (when port (list "-p" port))
                    ;; Host and command
                    (list host remote-cmd)))
         ;; Normalize buffer
         (actual-buffer (cond
                         ((bufferp buffer) buffer)
                         ((stringp buffer) (get-buffer-create buffer))
                         ((eq buffer t) (current-buffer))
                         (t nil)))
         ;; Start the SSH process with PTY
         (process-connection-type t)  ; Use PTY
         (process (apply #'start-process
                         (or name "tramp-rpc-direct-pty")
                         actual-buffer
                         ssh-args)))

    (tramp-rpc--debug "DIRECT-SSH-PTY started: %s -> %s %S"
                     process host command)

    ;; Configure the process
    (when coding
      (apply #'set-process-coding-system process
             (tramp-rpc--coding-args coding)))
    (set-process-query-on-exit-flag process (not noquery))

    ;; Set up filter
    (when filter
      (set-process-filter process filter))

    ;; Set up sentinel
    (when sentinel
      (set-process-sentinel process sentinel))

    ;; Store tramp-rpc metadata for compatibility with other code
    (process-put process :tramp-rpc-pty t)
    (process-put process :tramp-rpc-direct-ssh t)
    (process-put process :tramp-rpc-vec vec)
    (process-put process :tramp-rpc-user-sentinel sentinel)
    (process-put process :tramp-rpc-command command)
    ;; Standard tramp property expected by tests and upstream code
    (process-put process 'remote-command command)
    (process-put process 'tramp-vector vec)

    process))

(defun tramp-rpc--make-rpc-pty-process (vec name buffer command coding noquery
                                             filter sentinel localname &optional direnv-env)
  "Create a PTY-based process using the RPC server.
This is the fallback when direct SSH PTY is disabled.

VEC is the tramp connection vector.
NAME, BUFFER, COMMAND, CODING, NOQUERY, FILTER, SENTINEL are process params.
LOCALNAME is the remote working directory.
DIRENV-ENV is an optional alist of environment variables for the process."
  (let* ((program (car command))
         (program-args (cdr command))
         ;; Get terminal dimensions from buffer or use defaults
         (size (tramp-rpc--get-terminal-size buffer))
         (rows (cdr size))
         (cols (car size))
         ;; Build environment - add TERM after caller/remote env so it wins.
         (term-env (or (getenv "TERM") "xterm-256color"))
         (full-env (append direnv-env `(("TERM" . ,term-env))))
         ;; Start the PTY process on remote
         (result (tramp-rpc--call vec "process.start_pty"
                                   `((cmd . ,program)
                                     (args . ,(vconcat program-args))
                                     (cwd . ,localname)
                                     (rows . ,rows)
                                     (cols . ,cols)
                                     (env . ,full-env))))
         (remote-pid (alist-get 'pid result))
         (tty-name (alist-get 'tty_name result))
         ;; Normalize buffer - it can be t, nil, a buffer, or a string
         (actual-buffer (cond
                         ((bufferp buffer) buffer)
                         ((stringp buffer) (get-buffer-create buffer))
                         ((eq buffer t) (current-buffer))
                         (t nil)))
         ;; Create a local pipe process as a relay
         ;; We use make-pipe-process for the local side - all actual I/O
         ;; goes through our PTY RPC calls, not through this process.
         (local-process (make-pipe-process
                         :name (or name "tramp-rpc-pty")
                         :buffer actual-buffer
                         :coding (or (tramp-rpc--normalize-coding coding)
                                     'utf-8-unix)
                         :noquery t)))

    ;; Configure the local relay process
    (set-process-filter local-process (or filter #'tramp-rpc--pty-default-filter))
    (set-process-sentinel local-process #'tramp-rpc--pty-sentinel)
    (set-process-query-on-exit-flag local-process (not noquery))
    (when coding
      (apply #'set-process-coding-system local-process
             (tramp-rpc--coding-args coding)))

    ;; Store process info
    (process-put local-process :tramp-rpc-pty t)
    (process-put local-process :tramp-rpc-pid remote-pid)
    (process-put local-process :tramp-rpc-vec vec)
    (process-put local-process :tramp-rpc-user-sentinel sentinel)
    (process-put local-process :tramp-rpc-command command)
    (process-put local-process :tramp-rpc-tty-name tty-name)
    ;; Standard tramp property expected by tests and upstream code
    (process-put local-process 'remote-command command)
    (process-put local-process 'tramp-vector vec)

    ;; Set up window size adjustment function
    (process-put local-process 'adjust-window-size-function
                 #'tramp-rpc--adjust-pty-window-size)

    ;; Track the PTY process
    (puthash local-process
             (list :vec vec :pid remote-pid)
             tramp-rpc--pty-processes)

    ;; Start async read loop
    (tramp-rpc--pty-start-async-read local-process)

    local-process))

(defun tramp-rpc--pty-default-filter (process output)
  "Default filter for PTY processes - insert output into process buffer."
  (when-let* ((buf (process-buffer process)))
    (when (buffer-live-p buf)
      (with-current-buffer buf
        (let ((moving (= (point) (process-mark process))))
          (save-excursion
            (goto-char (process-mark process))
            (insert output)
            (set-marker (process-mark process) (point)))
          (when moving
            (goto-char (process-mark process))))))))

(defun tramp-rpc--get-terminal-size (buffer)
  "Get terminal size for BUFFER.
Returns (COLS . ROWS)."
  (let ((buf (cond
              ((bufferp buffer) buffer)
              ((stringp buffer) (get-buffer buffer))
              (t nil))))
    (if (and buf (buffer-live-p buf))
        (with-current-buffer buf
          (let ((window (get-buffer-window buf)))
            (if window
                (cons (window-body-width window)
                      (window-body-height window))
              '(80 . 24))))
      '(80 . 24))))

(defun tramp-rpc--pty-start-async-read (local-process)
  "Start an async read loop for LOCAL-PROCESS.
Sends a blocking read request; when response arrives, delivers output
and chains another read.  This provides truly async PTY I/O."
  (when (and (processp local-process)
             (process-live-p local-process)
             (gethash local-process tramp-rpc--pty-processes))
    (let* ((vec (process-get local-process :tramp-rpc-vec))
           (pid (process-get local-process :tramp-rpc-pid)))
      (when (and vec pid)
        ;; Send async read request with blocking timeout on server
        (tramp-rpc--call-async
         vec "process.read_pty"
         `((pid . ,pid) (timeout_ms . 100))
         (lambda (response)
           (tramp-rpc--pty-handle-async-response local-process response)))))))

(defun tramp-rpc--pty-handle-async-response (local-process response)
  "Handle async read response for LOCAL-PROCESS.
RESPONSE is the decoded RPC response plist."
  ;; Check process is still valid
  (when (and (processp local-process)
             (process-live-p local-process)
             (gethash local-process tramp-rpc--pty-processes))
    (condition-case nil
        (let* ((result (plist-get response :result))
               (output (when-let* ((o (alist-get 'output result)))
                         (tramp-rpc--decode-output
                          o (alist-get 'output_encoding result))))
               (exited (alist-get 'exited result))
                (exit-code (alist-get 'exit_code result)))

          ;; Deliver output via filter
          (when (and output (> (length output) 0))
            (if-let* ((filter (process-filter local-process)))
                (funcall filter local-process output)
              (when-let* ((buf (process-buffer local-process)))
                (when (buffer-live-p buf)
                  (with-current-buffer buf
                    (goto-char (point-max))
                    (insert output))))))

          ;; Handle process exit or chain next read
          (if exited
              (tramp-rpc--handle-pty-exit local-process exit-code)
            ;; Chain another read immediately
            (tramp-rpc--pty-start-async-read local-process)))
      (error
       ;; On error, clean up
       (tramp-rpc--handle-pty-exit local-process nil)))))

(defun tramp-rpc--handle-pty-exit (local-process exit-code)
  "Handle exit of PTY process associated with LOCAL-PROCESS."
  ;; Clean up PTY on remote
  (when-let* ((vec (process-get local-process :tramp-rpc-vec))
             (pid (process-get local-process :tramp-rpc-pid)))
    (ignore-errors
      (tramp-rpc--call vec "process.close_pty" `((pid . ,pid)))))

  ;; Remove from tracking
  (remhash local-process tramp-rpc--pty-processes)

  ;; Store exit info
  (process-put local-process :tramp-rpc-exit-code (or exit-code 0))
  (process-put local-process :tramp-rpc-exited t)

  ;; Get user sentinel
  (let ((user-sentinel (process-get local-process :tramp-rpc-user-sentinel))
        (event (if (and exit-code (= exit-code 0))
                   "finished\n"
                 (format "exited abnormally with code %d\n" (or exit-code -1)))))
    ;; Delete the local process
    (when (process-live-p local-process)
      (delete-process local-process))
    ;; Call user sentinel
    (when user-sentinel
      (funcall user-sentinel local-process event))))

(defun tramp-rpc--pty-sentinel (process event)
  "Sentinel for PTY relay processes.
PROCESS is the local relay process, EVENT is the process event."
  ;; Handle local process termination (e.g., user killed it)
  (when (memq (process-status process) '(exit signal))
    ;; Clean up remote PTY if still tracked
    (when (gethash process tramp-rpc--pty-processes)
      (when-let* ((vec (process-get process :tramp-rpc-vec))
                 (pid (process-get process :tramp-rpc-pid)))
        (ignore-errors
          (tramp-rpc--call vec "process.kill_pty"
                           `((pid . ,pid) (signal . 9)))))
      ;; Remove from tracking
      (remhash process tramp-rpc--pty-processes))
    ;; Call user sentinel
    (when-let* ((user-sentinel (process-get process :tramp-rpc-user-sentinel)))
      (funcall user-sentinel process event))))

;; ============================================================================
;; PTY window resize support
;; ============================================================================

(defun tramp-rpc--adjust-pty-window-size (process _windows)
  "Adjust PTY window size when Emacs window size changes.
PROCESS is the local relay process, WINDOWS is the list of windows.
Returns nil to tell Emacs not to call `set-process-window-size' on
the local relay process (we handle resizing via RPC to the remote)."
  (when (and (process-live-p process)
             (process-get process :tramp-rpc-pty))
    (when-let* ((vec (process-get process :tramp-rpc-vec))
               (pid (process-get process :tramp-rpc-pid)))
      (let ((size (tramp-rpc--get-terminal-size (process-buffer process))))
        ;; Resize the remote PTY
        (ignore-errors
          (tramp-rpc--call-fast vec "process.resize_pty"
                                `((pid . ,pid)
                                  (cols . ,(car size))
                                  (rows . ,(cdr size))))))))
  ;; Return nil - we handle resizing ourselves, Emacs shouldn't try to
  ;; set-process-window-size on our local relay process
  nil)

(defun tramp-rpc--handle-pty-resize (process windows size-adjuster display-updater)
  "Handle PTY resize for tramp-rpc PROCESS displayed in WINDOWS.
SIZE-ADJUSTER is a function (width height) -> (width . height) that adjusts
the calculated size for the specific terminal emulator.
DISPLAY-UPDATER is a function (width height) that updates the terminal display.
Returns the final (width . height) cons, or nil if resize was not handled."
  (when (process-live-p process)
    (when-let* ((vec (process-get process :tramp-rpc-vec))
               (pid (process-get process :tramp-rpc-pid))
               (buf (process-buffer process)))
      (when (buffer-live-p buf)
        (with-current-buffer buf
          (let* ((size (funcall window-adjust-process-window-size-function
                                process windows))
                 (width (car size))
                 (height (cdr size))
                 (inhibit-read-only t))
            (when size
              ;; Let terminal-specific code adjust size
              (when size-adjuster
                (let ((adjusted (funcall size-adjuster width height)))
                  (setq width (car adjusted)
                        height (cdr adjusted))))
              (when (and (> width 0) (> height 0))
                ;; Resize remote PTY
                (ignore-errors
                  (tramp-rpc--call-fast vec "process.resize_pty"
                                        `((pid . ,pid)
                                          (cols . ,width)
                                          (rows . ,height))))
                ;; Let terminal-specific code update display
                (when display-updater
                  (funcall display-updater width height))
                (cons width height)))))))))

(defun tramp-rpc-handle-vterm--window-adjust-process-window-size (process windows)
  "Handler for vterm's window adjust function to handle TRAMP-RPC PTY processes.
For tramp-rpc processes, resize the remote PTY and update vterm's display.
For direct SSH PTY, let the original function handle it (SSH handles resize)."
  (cond
   ;; Direct SSH PTY - let original function handle it
   ((and (processp process)
         (process-get process :tramp-rpc-direct-ssh))
    (tramp-run-real-handler
     'vterm--window-adjust-process-window-size (list process windows)))
   ;; RPC-based PTY - resize via RPC
   ((and (processp process)
         (process-get process :tramp-rpc-pty))
    (unless vterm-copy-mode
        (tramp-rpc--handle-pty-resize
         process windows
         ;; Size adjuster: apply vterm margins and minimum width
         (lambda (width height)
           (when (fboundp 'vterm--get-margin-width)
             (setq width (- width (vterm--get-margin-width))))
           (cons (max width vterm-min-window-width) height))
         ;; Display updater: call vterm--set-size
         (lambda (width height)
           (when (and (boundp 'vterm--term) vterm--term
                    (fboundp 'vterm--set-size))
             (vterm--set-size vterm--term height width))))))
   ;; Not our process, call original
   (t (tramp-run-real-handler
       'vterm--window-adjust-process-window-size (list process windows)))))

(defun tramp-rpc-handle-eat--adjust-process-window-size (process windows)
  "Handler for eat's window adjust function to handle TRAMP-RPC PTY processes.
For tramp-rpc processes, resize the remote PTY and update eat's display.
For direct SSH PTY, let the original function handle it (SSH handles resize)."
  (cond
   ;; Direct SSH PTY - let original function handle it
   ((and (processp process)
         (process-get process :tramp-rpc-direct-ssh))
    (tramp-run-real-handler
     'eat--adjust-process-window-size (list process windows)))
   ;; RPC-based PTY - resize via RPC
   ((and (processp process)
         (process-get process :tramp-rpc-pty))
    (tramp-rpc--handle-pty-resize
       process windows
       ;; Size adjuster: ensure minimum of 1
       (lambda (width height)
         (cons (max width 1) (max height 1)))
       ;; Display updater: resize eat terminal and run hooks
       (lambda (width height)
         (when (and (boundp 'eat-terminal) eat-terminal
                    (fboundp 'eat-term-resize)
                    (fboundp 'eat-term-redisplay))
           (eat-term-resize eat-terminal width height)
           (eat-term-redisplay eat-terminal))
         (pcase major-mode
           ('eat-mode (run-hooks 'eat-update-hook))
           ('eshell-mode (run-hooks 'eat-eshell-update-hook))))))
   ;; Not our process, call original
   (t (tramp-run-real-handler
       'eat--adjust-process-window-size (list process windows)))))

;; ============================================================================
;; Process cleanup
;; ============================================================================

(defun tramp-rpc--cleanup-pty-processes (&optional vec)
  "Clean up PTY processes, optionally only those for VEC."
  (maphash
   (lambda (local-process info)
     (when (or (null vec)
               (equal (tramp-rpc--connection-key (plist-get info :vec))
                      (tramp-rpc--connection-key vec)))
       ;; Kill remote PTY
       (when-let* ((pv (plist-get info :vec))
                   (pid (plist-get info :pid)))
         (ignore-errors
           (tramp-rpc--call pv "process.kill_pty"
                            `((pid . ,pid) (signal . 9)))))
       ;; Kill local process
       (when (process-live-p local-process)
         (delete-process local-process))
       ;; Remove from tracking
       (remhash local-process tramp-rpc--pty-processes)))
   tramp-rpc--pty-processes))

(defun tramp-rpc--cleanup-async-processes (&optional vec)
  "Clean up async processes, optionally only those for VEC."
  (maphash
   (lambda (local-process info)
     (when (or (null vec)
               (equal (tramp-rpc--connection-key (plist-get info :vec))
                      (tramp-rpc--connection-key vec)))
       ;; Cancel timer
       (when-let* ((timer (plist-get info :timer)))
         (cancel-timer timer))
       ;; Kill stderr relay process
       (when-let* ((stderr-process (plist-get info :stderr-process)))
         (when (process-live-p stderr-process)
           (ignore-errors (delete-process stderr-process))))
       ;; Kill local process
       (when (process-live-p local-process)
         (delete-process local-process))
       ;; Remove from tracking
       (remhash local-process tramp-rpc--async-processes)))
   tramp-rpc--async-processes))

;; Forward declare for cleanup
(declare-function tramp-rpc--connection-key "tramp-rpc")

;; Install terminal emulator handler.  When vterm/eat is already loaded while
;; `tramp-rpc' is being required, defer until `tramp-rpc' is provided; otherwise
;; `tramp-add-external-operation' calls `(require 'tramp-rpc)' recursively.
(with-eval-after-load 'vterm
  (with-eval-after-load 'tramp-rpc
    (tramp-add-external-operation
     'vterm--window-adjust-process-window-size
     #'tramp-rpc-handle-vterm--window-adjust-process-window-size
     'tramp-rpc 'process)))

(with-eval-after-load 'eat
  (with-eval-after-load 'tramp-rpc
    (tramp-add-external-operation
     'eat--adjust-process-window-size
     #'tramp-rpc-handle-eat--adjust-process-window-size
     'tramp-rpc 'process)))

(defun tramp-rpc--process-handler-remove ()
  "Remove handlers."
  (tramp-remove-external-operation
   'vterm--window-adjust-process-window-size 'tramp-rpc)
  (tramp-remove-external-operation
   'eat--adjust-process-window-size 'tramp-rpc))

;; ============================================================================
;; Unload support
;; ============================================================================

(defun tramp-rpc-process-unload-function ()
  "Unload function for tramp-rpc-process.
Removes handlers and cleans up async processes."
  ;; Remove all handlers
  (tramp-rpc--process-handler-remove)
  ;; Clean up all async processes.
  (tramp-rpc--cleanup-async-processes)
  ;; Clean up PTY processes.
  (tramp-rpc--cleanup-pty-processes)
  ;; Return nil to allow normal unload to proceed
  nil)

(add-hook 'tramp-rpc-unload-hook
	  (lambda ()
	    (when (featurep 'tramp-rpc-process)
	      (unload-feature 'tramp-rpc-process 'force))))

(provide 'tramp-rpc-process)
;;; tramp-rpc-process.el ends here
