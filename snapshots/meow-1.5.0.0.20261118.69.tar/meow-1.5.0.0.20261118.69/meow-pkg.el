;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "1.5.0.0.20261118.69"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://www.github.com/DogLooksGood/meow"
  :commit "f9612a164c638e88d343e98a529a4d83e597bfdc"
  :revdesc "f9612a164c63"
  :keywords '("convenience" "modal-editing"))
