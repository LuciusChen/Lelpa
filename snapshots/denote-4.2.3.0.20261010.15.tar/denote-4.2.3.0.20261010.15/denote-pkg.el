;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote" "4.2.3.0.20261010.15"
  "Simple notes with an efficient file-naming scheme."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/denote"
  :commit "eb621476cd1b9ce8fb3e1e6d04d8dd51334fedb9"
  :revdesc "eb621476cd1b"
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
